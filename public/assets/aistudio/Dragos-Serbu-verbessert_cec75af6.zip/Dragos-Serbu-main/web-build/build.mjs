// Baut die komplette App als eine HTML-Datei zum Testen ohne Server (node web-build/build.mjs <esbuild-pfad> <ausgabe.html>).
import fs from 'fs';
import path from 'path';
import { createRequire } from 'module';
const require = createRequire(import.meta.url);
const [, , esbuildPath, outFile] = process.argv;
const esbuild = require(esbuildPath);
const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const shim = (p) => path.join(root, 'web-build', 'shims', p);

// Alle in der App verwendeten Icon-Namen einsammeln
const icons = new Set();
for (const f of fs.readdirSync(path.join(root, 'src'), { recursive: true })) {
  if (!/\.tsx?$/.test(f)) continue;
  const src = fs.readFileSync(path.join(root, 'src', f), 'utf8');
  for (const m of src.matchAll(/import\s*\{([^}]+)\}\s*from\s*'lucide-react'/g)) m[1].split(',').map(s => s.trim()).filter(Boolean).forEach(n => icons.add(n.split(' as ')[0].trim()));
}

const virtual = {
  dotenv: 'export default { config() {} };',
  path: "const j=(...a)=>a.join('/'); export default { dirname: () => '/', resolve: j, join: j };",
  fs: "export default { existsSync: () => false, readFileSync() { throw new Error('nicht verfügbar'); }, writeFileSync() {}, mkdirSync() {} };",
  url: "export const fileURLToPath = () => '/server.ts';",
  '@google/genai': 'export class GoogleGenAI {}',
  vite: 'export const createServer = async () => ({ middlewares: () => {} });',
  react: 'module.exports = window.React;',
  'react-dom/client': 'module.exports = window.ReactDOM;',
  'react/jsx-runtime': "const R = window.React; export const Fragment = R.Fragment; export function jsx(t, p, k) { return R.createElement(t, k === undefined ? p : Object.assign({}, p, { key: k })); } export const jsxs = jsx;",
  'lucide-react': `const L = window.LucideReact || {}; const R = window.React;
const Fallback = (p) => R.createElement('span', { className: p.className, style: { display: 'inline-block', borderRadius: 3, background: 'currentColor', opacity: .35 } });
const pick = (n) => L[n] || L[n + 'Icon'] || Fallback;
${[...icons].map(n => `export const ${n} = pick('${n}');`).join('\n')}`,
};

const plugin = {
  name: 'web-test-build',
  setup(b) {
    b.onResolve({ filter: /^express$/ }, () => ({ path: shim('express.ts') }));
    b.onResolve({ filter: /^\.\/server-auth$/ }, a => (a.importer.endsWith('server.ts') ? { path: shim('server-auth.ts') } : undefined));
    b.onResolve({ filter: /^\.\/server-(workspace|billing|oauth|mail|kv)$/ }, a => (a.importer.endsWith('server.ts') ? { path: shim(a.path.slice(2) + '.ts') } : undefined));
    b.onResolve({ filter: /\.css$/ }, () => ({ path: 'css', namespace: 'v' }));
    b.onResolve({ filter: /^(dotenv|path|fs|url|@google\/genai|vite|react|react-dom\/client|react\/jsx-runtime|lucide-react)$/ }, a => ({ path: a.path, namespace: 'v' }));
    b.onLoad({ filter: /.*/, namespace: 'v' }, a => ({ contents: a.path === 'css' ? '' : virtual[a.path], loader: 'js' }));
  },
};

const res = await esbuild.build({
  entryPoints: [path.join(root, 'web-build', 'entry.ts')],
  bundle: true, write: false, format: 'iife', target: 'es2020', minify: true, jsx: 'automatic', charset: 'ascii',
  banner: { js: "var process = { env: { NODE_ENV: 'production' } };" },
  plugins: [plugin], logLevel: 'warning',
});
let js = res.outputFiles[0].text;

// Produktbilder als Begleitdateien neben der Seite (img/...) statt absoluter Vite-Pfade
js = js.split('/src/assets/images/').join('img/');
js = js.replace(/<\/script/gi, '<\\/script');

const cssExtra = fs.readFileSync(path.join(root, 'src', 'index.css'), 'utf8').replace(/@import "tailwindcss";/, '').replace(/@layer base \{([\s\S]*?)\n\}/, '$1');
const html = `<meta charset="utf-8">
<title>Goalsforce Agent</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;600&display=swap">
<script src="https://cdn.tailwindcss.com/3.4.17"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/react/18.3.1/umd/react.production.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/react-dom/18.3.1/umd/react-dom.production.min.js"></script>
<script src="https://unpkg.com/lucide-react@0.546.0/dist/umd/lucide-react.min.js"></script>
<style>
:root { color-scheme: dark; --gf-bg: #020617; --gf-fg: #f1f5f9 }
html, body { background: var(--gf-bg); color: var(--gf-fg) }
body { padding-left: env(safe-area-inset-left, 0px); padding-right: env(safe-area-inset-right, 0px); -webkit-font-smoothing: antialiased }
${cssExtra}
</style>
<div id="root" class="min-h-full flex flex-col"></div>
<script>${js}</script>
`;
fs.writeFileSync(outFile, html);
console.log('icons', icons.size, 'bytes', html.length);
