// Testversion: beantwortet alle /api-Aufrufe im Browser mit der echten Server-Logik aus server.ts.
import { dispatch } from './shims/express';
import '../server';

(window as any).__GF_TEST__ = true;
const original = window.fetch.bind(window);
window.fetch = async (input: RequestInfo | URL, init?: RequestInit) => {
  const url = typeof input === 'string' ? input : input instanceof URL ? input.toString() : input.url;
  const path = url.startsWith(location.origin) ? url.slice(location.origin.length) : url;
  if (!path.startsWith('/api/')) return original(input as any, init);
  let body: unknown = undefined;
  if (init?.body && typeof init.body === 'string') {
    try { body = JSON.parse(init.body); } catch { body = init.body; }
  }
  const r = await dispatch((init?.method || 'GET').toUpperCase(), path, body ?? {}, {});
  return new Response(r.body, { status: r.status, headers: r.headers });
};
