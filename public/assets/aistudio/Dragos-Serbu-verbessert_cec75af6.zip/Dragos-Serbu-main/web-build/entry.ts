import './install-fetch';
import '../src/main.tsx';
