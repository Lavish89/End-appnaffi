// Testversion: E-Mails werden nicht verschickt, sondern im Test-Postfach (localStorage) abgelegt.
import { renderMail, MailKind, MailData } from '../../mail-templates';

export const OUTBOX_KEY = 'gf_test_outbox';
export interface MailLogEntry { at: string; to: string; kind: MailKind; subject: string; status: 'sent' | 'logged' | 'failed'; html: string; text: string }

const read = (): MailLogEntry[] => { try { return JSON.parse(localStorage.getItem(OUTBOX_KEY) || '[]'); } catch { return []; } };

export function createMailer(_dataDir: string) {
  return {
    configured: true,
    log: read,
    async send(to: string, kind: MailKind, data: Omit<MailData, 'appUrl'> & { appUrl?: string }) {
      const m = renderMail(kind, { appUrl: location.href.split('?')[0], ...data } as MailData);
      const entry: MailLogEntry = { at: new Date().toISOString(), to, kind, subject: m.subject, status: 'logged', html: m.html, text: m.text };
      try { localStorage.setItem(OUTBOX_KEY, JSON.stringify([entry, ...read()].slice(0, 50))); } catch { /* */ }
      window.dispatchEvent(new CustomEvent('gf-test-mail', { detail: entry }));
    },
  };
}
