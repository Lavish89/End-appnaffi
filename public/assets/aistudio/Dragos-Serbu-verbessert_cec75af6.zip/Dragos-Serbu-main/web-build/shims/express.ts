// Minimaler Express-Ersatz fuer die Browser-Testversion.
// server.ts registriert seine Routen hier; dispatch() beantwortet fetch('/api/...') direkt im Browser.
type Handler = (req: any, res: any, next: () => void) => any;
interface Layer {
  method: string | null; // null = app.use
  paths: string[];
  prefix: boolean;
  fn: Handler;
}

export interface ShimResponse {
  status: number;
  headers: Record<string, string>;
  body: string;
}

const layers: Layer[] = [];
const settings: Record<string, unknown> = {};

const matches = (l: Layer, method: string, path: string) => {
  if (l.method && l.method !== method) return false;
  return l.paths.some(p => {
    if (p === '*') return true;
    if (l.prefix) return path === p || path.startsWith(p.endsWith('/') ? p : p + '/');
    return path === p;
  });
};

function app() {}
const api: any = app;
api.use = (a: any, b?: any) => {
  const fn: Handler = typeof a === 'function' ? a : b;
  const paths = typeof a === 'function' ? ['/'] : Array.isArray(a) ? a : [a];
  layers.push({ method: null, paths, prefix: true, fn });
  return api;
};
for (const m of ['get', 'post', 'put', 'delete']) {
  api[m] = (path: string, ...fns: Handler[]) => {
    for (const fn of fns) layers.push({ method: m.toUpperCase(), paths: [path], prefix: false, fn });
    return api;
  };
}
api.set = (k: string, v: unknown) => { settings[k] = v; return api; };
api.listen = (_port: unknown, _host: unknown, cb?: () => void) => { cb && cb(); return api; };

export async function dispatch(method: string, url: string, body: unknown, headers: Record<string, string>): Promise<ShimResponse> {
  const u = new URL(url, 'http://local');
  const fullPath = u.pathname;
  return new Promise<ShimResponse>(resolve => {
    const out: ShimResponse = { status: 200, headers: { 'content-type': 'application/json' }, body: '' };
    let done = false;
    const finish = () => { if (!done) { done = true; resolve(out); } };
    const res: any = {
      statusCode: 200,
      status(c: number) { out.status = c; this.statusCode = c; return res; },
      setHeader(k: string, v: string) { out.headers[k.toLowerCase()] = String(v); return res; },
      json(o: unknown) { out.body = JSON.stringify(o); finish(); return res; },
      send(s: unknown) { out.body = typeof s === 'string' ? s : JSON.stringify(s); finish(); return res; },
      redirect(c: number, loc: string) { out.status = c; out.headers.location = loc; finish(); return res; },
      sendFile() { out.status = 404; out.body = JSON.stringify({ success: false, error: 'Datei in der Testversion nicht verfügbar.' }); finish(); return res; },
    };
    const req: any = { method, url: fullPath + u.search, originalUrl: fullPath, path: fullPath, body, headers, ip: 'local', protocol: 'http', get: (h: string) => (h.toLowerCase() === 'host' ? 'local' : headers[h.toLowerCase()]), rawBody: typeof body === 'string' ? body : JSON.stringify(body ?? {}), query: Object.fromEntries(u.searchParams) };
    let i = 0;
    const next = () => {
      if (done) return;
      while (i < layers.length) {
        const l = layers[i++];
        if (!matches(l, method, fullPath)) continue;
        // Wie in Express: bei app.use('/api', fn) sieht fn den Pfad ohne Praefix
        const mount = l.prefix ? l.paths.find(p => p !== '/' && (fullPath === p || fullPath.startsWith(p + '/'))) : undefined;
        req.path = mount ? fullPath.slice(mount.length) || '/' : fullPath;
        try {
          const r = l.fn(req, res, next);
          if (r && typeof r.then === 'function') r.catch((e: any) => { out.status = 500; out.body = JSON.stringify({ success: false, error: e?.message || 'Fehler' }); finish(); });
        } catch (e: any) {
          out.status = 500; out.body = JSON.stringify({ success: false, error: e?.message || 'Fehler' }); finish();
        }
        return;
      }
      out.status = 404; out.body = JSON.stringify({ success: false, error: 'Nicht gefunden' }); finish();
    };
    next();
  });
}

const express: any = () => api;
express.json = () => (_req: any, _res: any, next: () => void) => next();
express.static = () => (_req: any, _res: any, next: () => void) => next();
export default express;
export type Express = any; export type Request = any; export type Response = any; export type NextFunction = any;
