import { FREE_LINK_LIMIT } from '../../src/billing/plans';
// Browser-Variante von server-workspace.ts: Daten pro Konto im localStorage dieses Browsers.
// Kurzlinks (/go/...) und Link-Pruefung brauchen einen echten Server und sind hier deaktiviert.
export const userKey = (id: string) => id.replace(/-/g, '').slice(0, 8);
const key = (id: string) => `gf_test_ws_${id}`;

export function installWorkspace(app: any, opts: { currentUser: (req: any) => { id: string } | undefined }) {
  const me = (req: any) => req.user || opts.currentUser(req);

  app.get('/api/me/workspace', (req: any, res: any) => {
    const u = me(req);
    if (!u) return res.status(401).json({ success: false, error: 'Bitte melde dich an.' });
    let workspace = null;
    try { workspace = JSON.parse(localStorage.getItem(key(u.id)) || 'null'); } catch { /* */ }
    res.json({ success: true, workspace, clicks: {}, userKey: userKey(u.id), testMode: true });
  });

  app.post('/api/me/workspace', (req: any, res: any) => {
    const u = me(req);
    if (!u) return res.status(401).json({ success: false, error: 'Bitte melde dich an.' });
    const ws = req.body?.workspace;
    if (!ws || ws.version !== 1) return res.status(400).json({ success: false, error: 'Ungültige Daten.' });
    if (u.role !== 'owner' && u.effectivePlan !== 'pro' && Array.isArray(ws.links) && ws.links.length > FREE_LINK_LIMIT) {
      return res.status(402).json({ success: false, error: `Mit Free kannst du bis zu ${FREE_LINK_LIMIT} Links speichern. Mit Pro sind es unbegrenzt viele.` });
    }
    try { localStorage.setItem(key(u.id), JSON.stringify(ws)); } catch { return res.status(507).json({ success: false, error: 'Speichern im Browser nicht möglich.' }); }
    res.json({ success: true, savedAt: new Date().toISOString() });
  });

  app.post('/api/me/check-link', (_req: any, res: any) => {
    res.json({ success: false, error: 'Die Link-Prüfung funktioniert nur in der Server-Version der App.' });
  });
}
