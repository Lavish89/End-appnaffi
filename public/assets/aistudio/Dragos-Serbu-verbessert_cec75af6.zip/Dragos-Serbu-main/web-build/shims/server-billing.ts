// Testversion der Mitgliedschaften: statt Stripe gibt es eine Test-Kasse ohne echte Zahlung.
import { DEFAULT_BILLING, BillingSettings, Interval, formatPrice } from '../../src/billing/plans';

const KEY = 'gf_test_billing';
const load = (): BillingSettings => { try { return { ...DEFAULT_BILLING, ...JSON.parse(localStorage.getItem(KEY) || '{}') }; } catch { return { ...DEFAULT_BILLING }; } };

export function installBilling(app: any, opts: { auth: any; mailer: any }) {
  const addPeriod = (i: Interval) => { const d = new Date(); i === 'year' ? d.setFullYear(d.getFullYear() + 1) : d.setMonth(d.getMonth() + 1); return d.toISOString(); };

  app.get('/api/billing/plans', (_req: any, res: any) => res.json({ success: true, settings: load(), paymentsEnabled: true, testMode: true }));

  app.post('/api/billing/checkout', (req: any, res: any) => {
    if (req.body?.acceptTerms !== true) return res.status(400).json({ success: false, error: 'Bitte bestätige AGB und Hinweise zum Widerrufsrecht.' });
    res.json({ success: true, testCheckout: true, interval: req.body?.interval === 'year' ? 'year' : 'month' });
  });

  // Nur Testversion: simuliert eine erfolgreiche Zahlung
  app.post('/api/billing/test-complete', async (req: any, res: any) => {
    const u = opts.auth.getUser(req.user.id);
    const interval: Interval = req.body?.interval === 'year' ? 'year' : 'month';
    const s = load();
    opts.auth.updateUser(u.id, { plan: 'pro', planStatus: 'active', planInterval: interval, planRenewsAt: addPeriod(interval) });
    await opts.mailer.send(u.email, 'payment_thanks', { name: u.profile?.firstName || u.name, plan: `Pro ${interval === 'year' ? 'jährlich' : 'monatlich'}`, amount: formatPrice(interval === 'year' ? s.priceYearCents : s.priceMonthCents) });
    res.json({ success: true });
  });

  app.post('/api/billing/cancel', async (req: any, res: any) => {
    const u = opts.auth.getUser(req.user.id);
    if (u.plan !== 'pro' || u.planStatus === 'canceled') return res.status(400).json({ success: false, error: 'Du hast kein aktives Abo.' });
    opts.auth.updateUser(u.id, { planStatus: u.planRenewsAt ? 'canceling' : 'canceled' });
    await opts.mailer.send(u.email, 'cancel_confirm', { name: u.profile?.firstName || u.name, plan: `Pro ${u.planInterval === 'year' ? 'jährlich' : 'monatlich'}`, until: u.planRenewsAt ? new Date(u.planRenewsAt).toLocaleDateString('de-DE') : undefined });
    res.json({ success: true, until: u.planRenewsAt, receivedAt: new Date().toISOString() });
  });

  app.post('/api/billing/resume', (req: any, res: any) => {
    const u = opts.auth.getUser(req.user.id);
    if (u.planStatus !== 'canceling') return res.status(400).json({ success: false, error: 'Es gibt keine Kündigung, die zurückgenommen werden kann.' });
    opts.auth.updateUser(u.id, { planStatus: 'active' });
    res.json({ success: true });
  });

  app.post('/api/billing/portal', (_req: any, res: any) => res.status(400).json({ success: false, error: 'Das Zahlungsportal gibt es nur mit echter Stripe-Anbindung.' }));

  app.get('/api/admin/billing', (_req: any, res: any) => res.json({ success: true, settings: load(), integrations: { stripe: false, stripeWebhook: false, mail: false, google: false, facebook: false, appUrl: '' }, testMode: true }));
  app.post('/api/admin/billing', (req: any, res: any) => {
    const b = req.body || {};
    const cur = load();
    const cents = (v: unknown, f: number) => { const n = Math.round(Number(v)); return Number.isFinite(n) && n >= 0 && n <= 1_000_000 ? n : f; };
    const next: BillingSettings = { priceMonthCents: cents(b.priceMonthCents, cur.priceMonthCents), priceYearCents: cents(b.priceYearCents, cur.priceYearCents), priceNote: typeof b.priceNote === 'string' ? b.priceNote.slice(0, 200) : cur.priceNote, trialDays: Math.min(60, Math.max(0, Math.round(Number(b.trialDays ?? cur.trialDays)) || 0)) };
    try { localStorage.setItem(KEY, JSON.stringify(next)); } catch { /* */ }
    res.json({ success: true, settings: next });
  });
}
