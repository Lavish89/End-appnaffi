// Browser-Variante von server-auth.ts fuer die Testversion.
// Konten bleiben nur in diesem Browser (localStorage). Passwoerter werden mit PBKDF2 gehasht.
// Gleiche Routen, Rollen, Profile, Passwort-Reset (Link im Test-Postfach) und Admin-Funktionen wie der Server.
import { validateRegistration, roleFor, DEFAULT_OWNER_EMAIL, cleanProfile, passwordProblem } from '../../server-auth-rules';
import { installAdmin } from '../../server-admin';
import { effectivePlan } from '../../src/billing/plans';

const MEMBER_PATHS = ['/me', '/gemini/generate-marketing', '/billing', '/community', '/jobs', '/feedback'];
const PUBLIC_PATHS = ['/auth/', '/health', '/billing/plans', '/billing/webhook'];
type StoredUser = Record<string, any> & { id: string; name: string; email: string; role: 'owner' | 'member'; salt: string; hash: string };
const KEY_USERS = 'gf_test_users';
const KEY_SESSION = 'gf_test_session';
const KEY_SETTINGS = 'gf_test_settings';
const ownerEmail = DEFAULT_OWNER_EMAIL;

const load = (): StoredUser[] => { try { return JSON.parse(localStorage.getItem(KEY_USERS) || '[]'); } catch { return []; } };
const store = (u: StoredUser[]) => { try { localStorage.setItem(KEY_USERS, JSON.stringify(u)); } catch { /* Speicher blockiert */ } };
const getSession = () => { try { return localStorage.getItem(KEY_SESSION); } catch { return null; } };
const setSession = (id: string | null) => { try { id ? localStorage.setItem(KEY_SESSION, id) : localStorage.removeItem(KEY_SESSION); } catch { /* */ } };
const getSettings = (): { registrationOpen: boolean } => { try { return { registrationOpen: true, ...JSON.parse(localStorage.getItem(KEY_SETTINGS) || '{}') }; } catch { return { registrationOpen: true }; } };
const putSettings = (s: { registrationOpen: boolean }) => { try { localStorage.setItem(KEY_SETTINGS, JSON.stringify(s)); } catch { /* */ } };
const toPublic = ({ salt: _s, hash: _h, oauth: _o, ...u }: StoredUser) => ({ ...u, effectivePlan: effectivePlan(u as any), hasPassword: u.hasPassword !== false, providers: [] });
const hex = (b: ArrayBuffer) => Array.from(new Uint8Array(b), x => x.toString(16).padStart(2, '0')).join('');

async function hashPassword(password: string, salt = hex(crypto.getRandomValues(new Uint8Array(16)).buffer)) {
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(password), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt: new TextEncoder().encode(salt), iterations: 150000 }, key, 256);
  return { salt, hash: hex(bits) };
}
const ensureOwner = (u: StoredUser) => {
  if (u.email === ownerEmail && (u.role !== 'owner' || u.disabled)) { u.role = 'owner'; u.disabled = false; return true; }
  return false;
};

export function installAuth(app: any, opts: { mailer: any }) {
  { const all = load(); if (all.map(ensureOwner).some(Boolean)) store(all); }
  const current = () => { const id = getSession(); const u = id ? load().find(x => x.id === id) : undefined; return u && !u.disabled ? u : undefined; };
  const updateUser = (id: string, patch: Record<string, unknown>) => { const all = load(); const u = all.find(x => x.id === id); if (u) { Object.assign(u, patch); store(all); } return u; };
  const resetTokens = new Map<string, { userId: string; expires: number }>();

  app.get('/api/auth/me', (_req: any, res: any) => {
    const u = current();
    res.json({ success: true, user: u ? toPublic(u) : null, registrationOpen: getSettings().registrationOpen || load().length === 0 });
  });
  app.get('/api/auth/providers', (_req: any, res: any) => res.json({ success: true, google: false, facebook: false, passwordReset: true, testMode: true }));

  app.post('/api/auth/register', async (req: any, res: any) => {
    const users = load();
    const wanted = String(req.body?.email ?? '').trim().toLowerCase();
    if (!getSettings().registrationOpen && users.length > 0 && wanted !== ownerEmail) {
      return res.status(403).json({ success: false, error: 'Die Registrierung ist geschlossen. Bitte wende dich an den Inhaber.' });
    }
    const v = validateRegistration(req.body);
    if (typeof v === 'string') return res.status(400).json({ success: false, error: v });
    if (users.some(u => u.email === v.email)) return res.status(409).json({ success: false, error: 'Mit dieser E-Mail-Adresse gibt es schon ein Konto. Bitte melde dich an.' });
    const now = new Date().toISOString();
    const user: StoredUser = { id: crypto.randomUUID(), name: v.name, email: v.email, role: roleFor(v.email, ownerEmail, users.length === 0), createdAt: now, lastLoginAt: now, plan: 'free', profile: cleanProfile(req.body?.profile), hasPassword: true, ...(await hashPassword(v.password)) };
    users.push(user);
    store(users);
    setSession(user.id);
    await opts.mailer.send(user.email, 'welcome', { name: user.profile?.firstName || user.name });
    res.json({ success: true, user: toPublic(user) });
  });

  app.post('/api/auth/login', async (req: any, res: any) => {
    const email = String(req.body?.email ?? '').trim().toLowerCase();
    const users = load();
    const user = users.find(u => u.email === email);
    if (!user || (await hashPassword(String(req.body?.password ?? ''), user.salt)).hash !== user.hash) {
      return res.status(401).json({ success: false, error: 'E-Mail oder Passwort ist falsch.' });
    }
    if (user.disabled && user.email !== ownerEmail) return res.status(403).json({ success: false, error: 'Dieses Konto ist gesperrt. Bitte wende dich an den Inhaber.' });
    ensureOwner(user);
    user.lastLoginAt = new Date().toISOString();
    store(users);
    setSession(user.id);
    res.json({ success: true, user: toPublic(user) });
  });

  app.post('/api/auth/logout', (_req: any, res: any) => { setSession(null); res.json({ success: true }); });

  app.post('/api/auth/forgot', async (req: any, res: any) => {
    const email = String(req.body?.email ?? '').trim().toLowerCase();
    const user = load().find(u => u.email === email && !u.disabled);
    if (user) {
      const token = hex(crypto.getRandomValues(new Uint8Array(24)).buffer);
      resetTokens.set(token, { userId: user.id, expires: Date.now() + 60 * 60_000 });
      await opts.mailer.send(user.email, 'password_reset', { name: user.profile?.firstName || user.name, resetUrl: `${location.href.split('?')[0]}?reset=${token}` });
    }
    res.json({ success: true, message: 'Wenn es ein Konto mit dieser E-Mail gibt, ist ein Link unterwegs.' });
  });
  app.post('/api/auth/reset', async (req: any, res: any) => {
    const t = resetTokens.get(String(req.body?.token ?? ''));
    if (!t || t.expires < Date.now()) return res.status(400).json({ success: false, error: 'Der Link ist abgelaufen oder ungültig. Fordere bitte einen neuen an.' });
    const pw = String(req.body?.password ?? '');
    const problem = passwordProblem(pw);
    if (problem) return res.status(400).json({ success: false, error: problem });
    const u = updateUser(t.userId, { ...(await hashPassword(pw)), hasPassword: true });
    resetTokens.delete(String(req.body.token));
    if (!u) return res.status(400).json({ success: false, error: 'Konto nicht gefunden.' });
    setSession(u.id);
    res.json({ success: true, user: toPublic(u) });
  });

  app.post('/api/auth/change-password', async (req: any, res: any) => {
    const u = current();
    if (!u) return res.status(401).json({ success: false, error: 'Bitte melde dich an.' });
    if ((await hashPassword(String(req.body?.currentPassword ?? ''), u.salt)).hash !== u.hash) return res.status(400).json({ success: false, error: 'Das aktuelle Passwort ist falsch.' });
    const problem = passwordProblem(String(req.body?.newPassword ?? ''));
    if (problem) return res.status(400).json({ success: false, error: problem });
    updateUser(u.id, await hashPassword(String(req.body.newPassword)));
    res.json({ success: true });
  });

  app.use('/api', (req: any, res: any, next: () => void) => {
    if (PUBLIC_PATHS.some(p => req.path === p || req.path.startsWith(p))) return next();
    const u = current();
    if (!u) return res.status(401).json({ success: false, error: 'Bitte melde dich an.' });
    req.user = toPublic(u);
    if (u.role !== 'owner' && !MEMBER_PATHS.some(p => req.path === p || req.path.startsWith(p + '/'))) {
      return res.status(403).json({ success: false, error: 'Dieser Bereich ist nur für den Inhaber.' });
    }
    next();
  });

  app.post('/api/me/profile', (req: any, res: any) => {
    const u = current()!;
    const name = String(req.body?.name ?? '').trim().slice(0, 80);
    const next = updateUser(u.id, { ...(name.length >= 2 ? { name } : {}), profile: cleanProfile({ ...(u.profile || {}), ...(req.body?.profile || {}) }) });
    res.json({ success: true, user: toPublic(next!) });
  });

  installAdmin(app, {
    ownerEmail,
    list: () => load().map(toPublic) as any,
    update: (id, patch) => { updateUser(id, patch as any); },
    remove: id => { store(load().filter(x => x.id !== id)); try { localStorage.removeItem(`gf_test_ws_${id}`); } catch { /* */ } },
    setPassword: async (id, pw) => { updateUser(id, { ...(await hashPassword(pw)), hasPassword: true }); },
    dropSessions: id => { if (getSession() === id) setSession(null); },
    getRegistrationOpen: () => getSettings().registrationOpen,
    setRegistrationOpen: v => putSettings({ ...getSettings(), registrationOpen: v }),
    workspaceStats: id => {
      try {
        const ws = JSON.parse(localStorage.getItem(`gf_test_ws_${id}`) || 'null');
        if (!ws) return null;
        return { links: ws.links?.length || 0, clicks: 0, earnings: (ws.earnings || []).filter((e: any) => e.status !== 'storniert').reduce((s: number, e: any) => s + (Number(e.amount) || 0), 0) };
      } catch { return null; }
    },
    mailLog: () => opts.mailer.log(),
  });

  return {
    currentUser: () => { const u = current(); return u ? toPublic(u) : undefined; },
    getUser: (id: string) => load().find(u => u.id === id),
    updateUser,
  };
}
