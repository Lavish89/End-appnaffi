// Testversion: Anmelden mit Google/Facebook braucht einen echten Server mit OAuth-Zugangsdaten.
export function installOAuth(_app: unknown, _auth: unknown) { /* nicht verfuegbar */ }
