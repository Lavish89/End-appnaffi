// Testversion: Speicher im localStorage dieses Browsers.
import type { KV } from '../../server-community';
export function createKV(_dir: string): KV {
  return {
    get<T>(key: string, fallback: T): T { try { const v = localStorage.getItem(`gf_test_kv_${key}`); return v ? JSON.parse(v) : fallback; } catch { return fallback; } },
    set(key: string, value: unknown) { try { localStorage.setItem(`gf_test_kv_${key}`, JSON.stringify(value)); } catch { /* */ } },
  };
}
