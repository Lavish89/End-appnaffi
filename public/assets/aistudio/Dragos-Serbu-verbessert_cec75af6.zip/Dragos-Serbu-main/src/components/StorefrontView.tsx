import React, { useState } from 'react';
import { 
  ShoppingBag, 
  Search, 
  Menu, 
  X, 
  ShieldCheck, 
  Truck, 
  RotateCcw, 
  Check, 
  Plus, 
  Minus, 
  Trash2, 
  ArrowRight, 
  Smartphone, 
  Monitor, 
  Sparkles,
  ChevronDown,
  Lock,
  Tag
} from 'lucide-react';
import { CATALOG_PRODUCTS, ASSET_IMAGES } from '../data/ecommerceData';
import { CatalogProduct } from '../types';
import { LegalPagesModal } from './LegalPagesModal';

interface CartItem {
  product: CatalogProduct;
  selectedVariants: { [key: string]: string };
  quantity: number;
}

export const StorefrontView: React.FC = () => {
  const [deviceMode, setDeviceMode] = useState<'desktop' | 'mobile'>('desktop');
  const [activeCategory, setActiveCategory] = useState<string>('Alle');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedProduct, setSelectedProduct] = useState<CatalogProduct | null>(null);
  const [selectedVariants, setSelectedVariants] = useState<{ [key: string]: string }>({});
  const [cart, setCart] = useState<CartItem[]>([
    {
      product: CATALOG_PRODUCTS[0],
      selectedVariants: { 'Farbe': 'Saddle Brown & Charcoal', 'Größe': 'Medium (80 × 40 cm)' },
      quantity: 1,
    }
  ]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isLegalModalOpen, setIsLegalModalOpen] = useState(false);
  const [legalModalTab, setLegalModalTab] = useState<'impressum' | 'datenschutz' | 'agb' | 'versand' | 'faq'>('impressum');
  
  // Voucher code state
  const [voucherCode, setVoucherCode] = useState('');
  const [appliedDiscount, setAppliedDiscount] = useState<number>(0);
  const [voucherMessage, setVoucherMessage] = useState<string | null>(null);

  // Simulated Checkout state
  const [isCheckoutModalOpen, setIsCheckoutModalOpen] = useState(false);
  const [orderConfirmed, setOrderConfirmed] = useState(false);

  // Calculate cart totals
  const subtotal = cart.reduce((acc, item) => acc + item.product.price * item.quantity, 0);
  const discountAmount = subtotal * appliedDiscount;
  const freeShippingThreshold = 50.0;
  const freeShippingLeft = Math.max(0, freeShippingThreshold - subtotal);
  const shippingFee = subtotal >= freeShippingThreshold || subtotal === 0 ? 0 : 3.90;
  const total = Math.max(0, subtotal - discountAmount + shippingFee);
  const totalItemCount = cart.reduce((acc, item) => acc + item.quantity, 0);

  const handleOpenProduct = (p: CatalogProduct) => {
    setSelectedProduct(p);
    const initialVariants: { [key: string]: string } = {};
    p.variants.forEach(v => {
      initialVariants[v.name] = v.options[0];
    });
    setSelectedVariants(initialVariants);
  };

  const handleAddToCart = (product: CatalogProduct) => {
    setCart(prev => {
      const existing = prev.find(item => 
        item.product.id === product.id && 
        JSON.stringify(item.selectedVariants) === JSON.stringify(selectedVariants)
      );
      if (existing) {
        return prev.map(item => 
          item === existing ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prev, { product, selectedVariants: { ...selectedVariants }, quantity: 1 }];
    });
    setIsCartOpen(true);
    setSelectedProduct(null);
  };

  const handleApplyVoucher = () => {
    if (voucherCode.trim().toUpperCase() === 'WELCOME10') {
      setAppliedDiscount(0.10);
      setVoucherMessage('Gutscheincode WELCOME10 erfolgreich eingelöst (-10%)');
    } else {
      setVoucherMessage('Ungültiger Code. Bitte teste "WELCOME10"');
    }
  };

  const handleCompleteOrder = () => {
    setOrderConfirmed(true);
    setTimeout(() => {
      setCart([]);
      setIsCheckoutModalOpen(false);
      setOrderConfirmed(false);
      setIsCartOpen(false);
    }, 2500);
  };

  const filteredCatalog = CATALOG_PRODUCTS.filter(p => {
    const matchesCat = activeCategory === 'Alle' || p.category === activeCategory;
    const matchesQuery = p.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
      p.subtitle.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesQuery;
  });

  return (
    <div className="space-y-4 max-w-7xl mx-auto pb-12">
      {/* Device Toolbar & Staging Control */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-3 rounded-2xl">
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-slate-200">Shopify Theme Vorschau:</span>
          <span className="text-xs bg-amber-500/10 text-amber-400 border border-amber-500/20 px-2 py-0.5 rounded-md font-mono">
            Aura Minimalist v2.4 (Unveröffentlicht - Staged)
          </span>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400">Gerät:</span>
          <div className="flex items-center bg-slate-950 p-1 rounded-lg border border-slate-800">
            <button
              onClick={() => setDeviceMode('desktop')}
              className={`flex items-center gap-1.5 px-3 py-1 text-xs font-medium rounded-md transition-colors ${
                deviceMode === 'desktop' ? 'bg-amber-400 text-slate-950 font-semibold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Monitor className="w-3.5 h-3.5" />
              Desktop
            </button>
            <button
              onClick={() => setDeviceMode('mobile')}
              className={`flex items-center gap-1.5 px-3 py-1 text-xs font-medium rounded-md transition-colors ${
                deviceMode === 'mobile' ? 'bg-amber-400 text-slate-950 font-semibold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Smartphone className="w-3.5 h-3.5" />
              Smartphone
            </button>
          </div>
        </div>
      </div>

      {/* Frame Container */}
      <div className={`mx-auto transition-all duration-300 ${deviceMode === 'mobile' ? 'max-w-[410px]' : 'w-full'}`}>
        <div className="bg-slate-950 text-slate-100 rounded-2xl border border-slate-800 shadow-2xl overflow-hidden flex flex-col min-h-[840px]">
          
          {/* Top Announcement Bar */}
          <div className="bg-slate-900 border-b border-slate-800/80 px-4 py-2 text-center text-xs font-medium text-slate-300 flex items-center justify-center gap-2 sm:gap-4 flex-wrap">
            <span className="flex items-center gap-1.5 text-amber-400 font-semibold">
              <Truck className="w-3.5 h-3.5" />
              Kostenloser DHL Versand ab 50 €
            </span>
            <span className="hidden sm:inline text-slate-600">·</span>
            <span className="hidden sm:flex items-center gap-1.5 text-slate-300">
              <RotateCcw className="w-3.5 h-3.5 text-emerald-400" />
              30 Tage Zufriedenheitsgarantie
            </span>
            <span className="hidden sm:inline text-slate-600">·</span>
            <span className="hidden md:inline text-slate-400">
              Code: <strong className="text-amber-300">WELCOME10</strong> für 10% Rabatt
            </span>
          </div>

          {/* Storefront Navigation Bar */}
          <nav className="flex items-center justify-between gap-4 px-6 py-4 border-b border-slate-800/80 bg-slate-950 sticky top-0 z-20">
            {/* Brand Logo */}
            <a href="#home" className="text-xl font-bold tracking-tight text-white whitespace-nowrap shrink-0">
              AURA
            </a>

            {/* Navigation links (Desktop) */}
            <div className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-400">
              <button 
                onClick={() => setActiveCategory('Alle')} 
                className={`hover:text-white transition-colors ${activeCategory === 'Alle' ? 'text-amber-400 font-semibold' : ''}`}
              >
                Alle Produkte
              </button>
              <button 
                onClick={() => setActiveCategory('Workspace')} 
                className={`hover:text-white transition-colors ${activeCategory === 'Workspace' ? 'text-amber-400 font-semibold' : ''}`}
              >
                Workspace
              </button>
              <button 
                onClick={() => setActiveCategory('Ergonomie')} 
                className={`hover:text-white transition-colors ${activeCategory === 'Ergonomie' ? 'text-amber-400 font-semibold' : ''}`}
              >
                Ergonomie
              </button>
              <button 
                onClick={() => setActiveCategory('Tech & Lifestyle')} 
                className={`hover:text-white transition-colors ${activeCategory === 'Tech & Lifestyle' ? 'text-amber-400 font-semibold' : ''}`}
              >
                Tech & Laden
              </button>
            </div>

            {/* Actions */}
            <div className="flex items-center gap-3">
              <div className="relative hidden sm:block w-40 md:w-52">
                <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Suchen..."
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg pl-8 pr-2.5 py-1 text-xs text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-amber-500"
                />
              </div>

              <button
                onClick={() => setIsCartOpen(true)}
                className="relative p-2 text-slate-300 hover:text-white rounded-lg hover:bg-slate-900 transition-colors"
                aria-label="Warenkorb öffnen"
              >
                <ShoppingBag className="w-5 h-5" />
                {totalItemCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-amber-400 text-slate-950 font-bold text-[10px] w-4 h-4 rounded-full flex items-center justify-center font-mono">
                    {totalItemCount}
                  </span>
                )}
              </button>
            </div>
          </nav>

          {/* Hero Section */}
          <div className="relative border-b border-slate-800 overflow-hidden bg-slate-900">
            <div className="grid grid-cols-1 lg:grid-cols-2 items-stretch min-h-[380px]">
              {/* Text content */}
              <div className="p-8 sm:p-12 flex flex-col justify-center space-y-4 z-10">
                <div className="text-xs font-mono text-amber-400 tracking-wider">
                  KOLLEKTION 2026 · WORKSPACE & ERGONOMIE
                </div>
                <h2 className="text-2xl sm:text-4xl font-bold tracking-tight text-white leading-tight">
                  Gestalte deinen Arbeitsplatz für maximale Produktivität.
                </h2>
                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed max-w-lg">
                  Minimalistische Schreibtisch-Accessoires und orthopädische Helfer aus edlem Naturholz, pflanzlichem Leder und Premium-Materialien. Schnellversand direkt aus Deutschland.
                </p>
                <div className="pt-2 flex items-center gap-3">
                  <a
                    href="#collection"
                    className="px-5 py-2.5 bg-amber-400 hover:bg-amber-300 text-slate-950 font-semibold text-xs rounded-xl transition-colors whitespace-nowrap shadow-md"
                  >
                    Kollektion ansehen
                  </a>
                  <button
                    onClick={() => {
                      setLegalModalTab('versand');
                      setIsLegalModalOpen(true);
                    }}
                    className="px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-slate-300 font-medium text-xs rounded-xl border border-slate-800 transition-colors whitespace-nowrap"
                  >
                    Versanddetails (DHL 2-4 Tage)
                  </button>
                </div>
              </div>

              {/* Hero Image */}
              <div className="relative h-64 lg:h-auto min-h-[280px]">
                <img
                  src={ASSET_IMAGES.hero}
                  alt="Minimalist Home Office Workspace"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t lg:bg-gradient-to-r from-slate-950/70 via-transparent to-transparent" />
              </div>
            </div>
          </div>

          {/* Trust Banner Bar */}
          <div className="grid grid-cols-1 sm:grid-cols-3 divide-y sm:divide-y-0 sm:divide-x divide-slate-800/80 border-b border-slate-800 bg-slate-900/40 text-xs">
            <div className="p-3.5 flex items-center justify-center gap-2.5 text-slate-300">
              <Truck className="w-4 h-4 text-amber-400 shrink-0" />
              <span><strong>Schneller DHL Versand</strong> (2–4 Tage aus Frankfurt)</span>
            </div>
            <div className="p-3.5 flex items-center justify-center gap-2.5 text-slate-300">
              <RotateCcw className="w-4 h-4 text-emerald-400 shrink-0" />
              <span><strong>30 Tage Probeschlafen / Testen</strong> mit Retoure</span>
            </div>
            <div className="p-3.5 flex items-center justify-center gap-2.5 text-slate-300">
              <ShieldCheck className="w-4 h-4 text-sky-400 shrink-0" />
              <span><strong>Rechtssicher nach EU & GPSR 2024</strong> zertifiziert</span>
            </div>
          </div>

          {/* Product Collection Grid */}
          <section id="collection" className="p-6 sm:p-10 space-y-6 flex-1">
            <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
              <div>
                <h3 className="text-xl font-bold text-white tracking-tight">Kuratierte Essentials</h3>
                <p className="text-xs text-slate-400 mt-1">Ausgewählte Favoriten mit herausragender Haptik und Funktion</p>
              </div>

              {/* Category Filter Pills */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
                {['Alle', 'Workspace', 'Ergonomie', 'Tech & Lifestyle', 'Alltag & Sport'].map(cat => (
                  <button
                    key={cat}
                    onClick={() => setActiveCategory(cat)}
                    className={`px-3 py-1.5 text-xs font-medium rounded-lg whitespace-nowrap transition-colors ${
                      activeCategory === cat 
                        ? 'bg-amber-400 text-slate-950 font-semibold' 
                        : 'text-slate-400 hover:text-white bg-slate-900/80 hover:bg-slate-800'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            {/* Product Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {filteredCatalog.map(product => (
                <div
                  key={product.id}
                  onClick={() => handleOpenProduct(product)}
                  className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-2xl overflow-hidden cursor-pointer transition-all hover:-translate-y-1 group flex flex-col justify-between"
                >
                  <div className="relative aspect-[4/3] bg-slate-950 overflow-hidden">
                    <img
                      src={product.image}
                      alt={product.title}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    {product.compareAtPrice > product.price && (
                      <span className="absolute top-2.5 left-2.5 bg-amber-400 text-slate-950 font-bold text-[10px] font-mono px-2 py-0.5 rounded shadow">
                        Sparen: {(product.compareAtPrice - product.price).toFixed(2)} €
                      </span>
                    )}
                  </div>

                  <div className="p-4 space-y-2 flex-1 flex flex-col justify-between">
                    <div>
                      <div className="text-[11px] text-slate-400 font-medium">{product.category}</div>
                      <h4 className="text-sm font-semibold text-slate-100 group-hover:text-amber-400 transition-colors line-clamp-1">
                        {product.title}
                      </h4>
                      <p className="text-xs text-slate-400 line-clamp-2 mt-1">
                        {product.subtitle}
                      </p>
                    </div>

                    <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between">
                      <div className="font-mono tabular-nums">
                        <span className="text-base font-bold text-white">{product.price.toFixed(2)} €</span>
                        {product.compareAtPrice > product.price && (
                          <span className="text-xs text-slate-500 line-through ml-2">
                            {product.compareAtPrice.toFixed(2)} €
                          </span>
                        )}
                      </div>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleOpenProduct(product);
                        }}
                        className="px-3 py-1.5 bg-slate-800 hover:bg-amber-400 hover:text-slate-950 text-slate-200 font-semibold text-xs rounded-lg transition-colors"
                      >
                        Optionen
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* Footer with German Legal Links */}
          <footer className="border-t border-slate-800 bg-slate-950 px-6 py-8 text-xs text-slate-400 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="space-y-2">
                <div className="text-sm font-bold text-white">AURA STUDIO</div>
                <p className="text-slate-400 text-xs leading-relaxed">
                  Design-getriebene Schreibtisch- und Ergonomie-Ausstattung für den deutschsprachigen Raum.
                </p>
              </div>

              <div className="space-y-1.5">
                <div className="font-semibold text-slate-200">Rechtliches & Schutz</div>
                <div>
                  <button onClick={() => { setLegalModalTab('impressum'); setIsLegalModalOpen(true); }} className="hover:text-amber-400">
                    Impressum (§ 5 TMG)
                  </button>
                </div>
                <div>
                  <button onClick={() => { setLegalModalTab('datenschutz'); setIsLegalModalOpen(true); }} className="hover:text-amber-400">
                    Datenschutzerklärung (DSGVO)
                  </button>
                </div>
                <div>
                  <button onClick={() => { setLegalModalTab('agb'); setIsLegalModalOpen(true); }} className="hover:text-amber-400">
                    AGB & Widerrufsbelehrung
                  </button>
                </div>
              </div>

              <div className="space-y-1.5">
                <div className="font-semibold text-slate-200">Kundenservice</div>
                <div>
                  <button onClick={() => { setLegalModalTab('versand'); setIsLegalModalOpen(true); }} className="hover:text-amber-400">
                    Versand- & Zahlungsarten
                  </button>
                </div>
                <div>
                  <button onClick={() => { setLegalModalTab('faq'); setIsLegalModalOpen(true); }} className="hover:text-amber-400">
                    Häufige Fragen (FAQ)
                  </button>
                </div>
                <div className="text-slate-500 pt-1">
                  support@aura-workspace.de
                </div>
              </div>

              <div className="space-y-1.5">
                <div className="font-semibold text-slate-200">Sichere Bezahlung</div>
                <p className="text-slate-400 text-xs">
                  PayPal · Klarna Rechnung · Visa · Mastercard · Apple Pay · DHL GOGREEN
                </p>
                <div className="text-[11px] text-emerald-400 flex items-center gap-1.5 pt-1">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  SSL-256 Bit Verschlüsselung
                </div>
              </div>
            </div>

            <div className="border-t border-slate-800/80 pt-4 flex flex-col sm:flex-row items-center justify-between gap-2 text-slate-500 text-[11px]">
              <div>© 2026 Aura Studio GmbH i.G. Alle Rechte vorbehalten.</div>
              <div>Entwickelt vom autonomen Shopify E-Commerce Agenten</div>
            </div>
          </footer>
        </div>
      </div>

      {/* Slide-out Cart Drawer with Free Shipping Tier */}
      {isCartOpen && (
        <div className="fixed inset-0 z-50 overflow-hidden bg-black/70 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="absolute inset-y-0 right-0 max-w-full flex pl-10">
            <div className="w-screen max-w-md bg-slate-900 border-l border-slate-800 shadow-2xl flex flex-col">
              {/* Drawer Header */}
              <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950">
                <div className="flex items-center gap-2">
                  <ShoppingBag className="w-5 h-5 text-amber-400" />
                  <h3 className="font-bold text-slate-100 text-base">Dein Warenkorb ({totalItemCount})</h3>
                </div>
                <button
                  onClick={() => setIsCartOpen(false)}
                  className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Dynamic Free Shipping Progress Bar */}
              <div className="bg-slate-950/80 px-6 py-3 border-b border-slate-800 space-y-1.5">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-300">
                    {freeShippingLeft > 0 ? (
                      <>Noch <strong className="text-amber-400 font-mono tabular-nums">{freeShippingLeft.toFixed(2)} €</strong> bis zum kostenlosen DHL Versand</>
                    ) : (
                      <span className="text-emerald-400 font-semibold flex items-center gap-1">
                        <Check className="w-3.5 h-3.5" /> Du hast kostenlosen DHL Versand freigeschaltet!
                      </span>
                    )}
                  </span>
                  <span className="text-slate-500 font-mono text-[11px]">50,00 € Ziel</span>
                </div>
                <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div
                    className="bg-amber-400 h-full transition-all duration-300"
                    style={{ width: `${Math.min(100, (subtotal / freeShippingThreshold) * 100)}%` }}
                  />
                </div>
              </div>

              {/* Items List */}
              <div className="flex-1 overflow-y-auto p-6 space-y-4">
                {cart.length === 0 ? (
                  <div className="text-center py-12 space-y-3">
                    <ShoppingBag className="w-12 h-12 text-slate-600 mx-auto" />
                    <p className="text-sm text-slate-400">Dein Warenkorb ist derzeit leer.</p>
                    <button
                      onClick={() => setIsCartOpen(false)}
                      className="px-4 py-2 bg-amber-400 text-slate-950 font-semibold text-xs rounded-xl"
                    >
                      Jetzt stöbern
                    </button>
                  </div>
                ) : (
                  cart.map((item, idx) => (
                    <div key={idx} className="flex gap-4 p-3 bg-slate-950 rounded-xl border border-slate-800">
                      <img
                        src={item.product.image}
                        alt={item.product.title}
                        className="w-16 h-16 object-cover rounded-lg bg-slate-900 shrink-0"
                      />
                      <div className="flex-1 min-w-0 space-y-1">
                        <div className="flex items-start justify-between">
                          <h4 className="text-xs font-semibold text-slate-100 truncate">{item.product.title}</h4>
                          <button
                            onClick={() => setCart(prev => prev.filter((_, i) => i !== idx))}
                            className="text-slate-500 hover:text-rose-400 transition-colors p-1"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                        <div className="text-[11px] text-slate-400">
                          {Object.entries(item.selectedVariants).map(([k, v]) => `${k}: ${v}`).join(' · ')}
                        </div>
                        <div className="flex items-center justify-between pt-1">
                          <div className="flex items-center border border-slate-800 rounded bg-slate-900 text-xs">
                            <button
                              onClick={() => {
                                if (item.quantity > 1) {
                                  setCart(prev => prev.map((it, i) => i === idx ? { ...it, quantity: it.quantity - 1 } : it));
                                } else {
                                  setCart(prev => prev.filter((_, i) => i !== idx));
                                }
                              }}
                              className="px-2 py-0.5 text-slate-400 hover:text-white"
                            >
                              -
                            </button>
                            <span className="px-2 font-mono tabular-nums text-slate-200">{item.quantity}</span>
                            <button
                              onClick={() => setCart(prev => prev.map((it, i) => i === idx ? { ...it, quantity: it.quantity + 1 } : it))}
                              className="px-2 py-0.5 text-slate-400 hover:text-white"
                            >
                              +
                            </button>
                          </div>
                          <span className="font-mono text-xs font-bold text-white tabular-nums">
                            {(item.product.price * item.quantity).toFixed(2)} €
                          </span>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>

              {/* Drawer Footer with Totals & Checkout */}
              {cart.length > 0 && (
                <div className="p-6 border-t border-slate-800 bg-slate-950 space-y-3">
                  {/* Voucher Input */}
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={voucherCode}
                      onChange={(e) => setVoucherCode(e.target.value)}
                      placeholder="Gutscheincode (z.B. WELCOME10)"
                      className="flex-1 bg-slate-900 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-200 uppercase font-mono focus:outline-none focus:border-amber-500"
                    />
                    <button
                      onClick={handleApplyVoucher}
                      className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-xs text-slate-200 font-medium rounded-lg"
                    >
                      Anwenden
                    </button>
                  </div>
                  {voucherMessage && (
                    <div className={`text-[11px] ${appliedDiscount > 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                      {voucherMessage}
                    </div>
                  )}

                  {/* Pricing Breakdown */}
                  <div className="space-y-1.5 font-mono text-xs pt-2 border-t border-slate-800/80">
                    <div className="flex justify-between text-slate-400">
                      <span>Zwischensumme:</span>
                      <span>{subtotal.toFixed(2)} €</span>
                    </div>
                    {appliedDiscount > 0 && (
                      <div className="flex justify-between text-emerald-400">
                        <span>Rabatt (10%):</span>
                        <span>- {discountAmount.toFixed(2)} €</span>
                      </div>
                    )}
                    <div className="flex justify-between text-slate-400">
                      <span>DHL Versand DE:</span>
                      <span>{shippingFee === 0 ? <span className="text-emerald-400">Kostenlos</span> : `${shippingFee.toFixed(2)} €`}</span>
                    </div>
                    <div className="flex justify-between text-white font-bold text-sm pt-1 border-t border-slate-800">
                      <span>Gesamtbetrag (inkl. MwSt.):</span>
                      <span className="text-amber-400">{total.toFixed(2)} €</span>
                    </div>
                  </div>

                  <button
                    onClick={() => setIsCheckoutModalOpen(true)}
                    className="w-full py-3 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs rounded-xl transition-colors flex items-center justify-center gap-2 shadow-lg"
                  >
                    <Lock className="w-4 h-4" />
                    <span>Zur sicheren Kasse ({total.toFixed(2)} €)</span>
                  </button>

                  <div className="text-[10px] text-center text-slate-500 flex items-center justify-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                    <span>14 Tage Widerrufsrecht · SSL 256-Bit verschlüsselt</span>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Product Detail Modal (PDP) with Contiguous Purchase Module */}
      {selectedProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-3xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
            <div className="flex justify-end p-3 border-b border-slate-800 bg-slate-950">
              <button
                onClick={() => setSelectedProduct(null)}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Product Gallery Left */}
              <div className="space-y-3">
                <div className="aspect-[4/3] rounded-xl overflow-hidden bg-slate-950 border border-slate-800">
                  <img
                    src={selectedProduct.image}
                    alt={selectedProduct.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 text-xs text-slate-400 space-y-1">
                  <div className="text-slate-200 font-semibold">Spezifikationen:</div>
                  {Object.entries(selectedProduct.specs).map(([k, v]) => (
                    <div key={k} className="flex justify-between py-0.5">
                      <span className="text-slate-500">{k}:</span>
                      <span className="text-slate-300 font-mono text-[11px]">{v}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Contiguous Purchase Module Right */}
              <div className="space-y-4 flex flex-col justify-between">
                <div className="space-y-3">
                  <div>
                    <span className="text-[11px] text-amber-400 font-mono">{selectedProduct.category}</span>
                    <h3 className="text-lg font-bold text-white mt-0.5">{selectedProduct.title}</h3>
                    <p className="text-xs text-slate-400 mt-1">{selectedProduct.subtitle}</p>
                  </div>

                  {/* Price */}
                  <div className="flex items-baseline gap-2 font-mono">
                    <span className="text-xl font-bold text-white">{selectedProduct.price.toFixed(2)} €</span>
                    {selectedProduct.compareAtPrice > selectedProduct.price && (
                      <span className="text-xs text-slate-500 line-through">
                        {selectedProduct.compareAtPrice.toFixed(2)} €
                      </span>
                    )}
                    <span className="text-[11px] text-emerald-400 font-sans">inkl. MwSt.</span>
                  </div>

                  {/* Stock Indicator */}
                  <div className="text-xs text-emerald-400 flex items-center gap-1.5 font-medium">
                    <Check className="w-3.5 h-3.5" />
                    Auf Lager ({selectedProduct.inventory} Stück im Hub Frankfurt) · Lieferbar in 2-3 Werktagen
                  </div>

                  {/* Variant Selectors */}
                  {selectedProduct.variants.map((v) => (
                    <div key={v.name} className="space-y-1.5">
                      <label className="text-xs text-slate-400 font-medium">{v.name}:</label>
                      <div className="flex flex-wrap gap-2">
                        {v.options.map((opt) => (
                          <button
                            key={opt}
                            onClick={() => setSelectedVariants(prev => ({ ...prev, [v.name]: opt }))}
                            className={`px-3 py-1.5 text-xs rounded-lg border transition-colors ${
                              selectedVariants[v.name] === opt
                                ? 'bg-amber-400 text-slate-950 font-bold border-amber-400'
                                : 'bg-slate-950 text-slate-300 border-slate-800 hover:border-slate-700'
                            }`}
                          >
                            {opt}
                          </button>
                        ))}
                      </div>
                    </div>
                  ))}

                  {/* Description & Bullet points */}
                  <div className="space-y-2 pt-2 border-t border-slate-800 text-xs text-slate-300 leading-relaxed">
                    <p>{selectedProduct.description}</p>
                    <ul className="space-y-1 text-slate-400 list-disc list-inside">
                      {selectedProduct.bulletPoints.map((bp, i) => (
                        <li key={i}><span className="text-slate-300">{bp}</span></li>
                      ))}
                    </ul>
                  </div>
                </div>

                {/* Primary CTA */}
                <div className="pt-4 border-t border-slate-800 space-y-2">
                  <button
                    onClick={() => handleAddToCart(selectedProduct)}
                    className="w-full py-3 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs rounded-xl transition-colors flex items-center justify-center gap-2 shadow-lg"
                  >
                    <ShoppingBag className="w-4 h-4" />
                    <span>In den Warenkorb ({selectedProduct.price.toFixed(2)} €)</span>
                  </button>
                  <p className="text-[10px] text-center text-slate-500">
                    Kostenloser DHL Rückversand innerhalb von 30 Tagen
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Simulated Checkout Confirmation Modal */}
      {isCheckoutModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md p-6 space-y-5 shadow-2xl text-center">
            {orderConfirmed ? (
              <div className="py-6 space-y-3">
                <div className="w-12 h-12 bg-emerald-500/20 text-emerald-400 rounded-full flex items-center justify-center mx-auto">
                  <Check className="w-6 h-6" />
                </div>
                <h3 className="text-lg font-bold text-white">Bestellung erfolgreich bestätigt!</h3>
                <p className="text-xs text-slate-400">
                  Bestellnummer #AUR-8942 · DHL Trackingcode wird an deine E-Mail gesendet.
                </p>
              </div>
            ) : (
              <>
                <div className="space-y-2">
                  <div className="w-10 h-10 bg-amber-500/20 text-amber-400 rounded-full flex items-center justify-center mx-auto">
                    <Lock className="w-5 h-5" />
                  </div>
                  <h3 className="text-base font-bold text-white">Shopify One-Click Checkout Simulation</h3>
                  <p className="text-xs text-slate-400">
                    Sichere Zahlung via Shopify Payments / PayPal / Klarna
                  </p>
                </div>

                <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 text-left text-xs space-y-1.5 font-mono">
                  <div className="flex justify-between text-slate-400">
                    <span>Artikel ({totalItemCount}):</span>
                    <span>{subtotal.toFixed(2)} €</span>
                  </div>
                  {appliedDiscount > 0 && (
                    <div className="flex justify-between text-emerald-400">
                      <span>Rabatt WELCOME10:</span>
                      <span>- {discountAmount.toFixed(2)} €</span>
                    </div>
                  )}
                  <div className="flex justify-between text-slate-400">
                    <span>DHL Versand DE:</span>
                    <span>{shippingFee === 0 ? '0,00 € (Kostenlos)' : `${shippingFee.toFixed(2)} €`}</span>
                  </div>
                  <div className="flex justify-between text-white font-bold text-sm pt-2 border-t border-slate-800">
                    <span>Gesamtbetrag:</span>
                    <span className="text-amber-400">{total.toFixed(2)} €</span>
                  </div>
                </div>

                <div className="space-y-2">
                  <button
                    onClick={handleCompleteOrder}
                    className="w-full py-3 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs rounded-xl transition-colors shadow-lg"
                  >
                    Zahlungspflichtig bestellen ({total.toFixed(2)} €)
                  </button>
                  <button
                    onClick={() => setIsCheckoutModalOpen(false)}
                    className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs rounded-xl"
                  >
                    Abbrechen
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* Legal Pages Modal */}
      <LegalPagesModal
        isOpen={isLegalModalOpen}
        onClose={() => setIsLegalModalOpen(false)}
        initialTab={legalModalTab}
      />
    </div>
  );
};
