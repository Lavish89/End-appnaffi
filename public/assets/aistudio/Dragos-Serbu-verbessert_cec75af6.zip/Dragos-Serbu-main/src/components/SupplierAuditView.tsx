import React, { useState } from 'react';
import { Truck, CheckCircle2, ShieldAlert, Clock, RefreshCw, Box, AlertTriangle, ArrowRight } from 'lucide-react';
import { SUPPLIERS } from '../data/ecommerceData';
import { Supplier } from '../types';

export const SupplierAuditView: React.FC = () => {
  const [selectedHub, setSelectedHub] = useState<Supplier>(SUPPLIERS[0]);

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Header */}
      <div>
        <div className="text-xs font-mono text-amber-400">PHASE 3 · LIEFERANTEN & FULFILLMENT</div>
        <h1 className="text-2xl font-bold text-slate-100 tracking-tight mt-1">
          Geprüfte Lieferanten & EU-Fulfillment-Hubs
        </h1>
        <p className="text-xs text-slate-400 mt-1 max-w-2xl">
          Lieferzeiten nach Deutschland, automatische Bestandssynchronisation, Retourenabwicklung und Qualitätskontrollen ohne teure Vorab-Fixkosten.
        </p>
      </div>

      {/* Supplier Hubs Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {SUPPLIERS.map((sup) => (
          <div
            key={sup.id}
            onClick={() => setSelectedHub(sup)}
            className={`border rounded-2xl p-5 cursor-pointer transition-all space-y-4 ${
              selectedHub.id === sup.id
                ? 'bg-slate-900 border-amber-500/80 shadow-lg ring-1 ring-amber-500/30'
                : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
            }`}
          >
            <div className="flex items-start justify-between">
              <div>
                <h3 className="text-base font-semibold text-slate-100 flex items-center gap-2">
                  {sup.name}
                  {sup.avgProductScore >= 4.8 && (
                    <span className="text-[10px] text-amber-400 bg-amber-400/10 px-2 py-0.5 rounded font-mono font-normal">
                      Top Empfehlung
                    </span>
                  )}
                </h3>
                <div className="text-xs text-slate-400 flex items-center gap-1.5 mt-1">
                  <span className="text-slate-500">Standort:</span>
                  <span className="text-slate-300 font-medium">{sup.hubLocation}</span>
                </div>
              </div>
              <div className="text-right">
                <div className="text-sm font-bold text-amber-400 font-mono">{sup.avgProductScore} / 5.0</div>
                <div className="text-[10px] text-slate-500">Qualitätsscore</div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs bg-slate-950 p-3 rounded-xl border border-slate-800/80">
              <div>
                <div className="text-slate-500 text-[11px] flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5 text-emerald-400" />
                  Lieferzeit nach DE:
                </div>
                <div className="text-emerald-400 font-semibold font-mono mt-0.5">{sup.deliveryTimeDE}</div>
              </div>

              <div>
                <div className="text-slate-500 text-[11px] flex items-center gap-1">
                  <Box className="w-3.5 h-3.5 text-slate-400" />
                  Mindestmenge (MOQ):
                </div>
                <div className="text-slate-300 font-medium mt-0.5">{sup.moq}</div>
              </div>
            </div>

            <div className="text-xs text-slate-400 space-y-1">
              <div className="text-slate-500 font-medium">Kostenstruktur:</div>
              <p className="text-slate-300">{sup.costStructure}</p>
            </div>

            <div className="text-xs text-slate-400 space-y-1">
              <div className="text-slate-500 font-medium">Retouren-Management:</div>
              <p className="text-slate-300">{sup.returnHandling}</p>
            </div>

            <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs">
              <div className="flex items-center gap-1.5 text-emerald-400">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Shopify API Sync aktiv</span>
              </div>
              <span className="text-amber-400 font-medium text-[11px]">Ausgewählt</span>
            </div>
          </div>
        ))}
      </div>

      {/* Supplier Comparison Summary Box */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
        <h3 className="text-base font-semibold text-slate-100 flex items-center gap-2">
          <Truck className="w-4 h-4 text-amber-400" />
          Fulfillment-Strategie für den DACH-Markt
        </h3>
        <p className="text-xs text-slate-300 leading-relaxed max-w-3xl">
          Deutsche Kunden haben eine extrem geringe Toleranz für Lieferzeiten über 5 Werktagen. Deshalb setzen wir als primären Logistikkanal auf den <strong>EU-Hub Frankfurt am Main (DHL GOGREEN)</strong> mit 1–3 Werktagen Zustellzeit. Internationale Direktlinien (CJ / Zendrop) nutzen wir ausschließlich als Backup für saisonale Spitzen ohne Vorab-Warenrisiko.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
          <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
            <div className="text-xs font-semibold text-slate-200">1. Kurze Lieferzeit (2-4 Tage)</div>
            <p className="text-[11px] text-slate-400 mt-1">Verhindert Stornos und senkt Kundenanfragen („Wo bleibt mein Paket?“) um über 70%.</p>
          </div>
          <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
            <div className="text-xs font-semibold text-slate-200">2. Deutsche Retourenadresse</div>
            <p className="text-[11px] text-slate-400 mt-1">Retouren gehen direkt an das Frankfurter Hub zur Prüfung und Wiederaufbereitung – kein Müll, kein Verlust.</p>
          </div>
          <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
            <div className="text-xs font-semibold text-slate-200">3. IOSS & Zollabfertigung</div>
            <p className="text-[11px] text-slate-400 mt-1">Alle Einfuhrabgaben und Steuern sind bezahlt – der Kunde muss niemals Überraschungszoll an der Haustür zahlen.</p>
          </div>
        </div>
      </div>
    </div>
  );
};
