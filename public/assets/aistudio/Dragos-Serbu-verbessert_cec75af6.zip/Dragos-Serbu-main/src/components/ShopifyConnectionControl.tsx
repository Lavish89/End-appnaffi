import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, 
  Lock, 
  Unlock, 
  RefreshCw, 
  CheckCircle2, 
  AlertTriangle, 
  Power, 
  Server, 
  Link2, 
  Sliders, 
  ArrowRight,
  ExternalLink,
  ShieldAlert,
  Zap,
  Globe
} from 'lucide-react';

interface ShopifyConnectionControlProps {
  onSyncComplete?: () => void;
  onThemePublished?: () => void;
}

export const ShopifyConnectionControl: React.FC<ShopifyConnectionControlProps> = ({
  onSyncComplete,
  onThemePublished
}) => {
  const [shopDomain, setShopDomain] = useState('aura-workspace.myshopify.com');
  const [accessToken, setAccessToken] = useState('shpat_********************************');
  const [isConnected, setIsConnected] = useState(true);
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncFeedback, setSyncFeedback] = useState<string | null>(null);
  
  // Permissions state (Volle Kontrolle)
  const [permissions, setPermissions] = useState({
    autonomousProductDrafts: true,
    autoPriceGuardrails: true,
    themeStagingAllowed: true,
    themeLivePublishAllowed: false,
    marketingGenAllowed: true,
    maxDailySpendLimit: 0.0,
    killSwitchActive: false,
  });

  const [activeTheme, setActiveTheme] = useState('Aura Minimalist v2.4 (Unveröffentlicht - Staged)');
  const [isPublishModalOpen, setIsPublishModalOpen] = useState(false);
  const [confirmationInput, setConfirmationInput] = useState('');

  // Fetch status on mount
  useEffect(() => {
    fetch('/api/shopify/status')
      .then(res => res.json())
      .then(data => {
        if (data.success && data.config) {
          setIsConnected(data.config.isConnected);
          setShopDomain(data.config.shopDomain);
          setPermissions(data.config.permissions);
          setActiveTheme(data.config.activeTheme);
        }
      })
      .catch(console.error);
  }, []);

  const handleTogglePermission = async (key: keyof typeof permissions) => {
    const updated = {
      ...permissions,
      [key]: !permissions[key],
    };
    setPermissions(updated);

    try {
      await fetch('/api/shopify/update-permissions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ permissions: updated }),
      });
      setSyncFeedback(`Berechtigung "${key}" erfolgreich aktualisiert.`);
      setTimeout(() => setSyncFeedback(null), 3000);
    } catch (err) {
      console.error(err);
    }
  };

  const handleTriggerSync = async () => {
    setIsSyncing(true);
    setSyncFeedback('Synchronisiere Produkte, Bestände und Themes mit Shopify API...');
    try {
      const res = await fetch('/api/shopify/sync', { method: 'POST' });
      const data = await res.json();
      if (data.success) {
        setSyncFeedback(data.message);
        if (onSyncComplete) onSyncComplete();
      } else {
        setSyncFeedback(`Fehler: ${data.error}`);
      }
    } catch (err: any) {
      setSyncFeedback(`Verbindungsfehler: ${err.message}`);
    } finally {
      setIsSyncing(false);
      setTimeout(() => setSyncFeedback(null), 5000);
    }
  };

  const handleConnectStore = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSyncing(true);
    try {
      const res = await fetch('/api/shopify/connect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ shopDomain, accessToken }),
      });
      const data = await res.json();
      if (data.success) {
        setIsConnected(true);
        setSyncFeedback(`Erfolgreich autorisiert: ${data.config.shopDomain}`);
      }
    } catch (err: any) {
      setSyncFeedback(`Fehler bei Autorisierung: ${err.message}`);
    } finally {
      setIsSyncing(false);
      setTimeout(() => setSyncFeedback(null), 4000);
    }
  };

  const handlePublishThemeLive = async () => {
    if (confirmationInput !== 'FREIGEBEN') {
      alert('Bitte tippe exakt "FREIGEBEN" ein, um die Live-Schaltung zu bestätigen.');
      return;
    }

    try {
      const res = await fetch('/api/shopify/publish-theme', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userConfirmed: true }),
      });
      const data = await res.json();
      if (data.success) {
        setActiveTheme(data.activeTheme);
        setPermissions(prev => ({ ...prev, themeLivePublishAllowed: true }));
        setIsPublishModalOpen(false);
        setConfirmationInput('');
        setSyncFeedback('Theme Aura Minimalist v2.4 ist nun LIVE auf Shopify!');
        if (onThemePublished) onThemePublished();
      }
    } catch (err: any) {
      alert(err.message);
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <div className="text-xs font-mono text-amber-400">SHOPIFY API & CONTROL CENTER</div>
          <h1 className="text-2xl font-bold text-slate-100 tracking-tight mt-1">
            Shopify-Verbindung & Volle Kontrolle
          </h1>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl">
            Verwalte die direkte Schnittstelle zu deinem Shopify-Onlineshop, steuere autonome Agenten-Berechtigungen und behalte jederzeit die 100%ige Entscheidungsgewalt über Veröffentlichungen und Budgets.
          </p>
        </div>

        {/* Kill Switch Toggle */}
        <button
          onClick={() => handleTogglePermission('killSwitchActive')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
            permissions.killSwitchActive
              ? 'bg-rose-500 text-white shadow-lg shadow-rose-500/20 animate-pulse'
              : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-rose-400 hover:border-rose-500/40'
          }`}
        >
          <Power className="w-4 h-4" />
          <span>{permissions.killSwitchActive ? 'NOT-HALT AKTIV (AGENT GESTOPPT)' : 'Notfall Kill-Switch'}</span>
        </button>
      </div>

      {syncFeedback && (
        <div className="p-3.5 bg-slate-900 border border-amber-500/50 rounded-xl text-xs text-amber-300 flex items-center justify-between animate-in fade-in">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-amber-400" />
            <span>{syncFeedback}</span>
          </div>
          <button onClick={() => setSyncFeedback(null)} className="text-slate-400 hover:text-white">✕</button>
        </div>
      )}

      {/* Grid: 1. Connection Card, 2. Live Store Status */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Connection Setup */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Link2 className="w-5 h-5 text-amber-400" />
              <h3 className="font-semibold text-sm text-slate-100">Shopify Admin API Verbindung</h3>
            </div>
            <span className={`text-[11px] font-mono px-2 py-0.5 rounded-full flex items-center gap-1.5 ${
              isConnected ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-rose-500/10 text-rose-400'
            }`}>
              <span className={`w-1.5 h-1.5 rounded-full ${isConnected ? 'bg-emerald-400' : 'bg-rose-400'}`} />
              {isConnected ? 'Aktiv Verbunden' : 'Getrennt'}
            </span>
          </div>

          <form onSubmit={handleConnectStore} className="space-y-3 text-xs">
            <div>
              <label className="text-slate-400 block mb-1">Shopify Store Domain (*.myshopify.com):</label>
              <div className="relative">
                <Globe className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={shopDomain}
                  onChange={(e) => setShopDomain(e.target.value)}
                  placeholder="dein-shop.myshopify.com"
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-3 py-2 text-slate-100 font-mono focus:outline-none focus:border-amber-500"
                />
              </div>
            </div>

            <div>
              <label className="text-slate-400 block mb-1">Admin API Access Token (shpat_...):</label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="password"
                  value={accessToken}
                  onChange={(e) => setAccessToken(e.target.value)}
                  placeholder="shpat_xxxxxxxxxxxxxxxxxxxxxxxxxxxx"
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-3 py-2 text-slate-100 font-mono focus:outline-none focus:border-amber-500"
                />
              </div>
              <p className="text-[11px] text-slate-500 mt-1">
                Erstellt unter: Shopify Admin → Apps → App-Entwicklung → Admin-API-Berechtigungen (read/write products, themes, inventory).
              </p>
            </div>

            <div className="pt-2 flex items-center gap-3">
              <button
                type="submit"
                disabled={isSyncing}
                className="px-4 py-2 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs rounded-xl transition-colors disabled:opacity-50"
              >
                Verbindung speichern & testen
              </button>
              <button
                type="button"
                onClick={handleTriggerSync}
                disabled={isSyncing}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs rounded-xl border border-slate-700 flex items-center gap-1.5 transition-colors disabled:opacity-50"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin text-amber-400' : ''}`} />
                <span>Jetzt Synchronisieren</span>
              </button>
            </div>
          </form>
        </div>

        {/* Live Store Status Overview */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4 flex flex-col justify-between">
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <Server className="w-5 h-5 text-emerald-400" />
                <h3 className="font-semibold text-sm text-slate-100">Live Status des verbundenen Shops</h3>
              </div>
              <span className="text-[11px] font-mono text-slate-400">Deutschland / EUR (€)</span>
            </div>

            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2 text-xs">
              <div className="flex justify-between py-1 border-b border-slate-800/80">
                <span className="text-slate-500">Shop-Name:</span>
                <span className="text-slate-200 font-bold">AURA MINIMALIST STUDIO</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/80">
                <span className="text-slate-500">Plan:</span>
                <span className="text-slate-200">Shopify Advanced</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/80">
                <span className="text-slate-500">Aktives Theme:</span>
                <span className="text-amber-400 font-semibold">{activeTheme}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/80">
                <span className="text-slate-500">Produkte in Staging:</span>
                <span className="text-slate-200 font-mono">4 vorbereitet (30 gescored)</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-500">Letzter Sync:</span>
                <span className="text-emerald-400 font-mono">Gerade eben (Live)</span>
              </div>
            </div>
          </div>

          <div className="pt-2">
            <button
              onClick={() => setIsPublishModalOpen(true)}
              className={`w-full py-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 ${
                permissions.themeLivePublishAllowed
                  ? 'bg-emerald-500 text-slate-950'
                  : 'bg-amber-400/10 hover:bg-amber-400 text-amber-300 hover:text-slate-950 border border-amber-500/30'
              }`}
            >
              <Zap className="w-4 h-4" />
              <span>Theme Aura Minimalist v2.4 Live schalten (Freigabe anfordern)</span>
            </button>
          </div>
        </div>
      </div>

      {/* Volle Kontrolle: Permission Matrix & Autonomy Guardrails */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
          <div className="flex items-center gap-2.5">
            <Sliders className="w-5 h-5 text-amber-400" />
            <div>
              <h3 className="font-semibold text-sm text-slate-100">
                Volle Kontrolle: Autonome Berechtigungs-Matrix
              </h3>
              <p className="text-xs text-slate-400">
                Du bestimmst haargenau, welche Aufgaben der Agent selbstständig ausführen darf und wo er auf deinen Klick warten muss.
              </p>
            </div>
          </div>
          <span className="text-xs text-emerald-400 font-mono bg-emerald-500/10 px-2.5 py-1 rounded-lg border border-emerald-500/20">
            Schutz-Level: Maximal
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          {/* Permission 1 */}
          <div className="flex items-start justify-between p-3.5 bg-slate-950 rounded-xl border border-slate-800">
            <div className="space-y-1 pr-4">
              <div className="font-semibold text-slate-200">1. Autonome Produktentwürfe in Staging</div>
              <p className="text-slate-400 text-[11px]">
                Erlaubt dem Agenten, überprüfte Top-Produkte als unveröffentlichte Entwürfe (Drafts) in den Katalog zu laden.
              </p>
            </div>
            <button
              onClick={() => handleTogglePermission('autonomousProductDrafts')}
              className={`px-3 py-1 rounded-lg font-mono text-[11px] font-semibold transition-colors shrink-0 ${
                permissions.autonomousProductDrafts ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40' : 'bg-slate-800 text-slate-400'
              }`}
            >
              {permissions.autonomousProductDrafts ? 'Erlaubt' : 'Gesperrt'}
            </button>
          </div>

          {/* Permission 2 */}
          <div className="flex items-start justify-between p-3.5 bg-slate-950 rounded-xl border border-slate-800">
            <div className="space-y-1 pr-4">
              <div className="font-semibold text-slate-200">2. Preis- & Margen-Korridore (DB II &gt; 50%)</div>
              <p className="text-slate-400 text-[11px]">
                Verhindert Preisänderungen, die den Netto-Deckungsbeitrag unter 50% drücken würden.
              </p>
            </div>
            <button
              onClick={() => handleTogglePermission('autoPriceGuardrails')}
              className={`px-3 py-1 rounded-lg font-mono text-[11px] font-semibold transition-colors shrink-0 ${
                permissions.autoPriceGuardrails ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40' : 'bg-slate-800 text-slate-400'
              }`}
            >
              {permissions.autoPriceGuardrails ? 'Aktiviert' : 'Deaktiviert'}
            </button>
          </div>

          {/* Permission 3 */}
          <div className="flex items-start justify-between p-3.5 bg-slate-950 rounded-xl border border-slate-800">
            <div className="space-y-1 pr-4">
              <div className="font-semibold text-slate-200">3. Theme-Bearbeitung im Staging-Modus</div>
              <p className="text-slate-400 text-[11px]">
                Agent darf Startseite, Navigation und Produktseiten in einer unveröffentlichten Theme-Kopie optimieren.
              </p>
            </div>
            <button
              onClick={() => handleTogglePermission('themeStagingAllowed')}
              className={`px-3 py-1 rounded-lg font-mono text-[11px] font-semibold transition-colors shrink-0 ${
                permissions.themeStagingAllowed ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40' : 'bg-slate-800 text-slate-400'
              }`}
            >
              {permissions.themeStagingAllowed ? 'Erlaubt' : 'Gesperrt'}
            </button>
          </div>

          {/* Permission 4 */}
          <div className="flex items-start justify-between p-3.5 bg-slate-950 rounded-xl border border-slate-800">
            <div className="space-y-1 pr-4">
              <div className="font-semibold text-slate-200">4. Live-Schaltung von Themes / Veröffentlichung</div>
              <p className="text-slate-400 text-[11px]">
                Autonome Veröffentlichung ist standardmäßig streng gesperrt. Erfordert immer deine explizite Bestätigung.
              </p>
            </div>
            <button
              onClick={() => setIsPublishModalOpen(true)}
              className={`px-3 py-1 rounded-lg font-mono text-[11px] font-semibold transition-colors shrink-0 ${
                permissions.themeLivePublishAllowed ? 'bg-emerald-500/20 text-emerald-400' : 'bg-amber-500/20 text-amber-400 border border-amber-500/40'
              }`}
            >
              {permissions.themeLivePublishAllowed ? 'Live aktiv' : 'Manuelle Freigabe'}
            </button>
          </div>

          {/* Permission 5 */}
          <div className="flex items-start justify-between p-3.5 bg-slate-950 rounded-xl border border-slate-800">
            <div className="space-y-1 pr-4">
              <div className="font-semibold text-slate-200">5. Marketing-Skripte & Creatives generieren</div>
              <p className="text-slate-400 text-[11px]">
                Erlaubt die automatische Erstellung von TikTok-Hooks, Instagram-Texten und E-Mail-Flows ohne Werbekosten.
              </p>
            </div>
            <button
              onClick={() => handleTogglePermission('marketingGenAllowed')}
              className={`px-3 py-1 rounded-lg font-mono text-[11px] font-semibold transition-colors shrink-0 ${
                permissions.marketingGenAllowed ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40' : 'bg-slate-800 text-slate-400'
              }`}
            >
              {permissions.marketingGenAllowed ? 'Erlaubt' : 'Gesperrt'}
            </button>
          </div>

          {/* Permission 6 */}
          <div className="flex items-start justify-between p-3.5 bg-slate-950 rounded-xl border border-slate-800">
            <div className="space-y-1 pr-4">
              <div className="font-semibold text-slate-200">6. Autonomes Werbebudget & App-Käufe</div>
              <p className="text-slate-400 text-[11px]">
                Fix auf 0,00 € gesetzt. Der Agent darf niemals Geld ausgeben oder kostenpflichtige Abos abschließen.
              </p>
            </div>
            <span className="px-3 py-1 bg-slate-800 text-slate-300 font-mono text-[11px] rounded-lg shrink-0 border border-slate-700">
              0,00 € (Gesperrt)
            </span>
          </div>
        </div>
      </div>

      {/* Confirmation Modal for Theme Publishing */}
      {isPublishModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-lg p-6 space-y-4 shadow-2xl">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">Theme Live-Veröffentlichung freigeben</h3>
                <p className="text-xs text-slate-400">Gemäß Master-Prompt Schutzregel: Nie ohne deine Freigabe veröffentlichen.</p>
              </div>
            </div>

            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 text-xs text-slate-300 space-y-2">
              <p>Möchtest du das vorbereitete Theme <strong>Aura Minimalist v2.4</strong> mit den 4 Flaggschiff-Produkten, dem Free-Shipping Cart Drawer und den rechtlichen Angaben (Impressum, DSGVO, AGB) als offizielles LIVE-Theme aktivieren?</p>
              <div className="text-slate-400 pt-1">
                Tippe zur Bestätigung <strong>FREIGEBEN</strong> in das Feld:
              </div>
              <input
                type="text"
                value={confirmationInput}
                onChange={(e) => setConfirmationInput(e.target.value.toUpperCase())}
                placeholder="FREIGEBEN"
                className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-white font-mono text-center tracking-widest uppercase focus:outline-none focus:border-amber-500"
              />
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                onClick={() => {
                  setIsPublishModalOpen(false);
                  setConfirmationInput('');
                }}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold rounded-xl"
              >
                Abbrechen
              </button>
              <button
                onClick={handlePublishThemeLive}
                disabled={confirmationInput !== 'FREIGEBEN'}
                className="px-4 py-2 bg-amber-400 hover:bg-amber-300 disabled:opacity-40 text-slate-950 text-xs font-bold rounded-xl transition-colors shadow-lg"
              >
                Jetzt live schalten
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
