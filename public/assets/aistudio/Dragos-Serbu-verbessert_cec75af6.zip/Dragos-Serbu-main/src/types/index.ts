export interface Competitor {
  id: string;
  name: string;
  domain: string;
  category: string;
  monthlyTrafficEst: string;
  avgOrderValue: string;
  heroHeadline: string;
  palette: { primary: string; secondary: string; accent: string; background: string };
  pdpStrengths: string[];
  salesArguments: string[];
  trustSignals: string[];
  pricingStrategy: string;
  trafficSources: { googleOrganic: number; socialAds: number; influencers: number; email: number };
  keyTakeaways: string[];
}

export interface ProductCandidate {
  rank: number;
  id: string;
  name: string;
  category: string;
  searchVolumeDE: string;
  competitionIndex: 'Gering' | 'Mittel' | 'Hoch';
  purchasePriceEK: number;
  sellingPriceVK: number;
  shippingCostDE: number;
  paymentFee: number;
  estimatedReturnRate: number;
  returnRiskCost: number;
  db1Amount: number;
  db1Percent: number;
  db2Amount: number;
  db2Percent: number;
  supplierDE: string;
  deliveryDaysDE: string;
  returnRiskScore: 'Sehr Gering' | 'Gering' | 'Mittel';
  shortVideoViralScore: number;
  euLegalCompliance: {
    gpsr2024: boolean;
    ceMark: boolean;
    lucidVerpackG: boolean;
    weeeReg: boolean;
    notes: string;
  };
  highlightUSP: string;
  sampleStatus: 'Geprüft & Freigegeben' | 'Muster bestellt' | 'In Vorprüfung';
}

export interface Supplier {
  id: string;
  name: string;
  hubLocation: string;
  deliveryTimeDE: string;
  avgProductScore: number;
  moq: string;
  inventorySync: boolean;
  returnHandling: string;
  recommendedFor: string[];
  costStructure: string;
}

export interface CatalogProduct {
  id: string;
  sku: string;
  ean: string;
  title: string;
  subtitle: string;
  category: string;
  price: number;
  compareAtPrice: number;
  costOfGoods: number;
  inventory: number;
  rating: number;
  reviewCount: number;
  image: string;
  secondaryImage?: string;
  variants: {
    name: string;
    options: string[];
  }[];
  description: string;
  bulletPoints: string[];
  specs: { [key: string]: string };
  seoTitle: string;
  seoDescription: string;
  tags: string[];
  supplierId: string;
  approvalStatus: 'Entwurf' | 'Freigabe_angefordert' | 'Freigegeben_Staging' | 'Live_Gesperrt';
  enabledChannels?: {
    inAppSelling: boolean;
    shopifyStore: boolean;
    socialCommerce: boolean;
  };
}

export interface MarketingCampaign {
  id: string;
  channel: 'tiktok' | 'instagram' | 'pinterest' | 'google_ads' | 'email_flow';
  title: string;
  targetAudience: string;
  hookOrSubject: string;
  creativeDetails: string;
  callToAction: string;
  hashtagsOrKeywords: string[];
  estimatedMetrics: string;
}

export interface AgentActivity {
  id: string;
  timestamp: string;
  phase: number;
  phaseName: string;
  action: string;
  detail: string;
  status: 'Abgeschlossen' | 'In Bearbeitung' | 'Wartet auf Freigabe' | 'Gesperrt';
  safetyCheckPassed: boolean;
}

// In-App & Multi-Channel Direct Selling Models
export interface OrderItem {
  productId: string;
  productTitle: string;
  sku: string;
  quantity: number;
  price: number;
  selectedVariants: { [key: string]: string };
  image: string;
}

export interface Order {
  id: string;
  orderNumber: string;
  createdAt: string;
  customerName: string;
  customerEmail: string;
  shippingAddress: {
    street: string;
    city: string;
    postalCode: string;
    country: string;
  };
  items: OrderItem[];
  subtotal: number;
  discount: number;
  shippingFee: number;
  total: number;
  paymentMethod: 'apple_pay' | 'google_pay' | 'klarna' | 'paypal' | 'credit_card' | 'rechnung';
  paymentStatus: 'Bezahlt' | 'Ausstehend' | 'Erstattet';
  fulfillmentStatus: 'Eingegangen' | 'In Vorbereitung' | 'Versendet' | 'Zugestellt';
  trackingNumber: string;
  carrier: string;
  salesChannel: 'In-App Direct' | 'Shopify Web' | 'TikTok Shop' | 'Instagram Direct';
}

export interface SalesChannelStatus {
  id: string;
  name: string;
  type: 'in_app' | 'shopify_web' | 'tiktok_shop' | 'instagram_shopping' | 'google_merchant';
  connected: boolean;
  syncedProductsCount: number;
  activeOrdersToday: number;
  todayRevenue: number;
  status: 'Live & Synchron' | 'Wartet auf Sync' | 'Getrennt';
}
