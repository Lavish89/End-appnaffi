// Alle Werkzeuge des Marketing-Toolkits: 50 Basis-Werkzeuge + 100 weitere.
import { MARKETING_TOOLS as BASE, TOOL_CATEGORIES as BASE_CATS, MarketingTool } from './marketingTools';
import { MORE_TOOLS, MORE_CATEGORIES } from './moreTools';

export const ALL_TOOLS: MarketingTool[] = [...BASE, ...MORE_TOOLS];
export const ALL_CATEGORIES: string[] = [...BASE_CATS, ...MORE_CATEGORIES];
