// 100 weitere Werkzeuge. Wie im Basis-Toolkit gilt: Ergebnisse entstehen nur aus den Eingaben
// des Nutzers – keine erfundenen Markt- oder Plattformdaten.
import type { MarketingTool, ToolValues, ToolField } from './marketingTools';

// ---------- Helfer ----------
const n = (v: ToolValues, k: string): number => {
  const x = parseFloat(String(v[k] ?? '').replace(/\./g, (m, i, s) => (s.indexOf(',') > -1 ? '' : m)).replace(',', '.'));
  return Number.isFinite(x) ? x : 0;
};
const t = (v: ToolValues, k: string): string => String(v[k] ?? '').trim();
const eur = (x: number) => (Number.isFinite(x) ? x.toLocaleString('de-DE', { style: 'currency', currency: 'EUR' }) : '–');
const pct = (x: number, d = 1) => (Number.isFinite(x) ? `${(x * 100).toFixed(d).replace('.', ',')} %` : '–');
const num = (x: number, d = 2) => (Number.isFinite(x) ? x.toLocaleString('de-DE', { maximumFractionDigits: d }) : '–');
const words = (s: string) => s.split(/\s+/).filter(Boolean);
const lines = (s: string) => s.split(/\n/).map(x => x.trim()).filter(Boolean);
const items = (s: string) => s.split(/[\n,;]+/).map(x => x.trim()).filter(Boolean);
const need = (c: boolean, m: string) => { if (!c) throw new Error(m); };
const slug = (s: string) => s.toLowerCase().replace(/ä/g, 'ae').replace(/ö/g, 'oe').replace(/ü/g, 'ue').replace(/ß/g, 'ss').normalize('NFKD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
const rnd = (max: number) => { const a = new Uint32Array(1); crypto.getRandomValues(a); return a[0] % max; };
const json = (o: unknown) => JSON.stringify(o, null, 2);
const ld = (o: unknown) => `<script type="application/ld+json">\n${json(o)}\n</script>`;
const esc = (s: string) => s.replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;');
const parseDate = (s: string) => { const d = new Date(s); need(!isNaN(d.getTime()), 'Datum im Format JJJJ-MM-TT eingeben.'); return d; };
const fmtDate = (d: Date) => d.toLocaleDateString('de-DE', { weekday: 'short', day: '2-digit', month: '2-digit', year: 'numeric' });

const F = {
  num: (key: string, label: string, def: number | string): ToolField => ({ key, label, type: 'number', default: def }),
  txt: (key: string, label: string, def = '', placeholder?: string): ToolField => ({ key, label, type: 'text', default: def, placeholder }),
  area: (key: string, label: string, def = '', placeholder?: string): ToolField => ({ key, label, type: 'textarea', default: def, placeholder }),
  sel: (key: string, label: string, options: string[], def?: string): ToolField => ({ key, label, type: 'select', options, default: def ?? options[0] }),
};
const tool = (id: string, category: string, name: string, description: string, fields: ToolField[], run: (v: ToolValues) => string): MarketingTool =>
  ({ id, category: category as MarketingTool['category'], name, description, fields, run });

const SAMPLE = 'Unsere Widerstandsbänder sind eigentlich ziemlich leicht und passen halt in jede Schublade. Das Training wird von vielen als angenehm empfunden. Du trainierst zuhause mit fünf Stufen, und weil sie kaum Platz brauchen, sind sie ideal für kleine Wohnungen.';

export const MORE_CATEGORIES = ['Influencer & Creator', 'Social Media', 'Texte', 'SEO & Web', 'E-Commerce', 'Finanzen', 'Produktivität', 'Daten & Umwandlung'];

const IC = 'Influencer & Creator', SM = 'Social Media', TX = 'Texte', SE = 'SEO & Web', EC = 'E-Commerce', FI = 'Finanzen', PR = 'Produktivität', DA = 'Daten & Umwandlung';

const UNICODE_BOLD = (s: string, upperA: number, lowerA: number, digit0?: number) =>
  Array.from(s).map(ch => {
    const c = ch.codePointAt(0)!;
    if (c >= 65 && c <= 90) return String.fromCodePoint(upperA + c - 65);
    if (c >= 97 && c <= 122) return String.fromCodePoint(lowerA + c - 97);
    if (digit0 && c >= 48 && c <= 57) return String.fromCodePoint(digit0 + c - 48);
    return ch;
  }).join('');

const hexToRgb = (h: string) => {
  const m = h.replace('#', '').trim();
  const full = m.length === 3 ? m.split('').map(x => x + x).join('') : m;
  need(/^[0-9a-f]{6}$/i.test(full), 'Farbe als Hex-Wert eingeben, z. B. #fbbf24.');
  return [0, 2, 4].map(i => parseInt(full.slice(i, i + 2), 16));
};
const lum = (rgb: number[]) => { const a = rgb.map(v => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }); return 0.2126 * a[0] + 0.7152 * a[1] + 0.0722 * a[2]; };

export const MORE_TOOLS: MarketingTool[] = [
  // ===== Influencer & Creator (15) =====
  tool('er', IC, 'Engagement-Rate', 'Interaktionen im Verhältnis zu Followern.', [F.num('likes', 'Likes', 420), F.num('comments', 'Kommentare', 35), F.num('shares', 'Geteilt', 12), F.num('saves', 'Gespeichert', 28), F.num('followers', 'Follower', 12000)], v => {
    need(n(v, 'followers') > 0, 'Follower angeben.');
    const i = n(v, 'likes') + n(v, 'comments') + n(v, 'shares') + n(v, 'saves');
    return `Interaktionen: ${num(i, 0)}\nEngagement-Rate: ${pct(i / n(v, 'followers'), 2)}\nKommentare je 100 Likes: ${n(v, 'likes') ? num((n(v, 'comments') / n(v, 'likes')) * 100, 1) : '–'}`;
  }),
  tool('er-reach', IC, 'Engagement pro Reichweite', 'Interaktionen im Verhältnis zu erreichten Konten – aussagekräftiger als pro Follower.', [F.num('interactions', 'Interaktionen gesamt', 495), F.num('reach', 'Erreichte Konten', 8500)], v => {
    need(n(v, 'reach') > 0, 'Reichweite angeben.');
    return `Engagement pro Reichweite: ${pct(n(v, 'interactions') / n(v, 'reach'), 2)}`;
  }),
  tool('collab-price', IC, 'Kooperationspreis', 'Preis für einen Beitrag aus deinem eigenen Satz pro 1.000 Follower, angepasst an deine Engagement-Rate.', [F.num('followers', 'Follower', 12000), F.num('rate', 'Dein Basissatz pro 1.000 Follower (€)', 10), F.num('er', 'Deine Engagement-Rate (%)', 4), F.num('ref', 'Vergleichswert Engagement-Rate (%)', 3), F.sel('format', 'Format', ['Feed-Post', 'Reel/Video', 'Story (3 Slides)'])], v => {
    const base = (n(v, 'followers') / 1000) * n(v, 'rate');
    const factor = n(v, 'ref') > 0 ? Math.min(2, Math.max(0.5, n(v, 'er') / n(v, 'ref'))) : 1;
    const fm = t(v, 'format') === 'Reel/Video' ? 1.3 : t(v, 'format').startsWith('Story') ? 0.6 : 1;
    const p = base * factor * fm;
    return `Basis: ${eur(base)}\nEngagement-Faktor: ${num(factor)}× (begrenzt auf 0,5–2)\nFormat-Faktor: ${num(fm)}×\n= Vorschlag: ${eur(p)} (Spanne ${eur(p * 0.85)} – ${eur(p * 1.15)})\nHinweis: Satz und Faktoren sind deine Annahmen – passe sie an deinen Markt an.`;
  }),
  tool('growth-rate', IC, 'Follower-Wachstum', 'Wachstum zwischen zwei Zeitpunkten und Prognose.', [F.num('start', 'Follower am Anfang', 8000), F.num('end', 'Follower heute', 9200), F.num('days', 'Zeitraum (Tage)', 30)], v => {
    need(n(v, 'start') > 0 && n(v, 'days') > 0, 'Startwert und Tage angeben.');
    const g = n(v, 'end') / n(v, 'start'); const daily = Math.pow(g, 1 / n(v, 'days')) - 1;
    return `Wachstum: ${pct(g - 1)} in ${num(n(v, 'days'), 0)} Tagen\nPro Monat (30 T.): ${pct(Math.pow(1 + daily, 30) - 1)}\nIn 6 Monaten bei gleichem Tempo: ${num(n(v, 'end') * Math.pow(1 + daily, 182), 0)} Follower`;
  }),
  tool('follower-goal', IC, 'Follower-Ziel', 'Wie lange es bis zu deinem Ziel dauert.', [F.num('now', 'Follower heute', 9200), F.num('goal', 'Ziel', 20000), F.num('growth', 'Wachstum pro Monat (%)', 6)], v => {
    need(n(v, 'growth') > 0 && n(v, 'goal') > n(v, 'now') && n(v, 'now') > 0, 'Werte prüfen: Ziel größer als heute, Wachstum > 0.');
    const m = Math.log(n(v, 'goal') / n(v, 'now')) / Math.log(1 + n(v, 'growth') / 100);
    const d = new Date(); d.setMonth(d.getMonth() + Math.ceil(m));
    return `Dauer: ca. ${num(m, 1)} Monate\nVoraussichtlich erreicht: ${d.toLocaleDateString('de-DE', { month: 'long', year: 'numeric' })}`;
  }),
  tool('media-kit', IC, 'Media-Kit-Text', 'Textbausteine für dein Media-Kit.', [F.txt('name', 'Name / Kanal', '@fitimwohnzimmer'), F.txt('niche', 'Thema', 'Home-Fitness in kleinen Wohnungen'), F.txt('platforms', 'Plattformen & Follower', 'Instagram 12.000, TikTok 8.500'), F.num('er', 'Engagement-Rate (%)', 4.1), F.txt('audience', 'Zielgruppe', '70 % Frauen, 25–34 Jahre, DACH'), F.txt('brands', 'Bisherige Partner (optional)', '')], v =>
    [`${t(v, 'name')} – ${t(v, 'niche')}`, '', `Über mich: Ich zeige, wie ${t(v, 'niche').toLowerCase()} im Alltag funktioniert – ehrlich, praktisch und ohne Studio.`, '', `Reichweite: ${t(v, 'platforms')}`, `Engagement-Rate: ${num(n(v, 'er'), 1)} %`, `Zielgruppe: ${t(v, 'audience')}`, t(v, 'brands') ? `Partner: ${t(v, 'brands')}` : '', '', 'Formate: Feed-Post, Reel, Story-Serie, Langzeitkooperation', 'Kontakt: [deine E-Mail]'].filter((x, i, a) => x !== '' || a[i - 1] !== '').join('\n')),
  tool('pitch-mail', IC, 'Kooperationsanfrage an Marken', 'E-Mail, um eine Marke anzuschreiben.', [F.txt('brand', 'Marke', 'FitBand GmbH'), F.txt('product', 'Produkt', 'Widerstandsbänder'), F.txt('you', 'Dein Kanal', '@fitimwohnzimmer, 12.000 Follower'), F.txt('why', 'Warum passt es?', 'meine Community trainiert zuhause auf wenig Platz'), F.txt('idea', 'Konkrete Idee', '3-teilige Reel-Serie „Ganzkörper in 15 Minuten“')], v =>
    `Betreff: Kooperationsidee: ${t(v, 'product')} × ${t(v, 'you').split(',')[0]}\n\nHallo Team von ${t(v, 'brand')},\n\nich bin ${t(v, 'you')}. Ich nutze ${t(v, 'product')} selbst und finde, dass es gut passt, weil ${t(v, 'why')}.\n\nMeine Idee: ${t(v, 'idea')}.\n\nGern schicke ich euch mein Media-Kit und Beispielzahlen. Habt ihr nächste Woche 15 Minuten für ein kurzes Gespräch?\n\nViele Grüße\n[Name]`),
  tool('price-list', IC, 'Preisliste & Pakete', 'Einzelpreise und Paketpreise mit Rabatt.', [F.num('post', 'Feed-Post (€)', 150), F.num('reel', 'Reel (€)', 220), F.num('story', 'Story-Serie (€)', 90), F.num('disc', 'Paketrabatt (%)', 15)], v => {
    const p = n(v, 'post'), r = n(v, 'reel'), s = n(v, 'story'), d = 1 - n(v, 'disc') / 100;
    return `Einzeln:\n• Feed-Post: ${eur(p)}\n• Reel: ${eur(r)}\n• Story-Serie: ${eur(s)}\n\nPakete:\n• Starter (Reel + Story): ${eur((r + s) * d)} statt ${eur(r + s)}\n• Komplett (Post + Reel + Story): ${eur((p + r + s) * d)} statt ${eur(p + r + s)}\n• Monat (2 Reels + 2 Storys): ${eur((2 * r + 2 * s) * d)} statt ${eur(2 * r + 2 * s)}`;
  }),
  tool('offer-text', IC, 'Angebotstext für Kooperation', 'Leistungen, Nutzungsrechte und Bedingungen als Angebot.', [F.txt('client', 'Kunde', 'FitBand GmbH'), F.area('services', 'Leistungen (eine pro Zeile)', '1 Reel (30–60 s)\n3 Story-Slides mit Link\n1 Freigaberunde'), F.num('fee', 'Honorar netto (€)', 450), F.num('months', 'Nutzungsrechte (Monate)', 3), F.txt('channels', 'Nutzung erlaubt auf', 'Kanälen der Marke, ohne Paid Ads')], v =>
    `Angebot für ${t(v, 'client')}\n\nLeistungen:\n${lines(t(v, 'services')).map(x => `• ${x}`).join('\n')}\n\nNutzungsrechte: ${num(n(v, 'months'), 0)} Monate, ${t(v, 'channels')}\nHonorar: ${eur(n(v, 'fee'))} zzgl. gesetzlicher USt. (falls anfallend)\nZahlungsziel: 14 Tage nach Veröffentlichung\nKennzeichnung: Alle Inhalte werden als „Anzeige“ gekennzeichnet.\n\nGültig 14 Tage.`),
  tool('usage-rights', IC, 'Aufschlag für Nutzungsrechte', 'Was zusätzliche Nutzungsrechte kosten, nach deinen eigenen Sätzen.', [F.num('base', 'Basishonorar (€)', 300), F.num('months', 'Laufzeit (Monate)', 6), F.num('perMonth', 'Aufschlag pro Monat (%)', 5), F.sel('ads', 'Nutzung in bezahlter Werbung?', ['Nein', 'Ja']), F.num('adsPct', 'Aufschlag für Werbung (%)', 30)], v => {
    const m = (n(v, 'months') * n(v, 'perMonth')) / 100, a = t(v, 'ads') === 'Ja' ? n(v, 'adsPct') / 100 : 0;
    const extra = n(v, 'base') * (m + a);
    return `Laufzeit-Aufschlag: ${pct(m, 0)}\nWerbe-Aufschlag: ${pct(a, 0)}\nZusätzlich: ${eur(extra)}\nGesamt: ${eur(n(v, 'base') + extra)}`;
  }),
  tool('bio', IC, 'Bio-Generator', 'Fünf Profil-Bios mit Zeichenzahl (Instagram: max. 150).', [F.txt('niche', 'Thema', 'Home-Workouts für kleine Wohnungen'), F.txt('value', 'Was bekommt man bei dir?', 'Übungen in 15 Minuten'), F.txt('cta', 'Aufruf', 'Gratis-Plan im Link'), F.txt('emoji', 'Emoji', '💪')], v => {
    const e = t(v, 'emoji');
    const list = [`${e} ${t(v, 'niche')}\n✓ ${t(v, 'value')}\n👇 ${t(v, 'cta')}`, `${t(v, 'value')} – ${t(v, 'niche').toLowerCase()} ${e}\n${t(v, 'cta')} ⬇️`, `Kein Platz? Kein Problem. ${e}\n${t(v, 'niche')}\n${t(v, 'cta')}`, `${e} Ich helfe dir: ${t(v, 'value').toLowerCase()}\n${t(v, 'cta')}`, `${t(v, 'niche')} | ${t(v, 'value')}\n${t(v, 'cta')} ${e}`];
    return list.map((b, i) => `Bio ${i + 1} (${Array.from(b).length} Zeichen${Array.from(b).length > 150 ? ' ⚠️ zu lang' : ''}):\n${b}`).join('\n\n');
  }),
  tool('pillars', IC, 'Content-Säulen', 'Vier Themensäulen mit je drei Ideen.', [F.txt('niche', 'Nische', 'Home-Fitness'), F.txt('audience', 'Zielgruppe', 'Berufstätige mit wenig Zeit')], v => {
    const nn = t(v, 'niche'), a = t(v, 'audience');
    const p = [['Wissen', [`3 Mythen über ${nn}`, `${nn}-Begriffe einfach erklärt`, `Was ${a} falsch machen`]], ['Anleitung', [`${nn} in 10 Minuten`, 'Schritt-für-Schritt für Anfänger', 'Meine Routine zum Nachmachen']], ['Persönlich', ['Ein Tag in meinem Leben', 'Mein größter Fehler', 'Warum ich angefangen habe']], ['Produkt & Empfehlung', ['Ehrlicher Test', 'Vergleich: zwei Produkte', 'Mein Setup unter 50 €']]] as const;
    return p.map(([title, ideas]) => `${title}:\n${ideas.map(i => `• ${i}`).join('\n')}`).join('\n\n');
  }),
  tool('story-seq', IC, 'Story-Sequenz', 'Sieben Story-Slides, die zum Link führen.', [F.txt('product', 'Produkt', 'Widerstandsbänder'), F.txt('problem', 'Problem', 'kein Platz für Geräte')], v =>
    [`1. Frage-Sticker: „Kennst du das – ${t(v, 'problem')}?“`, '2. Kurz zeigen, wie es bei dir aussah', `3. Lösung: ${t(v, 'product')} auspacken`, '4. 10-Sekunden-Demo einer Übung', '5. Ehrlich: ein Nachteil', '6. Umfrage-Sticker: „Willst du meine Routine?“', '7. Link-Sticker + „Anzeige“-Hinweis'].join('\n')),
  tool('giveaway', IC, 'Gewinnspiel-Bedingungen (Vorlage)', 'Gerüst für Teilnahmebedingungen. Vor Veröffentlichung rechtlich prüfen lassen.', [F.txt('host', 'Veranstalter', 'Max Mustermann, Musterstr. 1, 12345 Musterstadt'), F.txt('prize', 'Gewinn', '1× Widerstandsbänder-Set'), F.txt('end', 'Teilnahmeschluss', '31.12.2026, 23:59 Uhr'), F.txt('how', 'Teilnahme', 'Beitrag liken und kommentieren'), F.num('age', 'Mindestalter', 18)], v =>
    `Teilnahmebedingungen (Vorlage – bitte prüfen lassen)\n\n1. Veranstalter: ${t(v, 'host')}.\n2. Teilnahme: ${t(v, 'how')} bis ${t(v, 'end')}. Teilnahme ab ${num(n(v, 'age'), 0)} Jahren mit Wohnsitz in Deutschland. Die Teilnahme ist kostenlos und unabhängig von einem Kauf.\n3. Gewinn: ${t(v, 'prize')}. Keine Barauszahlung.\n4. Ermittlung: Zufallsauswahl nach Teilnahmeschluss, Benachrichtigung per Direktnachricht innerhalb von 7 Tagen.\n5. Datenschutz: Daten nur zur Durchführung und Gewinnzustellung, danach Löschung.\n6. Das Gewinnspiel steht in keiner Verbindung zu Instagram/Meta.`),
  tool('disclosure-check', IC, 'Kennzeichnungs-Check', 'Prüft, ob ein Beitrag sichtbar als Werbung gekennzeichnet ist.', [F.area('text', 'Beitragstext', 'Mein neues Lieblingsteil für zuhause 💪 Link in Bio #ad #fitness')], v => {
    const s = t(v, 'text'), first = s.slice(0, 100).toLowerCase();
    const hasStart = /\b(anzeige|werbung)\b/.test(first);
    const onlyHashtag = !hasStart && /#(ad|werbung|anzeige)\b/i.test(s);
    return [hasStart ? '✅ „Anzeige“/„Werbung“ steht am Anfang.' : '⚠️ Kein deutlicher Hinweis am Anfang. Beginne mit „Anzeige“ oder „Werbung“.', onlyHashtag ? '⚠️ Nur als Hashtag gekennzeichnet – das gilt oft als nicht ausreichend.' : '', /\*|affiliate/i.test(s) ? '✅ Affiliate-Link-Hinweis gefunden.' : 'ℹ️ Affiliate-Links zusätzlich mit * markieren und kurz erklären.'].filter(Boolean).join('\n');
  }),

  // ===== Social Media (12) =====
  tool('hashtag-mix', SM, 'Hashtag-Mix', 'Ausgewogene Mischung aus breiten, mittleren und Nischen-Hashtags.', [F.txt('broad', 'Breite Hashtags', 'fitness, workout, sport'), F.txt('mid', 'Mittlere', 'homeworkout, fitnesszuhause, trainingzuhause'), F.txt('niche', 'Nischen', 'kleinewohnung, widerstandsband, homegymdeutschland'), F.num('total', 'Anzahl gesamt', 12)], v => {
    const clean = (s: string) => items(s).map(x => '#' + x.replace(/^#/, '').replace(/\s+/g, ''));
    const b = clean(t(v, 'broad')), m = clean(t(v, 'mid')), k = clean(t(v, 'niche')), tot = Math.max(3, Math.round(n(v, 'total')));
    const out = [...k.slice(0, Math.ceil(tot * 0.5)), ...m.slice(0, Math.ceil(tot * 0.3)), ...b.slice(0, Math.ceil(tot * 0.2))];
    return `${Array.from(new Set(out)).slice(0, tot).join(' ')}\n\n(Gewichtung: ca. 50 % Nische, 30 % mittel, 20 % breit)`;
  }),
  tool('hashtag-count', SM, 'Hashtag-Zähler', 'Zählt Hashtags und findet doppelte.', [F.area('text', 'Text', '#fitness #homeworkout #Fitness #sport #homeworkout')], v => {
    const tags = (t(v, 'text').match(/#[\p{L}\p{N}_]+/gu) || []);
    const seen = new Map<string, number>(); tags.forEach(x => seen.set(x.toLowerCase(), (seen.get(x.toLowerCase()) || 0) + 1));
    const dup = [...seen].filter(([, c]) => c > 1).map(([k]) => k);
    return `Hashtags: ${tags.length} (${seen.size} verschiedene)\n${dup.length ? `Doppelt: ${dup.join(', ')}` : 'Keine doppelten.'}\nBereinigt: ${[...seen.keys()].join(' ')}`;
  }),
  tool('caption-format', SM, 'Caption-Absätze', 'Erhält Leerzeilen in Instagram-Captions mit unsichtbarem Zeichen.', [F.area('text', 'Caption', 'Erster Absatz.\n\nZweiter Absatz.\n\n#fitness')], v => t(v, 'text').split('\n').map(l => (l.trim() === '' ? '⠀' : l)).join('\n')),
  tool('emoji-bullets', SM, 'Emoji-Aufzählung', 'Macht aus einer Liste eine Emoji-Aufzählung.', [F.area('list', 'Liste (eine Zeile pro Punkt)', 'Kein Platz nötig\n5 Stärken\nIn 15 Minuten fertig'), F.txt('emoji', 'Emoji', '✅')], v => lines(t(v, 'list')).map(l => `${t(v, 'emoji')} ${l}`).join('\n')),
  tool('unicode-bold', SM, 'Fett & kursiv für Social Media', 'Wandelt Text in Unicode-Fett oder -Kursiv (sparsam nutzen – Screenreader lesen es schlecht vor).', [F.txt('text', 'Text', 'Neues Video online'), F.sel('style', 'Stil', ['Fett', 'Kursiv', 'Fett kursiv'])], v => {
    const s = t(v, 'text'), st = t(v, 'style');
    return st === 'Fett' ? UNICODE_BOLD(s, 0x1d5d4, 0x1d5ee, 0x1d7ec) : st === 'Kursiv' ? UNICODE_BOLD(s, 0x1d608, 0x1d622) : UNICODE_BOLD(s, 0x1d63c, 0x1d656);
  }),
  tool('thread-split', SM, 'Thread-Aufteiler', 'Teilt langen Text in nummerierte Beiträge.', [F.area('text', 'Text', SAMPLE + ' ' + SAMPLE), F.num('limit', 'Zeichen pro Beitrag', 280)], v => {
    const lim = Math.max(50, Math.round(n(v, 'limit'))) - 8, parts: string[] = []; let cur = '';
    for (const w of words(t(v, 'text'))) { if ((cur + ' ' + w).trim().length > lim) { parts.push(cur.trim()); cur = w; } else cur += ' ' + w; }
    if (cur.trim()) parts.push(cur.trim());
    return parts.map((p, i) => `${i + 1}/${parts.length} ${p}`).join('\n\n');
  }),
  tool('week-grid', SM, 'Wochenraster', 'Verteilt deine Posts gleichmäßig über die Woche.', [F.num('posts', 'Posts pro Woche', 5), F.txt('platforms', 'Plattformen', 'Instagram, TikTok')], v => {
    const days = ['Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa', 'So'], p = Math.min(14, Math.max(1, Math.round(n(v, 'posts')))), pl = items(t(v, 'platforms'));
    const out = days.map(d => `${d}: –`); for (let i = 0; i < p; i++) { const di = Math.floor((i * 7) / p); out[di] = `${days[di]}: ${pl[i % pl.length] || 'Post'}`; }
    return out.join('\n');
  }),
  tool('yt-title', SM, 'YouTube-Titel-Check', 'Länge, Keyword-Position und Zahlen.', [F.txt('title', 'Titel', '5 Übungen für kleine Wohnungen – Ganzkörper ohne Geräte'), F.txt('kw', 'Keyword', 'Übungen')], v => {
    const s = t(v, 'title'), p = s.toLowerCase().indexOf(t(v, 'kw').toLowerCase());
    return [`Länge: ${s.length}/100 Zeichen${s.length > 70 ? ' – in Suchergebnissen wird ab ca. 70 gekürzt' : ''}`, p === -1 ? '⚠️ Keyword fehlt' : p < 30 ? '✅ Keyword weit vorne' : 'ℹ️ Keyword nach vorne ziehen', /\d/.test(s) ? '✅ Enthält eine Zahl' : 'ℹ️ Zahlen (z. B. „5 Übungen“) erhöhen oft die Klickrate'].join('\n');
  }),
  tool('yt-chapters', SM, 'YouTube-Kapitel prüfen', 'Prüft Kapitelmarken: Start bei 0:00, aufsteigend, mind. 10 Sekunden.', [F.area('text', 'Kapitel (eine Zeile: 0:00 Titel)', '0:00 Intro\n0:45 Aufwärmen\n3:10 Übung 1\n6:30 Fazit')], v => {
    const toS = (x: string) => x.split(':').map(Number).reduce((a, b) => a * 60 + b, 0);
    const rows = lines(t(v, 'text')).map(l => { const m = l.match(/^(\d{1,2}(?::\d{2}){1,2})\s+(.+)$/); return m ? { s: toS(m[1]), title: m[2], raw: l } : null; });
    const issues: string[] = []; if (rows.some(r => !r)) issues.push('⚠️ Nicht jede Zeile hat das Format „0:00 Titel“.');
    const ok = rows.filter(Boolean) as { s: number; title: string }[];
    if (ok[0]?.s !== 0) issues.push('⚠️ Das erste Kapitel muss bei 0:00 beginnen.');
    if (ok.length < 3) issues.push('⚠️ Mindestens 3 Kapitel nötig.');
    ok.forEach((r, i) => { if (i && r.s - ok[i - 1].s < 10) issues.push(`⚠️ „${r.title}“ ist weniger als 10 s nach dem vorigen.`); if (i && r.s <= ok[i - 1].s) issues.push(`⚠️ „${r.title}“ ist nicht aufsteigend.`); });
    return issues.length ? issues.join('\n') : `✅ ${ok.length} Kapitel sind gültig.`;
  }),
  tool('speak-time', SM, 'Sprechzeit', 'Wie lange ein Skript gesprochen dauert.', [F.area('text', 'Skript', SAMPLE), F.num('wpm', 'Wörter pro Minute', 150)], v => {
    const w = words(t(v, 'text')).length, s = (w / Math.max(60, n(v, 'wpm'))) * 60;
    return `Wörter: ${w}\nSprechzeit: ca. ${Math.floor(s / 60)}:${String(Math.round(s % 60)).padStart(2, '0')} Min.`;
  }),
  tool('script-length', SM, 'Skriptlänge für Videolänge', 'Wie viele Wörter in dein Video passen.', [F.num('seconds', 'Videolänge (Sekunden)', 45), F.num('wpm', 'Sprechtempo (Wörter/Min.)', 150)], v => `Passend: ca. ${Math.round((n(v, 'seconds') / 60) * n(v, 'wpm'))} Wörter`),
  tool('comment-replies', SM, 'Antworten auf Kommentare', 'Vorlagen für typische Kommentare.', [F.sel('type', 'Art', ['Lob', 'Frage zum Produkt', 'Kritik', 'Preisfrage', 'Spam/Troll']), F.txt('product', 'Produkt', 'Widerstandsbänder')], v => ({
    'Lob': `Danke dir! 🙏 Freut mich, dass es dir hilft. Welche Übung soll als Nächstes kommen?`,
    'Frage zum Produkt': `Gute Frage! Die ${t(v, 'product')} nutze ich seit Wochen – kurz gesagt: … Details stehen im Link in meiner Bio.`,
    'Kritik': `Danke für dein ehrliches Feedback! Du hast recht, dass … Was würdest du dir stattdessen wünschen?`,
    'Preisfrage': `Den aktuellen Preis siehst du über den Link in meiner Bio – er ändert sich manchmal. *Affiliate-Link`,
    'Spam/Troll': `(Nicht antworten. Ausblenden oder melden.)`,
  } as Record<string, string>)[t(v, 'type')]),

  // ===== Texte (14) =====
  tool('word-count', TX, 'Wortzähler & Lesezeit', 'Wörter, Zeichen, Sätze und Lesezeit.', [F.area('text', 'Text', SAMPLE)], v => {
    const s = t(v, 'text'), w = words(s).length;
    return `Wörter: ${w}\nZeichen: ${s.length} (ohne Leerzeichen ${s.replace(/\s/g, '').length})\nSätze: ${(s.match(/[.!?]+/g) || []).length}\nLesezeit: ca. ${Math.max(1, Math.round(w / 200))} Min.`;
  }),
  tool('case', TX, 'Groß-/Kleinschreibung', 'Wandelt die Schreibweise um.', [F.area('text', 'Text', 'neues video: 5 übungen für zuhause'), F.sel('mode', 'Umwandeln in', ['Satzanfang groß', 'Jedes Wort groß', 'GROSSBUCHSTABEN', 'kleinbuchstaben'])], v => {
    const s = t(v, 'text'), m = t(v, 'mode');
    return m === 'GROSSBUCHSTABEN' ? s.toLocaleUpperCase('de-DE') : m === 'kleinbuchstaben' ? s.toLocaleLowerCase('de-DE') : m === 'Jedes Wort groß' ? s.replace(/(^|\s)(\p{L})/gu, (_, a, b) => a + b.toLocaleUpperCase('de-DE')) : s.toLocaleLowerCase('de-DE').replace(/(^\s*|[.!?]\s+)(\p{L})/gu, (_, a, b) => a + b.toLocaleUpperCase('de-DE'));
  }),
  tool('diff', TX, 'Textvergleich', 'Zeigt, welche Wörter dazugekommen oder weggefallen sind.', [F.area('a', 'Alte Version', 'Trainiere zuhause mit fünf Stufen.'), F.area('b', 'Neue Version', 'Trainiere zuhause mit fünf Stärken und Türanker.')], v => {
    const A = words(t(v, 'a').toLowerCase()), B = words(t(v, 'b').toLowerCase());
    const add = B.filter(w => !A.includes(w)), rem = A.filter(w => !B.includes(w));
    return `Neu: ${add.length ? add.join(', ') : '–'}\nEntfernt: ${rem.length ? rem.join(', ') : '–'}\nWörter: ${A.length} → ${B.length}`;
  }),
  tool('sentence-length', TX, 'Lange Sätze finden', 'Markiert Sätze mit mehr als 20 Wörtern.', [F.area('text', 'Text', SAMPLE), F.num('max', 'Grenze (Wörter)', 20)], v => {
    const ss = t(v, 'text').split(/(?<=[.!?])\s+/).filter(Boolean), lim = n(v, 'max') || 20;
    const long = ss.filter(s => words(s).length > lim);
    return `Sätze: ${ss.length}, davon zu lang: ${long.length}\n${long.map(s => `• (${words(s).length} W.) ${s}`).join('\n') || '✅ Alles im grünen Bereich.'}`;
  }),
  tool('filler', TX, 'Füllwörter finden', 'Findet Wörter, die man meist streichen kann.', [F.area('text', 'Text', SAMPLE)], v => {
    const list = ['eigentlich', 'halt', 'quasi', 'irgendwie', 'ziemlich', 'wirklich', 'einfach', 'eben', 'sozusagen', 'gewissermaßen', 'natürlich', 'echt', 'total', 'mal', 'ja', 'wohl', 'durchaus', 'letztendlich'];
    const found = list.map(w => [w, (t(v, 'text').toLowerCase().match(new RegExp(`\\b${w}\\b`, 'g')) || []).length] as const).filter(([, c]) => c);
    return found.length ? found.map(([w, c]) => `• ${w}: ${c}×`).join('\n') : '✅ Keine typischen Füllwörter gefunden.';
  }),
  tool('passive', TX, 'Passiv-Sätze finden', 'Findet Sätze mit „wird/wurde … -t/-en“ (Faustregel).', [F.area('text', 'Text', SAMPLE)], v => {
    const ss = t(v, 'text').split(/(?<=[.!?])\s+/), hits = ss.filter(s => /\b(wird|werden|wurde|wurden|worden)\b.*\b(ge\w+(t|en))\b/i.test(s));
    return hits.length ? `Mögliche Passiv-Sätze: ${hits.length}\n${hits.map(s => `• ${s}`).join('\n')}\nTipp: Aktiv formulieren („Viele finden das Training angenehm“).` : '✅ Keine Passiv-Sätze gefunden.';
  }),
  tool('headlines', TX, 'Überschriften-Generator', '10 Überschriften nach bewährten Mustern.', [F.txt('topic', 'Thema', 'Home-Workout'), F.txt('benefit', 'Nutzen', 'fit ohne Fitnessstudio'), F.num('nr', 'Zahl', 5)], v => {
    const tp = t(v, 'topic'), b = t(v, 'benefit'), x = num(n(v, 'nr'), 0);
    return [`${x} ${tp}-Tipps, um ${b} zu werden`, `So wirst du ${b} – in 15 Minuten am Tag`, `${tp} für Anfänger: der komplette Guide`, `Warum dein ${tp} nicht funktioniert (und was hilft)`, `${tp} ohne Ausreden: ${x} einfache Schritte`, `Das ${tp}, das ich gerne früher gekannt hätte`, `${tp} vs. Fitnessstudio: der ehrliche Vergleich`, `${x} Fehler beim ${tp}, die fast jeder macht`, `${tp}: Was wirklich zählt`, `Von 0 auf ${b}: mein ${tp}-Plan`].map((h, i) => `${i + 1}. ${h}`).join('\n');
  }),
  tool('cta-gen', TX, 'Call-to-Action-Ideen', '10 Handlungsaufforderungen.', [F.txt('action', 'Was soll passieren?', 'Plan herunterladen'), F.txt('benefit', 'Nutzen', 'in 15 Minuten fit')], v => [`Jetzt ${t(v, 'action')}`, `${t(v, 'action')} – kostenlos`, `Ja, ich will ${t(v, 'benefit')}`, `Hier ${t(v, 'action')}`, `Starte jetzt: ${t(v, 'action')}`, `${t(v, 'action')} und ${t(v, 'benefit')}`, `Zeig mir, wie`, `Ich bin dabei`, `Mehr erfahren`, `Gleich ausprobieren`].map((c, i) => `${i + 1}. ${c}`).join('\n')),
  tool('usp', TX, 'Alleinstellungsmerkmal formulieren', 'Ein Satz, der sagt, warum gerade du.', [F.txt('what', 'Was bietest du?', 'Workouts'), F.txt('who', 'Für wen?', 'Menschen in kleinen Wohnungen'), F.txt('result', 'Ergebnis', 'fit in 15 Minuten'), F.txt('unlike', 'Anders als …', 'Programme, die ein Studio voraussetzen')], v => `${t(v, 'what')} für ${t(v, 'who')}, die ${t(v, 'result')} wollen – anders als ${t(v, 'unlike')}.`),
  tool('faq-gen', TX, 'FAQ aus Merkmalen', 'Macht aus Produktmerkmalen Fragen und Antwort-Gerüste.', [F.txt('product', 'Produkt', 'Widerstandsbänder-Set'), F.area('features', 'Merkmale (eine pro Zeile)', '5 Stärken\nTüranker inklusive\nNaturlatex')], v => lines(t(v, 'features')).map(f => `F: Wie ist das mit „${f}“ beim ${t(v, 'product')}?\nA: ${f} – das bedeutet für dich: … [Nutzen ergänzen]`).join('\n\n')),
  tool('review-reply', TX, 'Antwort auf Bewertungen', 'Antwortvorlagen für positive und negative Bewertungen.', [F.sel('type', 'Bewertung', ['positiv', 'neutral', 'negativ']), F.txt('name', 'Name des Kunden', 'Anna'), F.txt('detail', 'Erwähntes Detail', 'die Lieferzeit')], v => ({
    positiv: `Liebe ${t(v, 'name')}, vielen Dank für deine tolle Bewertung! Schön, dass dir ${t(v, 'detail')} gefallen hat. Viel Freude weiterhin!`,
    neutral: `Hallo ${t(v, 'name')}, danke für dein Feedback! Was hätte ${t(v, 'detail')} für dich besser gemacht? Schreib uns gern.`,
    negativ: `Hallo ${t(v, 'name')}, das tut uns leid – ${t(v, 'detail')} sollte so nicht sein. Bitte melde dich unter [E-Mail], wir finden eine Lösung.`,
  } as Record<string, string>)[t(v, 'type')]),
  tool('compare-table', TX, 'Vergleichstabelle', 'Markdown-Tabelle für Produktvergleiche.', [F.txt('products', 'Produkte (Komma)', 'Set A, Set B, Set C'), F.area('rows', 'Merkmal: Werte (Komma)', 'Preis: 29 €, 35 €, 19 €\nStärken: 5, 4, 3\nTüranker: ja, ja, nein')], v => {
    const p = items(t(v, 'products'));
    const rows = lines(t(v, 'rows')).map(l => { const [k, rest = ''] = l.split(':'); return [k.trim(), ...rest.split(',').map(x => x.trim())]; });
    return [`| Merkmal | ${p.join(' | ')} |`, `|---|${p.map(() => '---').join('|')}|`, ...rows.map(r => `| ${r[0]} | ${p.map((_, i) => r[i + 1] || '').join(' | ')} |`)].join('\n');
  }),
  tool('before-after', TX, 'Vorher-Nachher-Text', 'Kurzer Text, der eine Veränderung zeigt.', [F.txt('before', 'Vorher', 'kein Platz, keine Zeit, keine Lust'), F.txt('after', 'Nachher', '15 Minuten Training im Wohnzimmer'), F.txt('bridge', 'Was hat es verändert?', 'ein Set Widerstandsbänder')], v => `Vorher: ${t(v, 'before')}.\nNachher: ${t(v, 'after')}.\nDer Unterschied: ${t(v, 'bridge')}.`),
  tool('slogans', TX, 'Slogan-Kombinierer', 'Kombiniert Wörter zu Slogan-Ideen.', [F.txt('a', 'Wörter Teil 1', 'Fit, Stark, Frei'), F.txt('b', 'Wörter Teil 2', 'zuhause, im Wohnzimmer, ohne Studio')], v => { const A = items(t(v, 'a')), B = items(t(v, 'b')); return A.flatMap(x => B.map(y => `${x} ${y}.`)).slice(0, 20).join('\n'); }),

  // ===== SEO & Web (12) =====
  tool('robots-meta', SE, 'Meta-Robots & Canonical', 'Erzeugt die Tags für Indexierung und kanonische URL.', [F.txt('url', 'Kanonische URL', 'https://goalsforce.store/products/widerstandsbaender'), F.sel('index', 'Indexieren?', ['index, follow', 'noindex, follow', 'noindex, nofollow'])], v => `<link rel="canonical" href="${esc(t(v, 'url'))}">\n<meta name="robots" content="${t(v, 'index')}">`),
  tool('og-tags', SE, 'Open-Graph-Tags', 'Vorschau für Facebook, WhatsApp, LinkedIn.', [F.txt('title', 'Titel', 'Widerstandsbänder Set'), F.txt('desc', 'Beschreibung', 'Ganzkörpertraining in 15 Minuten'), F.txt('url', 'URL', 'https://goalsforce.store/products/widerstandsbaender'), F.txt('image', 'Bild-URL (1200×630)', 'https://goalsforce.store/og.jpg')], v => [`<meta property="og:type" content="website">`, `<meta property="og:title" content="${esc(t(v, 'title'))}">`, `<meta property="og:description" content="${esc(t(v, 'desc'))}">`, `<meta property="og:url" content="${esc(t(v, 'url'))}">`, `<meta property="og:image" content="${esc(t(v, 'image'))}">`, `<meta name="twitter:card" content="summary_large_image">`].join('\n')),
  tool('robots-txt', SE, 'robots.txt', 'Einfache robots.txt mit Sitemap.', [F.txt('sitemap', 'Sitemap-URL', 'https://goalsforce.store/sitemap.xml'), F.area('disallow', 'Gesperrte Pfade (eine pro Zeile)', '/admin\n/checkout')], v => ['User-agent: *', ...lines(t(v, 'disallow')).map(p => `Disallow: ${p}`), 'Allow: /', '', `Sitemap: ${t(v, 'sitemap')}`].join('\n')),
  tool('sitemap', SE, 'sitemap.xml', 'Sitemap aus einer URL-Liste.', [F.area('urls', 'URLs (eine pro Zeile)', 'https://goalsforce.store/\nhttps://goalsforce.store/products/widerstandsbaender')], v => {
    const d = new Date().toISOString().slice(0, 10);
    return `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${lines(t(v, 'urls')).map(u => `  <url><loc>${esc(u)}</loc><lastmod>${d}</lastmod></url>`).join('\n')}\n</urlset>`;
  }),
  tool('hreflang', SE, 'hreflang-Tags', 'Sprachversionen einer Seite verknüpfen.', [F.area('pairs', 'Sprache: URL (eine pro Zeile)', 'de-DE: https://goalsforce.store/de/\nde-AT: https://goalsforce.store/at/\nen: https://goalsforce.store/en/'), F.txt('def', 'Standard-URL (x-default)', 'https://goalsforce.store/')], v => [...lines(t(v, 'pairs')).map(l => { const [lang, ...u] = l.split(':'); return `<link rel="alternate" hreflang="${lang.trim()}" href="${esc(u.join(':').trim())}">`; }), `<link rel="alternate" hreflang="x-default" href="${esc(t(v, 'def'))}">`].join('\n')),
  tool('faq-schema', SE, 'FAQ-Schema (JSON-LD)', 'Strukturierte Daten für Fragen und Antworten.', [F.area('qa', 'Frage? Antwort (eine pro Zeile)', 'Wie lange dauert der Versand? 2–4 Werktage.\nKann ich zurückgeben? Ja, innerhalb von 14 Tagen.')], v => ld({ '@context': 'https://schema.org', '@type': 'FAQPage', mainEntity: lines(t(v, 'qa')).map(l => { const i = l.indexOf('?'); return { '@type': 'Question', name: l.slice(0, i + 1).trim(), acceptedAnswer: { '@type': 'Answer', text: l.slice(i + 1).trim() } }; }) })),
  tool('breadcrumb', SE, 'Breadcrumb-Schema (JSON-LD)', 'Brotkrumen-Navigation für Google.', [F.area('items', 'Name | URL (eine pro Zeile)', 'Start | https://goalsforce.store/\nFitness | https://goalsforce.store/collections/fitness\nWiderstandsbänder | https://goalsforce.store/products/widerstandsbaender')], v => ld({ '@context': 'https://schema.org', '@type': 'BreadcrumbList', itemListElement: lines(t(v, 'items')).map((l, i) => { const [name, url] = l.split('|').map(x => x.trim()); return { '@type': 'ListItem', position: i + 1, name, item: url }; }) })),
  tool('article-schema', SE, 'Artikel-Schema (JSON-LD)', 'Strukturierte Daten für Blogartikel.', [F.txt('title', 'Titel', '5 Übungen für kleine Wohnungen'), F.txt('author', 'Autor', 'Dragos Serbu'), F.txt('date', 'Veröffentlicht (JJJJ-MM-TT)', new Date().toISOString().slice(0, 10)), F.txt('image', 'Bild-URL', 'https://goalsforce.store/blog/uebungen.jpg')], v => ld({ '@context': 'https://schema.org', '@type': 'Article', headline: t(v, 'title'), author: { '@type': 'Person', name: t(v, 'author') }, datePublished: t(v, 'date'), image: [t(v, 'image')] })),
  tool('kw-group', SE, 'Keywords gruppieren', 'Gruppiert Keywords nach gemeinsamem Hauptwort.', [F.area('kws', 'Keywords (eine pro Zeile)', 'widerstandsband übungen\nwiderstandsband set\nhome workout anfänger\nhome workout ohne geräte\nfaszienrolle test')], v => {
    const g = new Map<string, string[]>(); lines(t(v, 'kws')).forEach(k => { const h = k.toLowerCase().split(/\s+/)[0]; g.set(h, [...(g.get(h) || []), k]); });
    return [...g].map(([h, ks]) => `${h} (${ks.length}):\n${ks.map(k => `• ${k}`).join('\n')}`).join('\n\n');
  }),
  tool('longtail', SE, 'Long-Tail-Keywords', 'Kombiniert ein Keyword mit typischen Zusätzen.', [F.txt('kw', 'Keyword', 'widerstandsband'), F.txt('mods', 'Zusätze', 'test, übungen, für anfänger, kaufen, vergleich, welche stärke, erfahrungen')], v => items(t(v, 'mods')).map(m => `${t(v, 'kw')} ${m}`).join('\n')),
  tool('url-clean', SE, 'URL von Tracking befreien', 'Entfernt utm_*, fbclid, gclid und ähnliche Parameter.', [F.txt('url', 'URL', 'https://goalsforce.store/products/x?utm_source=ig&fbclid=123&variant=4')], v => {
    let u: URL; try { u = new URL(t(v, 'url')); } catch { throw new Error('Vollständige URL mit https:// eingeben.'); }
    [...u.searchParams.keys()].forEach(k => { if (/^(utm_|fbclid|gclid|msclkid|mc_|igshid|ttclid|_hs)/i.test(k)) u.searchParams.delete(k); });
    return u.toString();
  }),
  tool('redirects', SE, 'Weiterleitungen (301)', 'Regeln für .htaccess, nginx und Shopify-CSV.', [F.area('pairs', 'Alt -> Neu (eine pro Zeile)', '/alte-seite -> /neue-seite\n/produkt-a -> /products/produkt-a')], v => {
    const p = lines(t(v, 'pairs')).map(l => l.split(/\s*->\s*/)).filter(x => x.length === 2);
    need(p.length > 0, 'Format: /alt -> /neu');
    return `.htaccess:\n${p.map(([a, b]) => `Redirect 301 ${a} ${b}`).join('\n')}\n\nnginx:\n${p.map(([a, b]) => `location = ${a} { return 301 ${b}; }`).join('\n')}\n\nShopify (CSV „Redirect from,Redirect to“):\n${p.map(([a, b]) => `${a},${b}`).join('\n')}`;
  }),

  // ===== E-Commerce (12) =====
  tool('vat', EC, 'Mehrwertsteuer-Rechner', 'Brutto ↔ Netto mit 19 % oder 7 %.', [F.num('amount', 'Betrag (€)', 39.9), F.sel('dir', 'Betrag ist', ['brutto', 'netto']), F.sel('rate', 'Steuersatz', ['19', '7'])], v => {
    const r = n(v, 'rate') / 100, a = n(v, 'amount'), net = t(v, 'dir') === 'brutto' ? a / (1 + r) : a, gross = net * (1 + r);
    return `Netto: ${eur(net)}\nMwSt. (${num(r * 100, 0)} %): ${eur(gross - net)}\nBrutto: ${eur(gross)}`;
  }),
  tool('margin-markup', EC, 'Marge ↔ Aufschlag', 'Rechnet Handelsspanne und Kalkulationsaufschlag um.', [F.num('cost', 'Einkauf netto (€)', 12), F.num('price', 'Verkauf netto (€)', 33.5)], v => {
    need(n(v, 'cost') > 0 && n(v, 'price') > 0, 'Preise angeben.');
    return `Rohertrag: ${eur(n(v, 'price') - n(v, 'cost'))}\nMarge (Handelsspanne): ${pct((n(v, 'price') - n(v, 'cost')) / n(v, 'price'))}\nAufschlag: ${pct((n(v, 'price') - n(v, 'cost')) / n(v, 'cost'))}`;
  }),
  tool('price-from-margin', EC, 'Preis aus Wunschmarge', 'Welcher Verkaufspreis deine Zielmarge erreicht.', [F.num('cost', 'Kosten pro Stück netto (€)', 15), F.num('margin', 'Wunschmarge (%)', 55), F.num('vat', 'MwSt. (%)', 19)], v => {
    need(n(v, 'margin') < 100, 'Marge muss unter 100 % liegen.');
    const net = n(v, 'cost') / (1 - n(v, 'margin') / 100);
    return `Netto: ${eur(net)}\nBrutto: ${eur(net * (1 + n(v, 'vat') / 100))}`;
  }),
  tool('tier-discount', EC, 'Mengenrabatt-Staffel', 'Preise je Menge mit Staffelrabatten.', [F.num('price', 'Stückpreis (€)', 19.9), F.txt('tiers', 'Staffeln Menge:Rabatt%', '2:5, 3:10, 5:15')], v => {
    const ts = items(t(v, 'tiers')).map(x => x.split(':').map(Number)).filter(x => x.length === 2);
    return [`1 Stück: ${eur(n(v, 'price'))}`, ...ts.map(([q, d]) => `${q} Stück: je ${eur(n(v, 'price') * (1 - d / 100))}, gesamt ${eur(q * n(v, 'price') * (1 - d / 100))} (−${d} %)`)].join('\n');
  }),
  tool('cross-sell', EC, 'Cross-Selling-Wirkung', 'Mehr Umsatz durch Zusatzprodukte im Warenkorb.', [F.num('orders', 'Bestellungen pro Monat', 120), F.num('take', 'Anteil, der zusätzlich kauft (%)', 15), F.num('addon', 'Preis Zusatzprodukt (€)', 9.9)], v => `Zusätzlicher Umsatz: ${eur((n(v, 'orders') * n(v, 'take')) / 100 * n(v, 'addon'))} pro Monat`),
  tool('stock-days', EC, 'Lagerreichweite', 'Wie lange der Bestand reicht und wann du nachbestellen musst.', [F.num('stock', 'Bestand (Stück)', 240), F.num('daily', 'Verkäufe pro Tag', 6), F.num('lead', 'Lieferzeit Nachschub (Tage)', 14), F.num('safety', 'Sicherheitspuffer (Tage)', 5)], v => {
    need(n(v, 'daily') > 0, 'Verkäufe pro Tag angeben.');
    const days = n(v, 'stock') / n(v, 'daily'), order = days - n(v, 'lead') - n(v, 'safety'), d = new Date(Date.now() + Math.max(0, order) * 864e5);
    return `Reichweite: ${num(days, 1)} Tage\n${order <= 0 ? '⚠️ Jetzt nachbestellen!' : `Spätestens nachbestellen am: ${fmtDate(d)}`}`;
  }),
  tool('eoq', EC, 'Optimale Bestellmenge', 'Klassische Bestellmengen-Formel (EOQ).', [F.num('demand', 'Jahresbedarf (Stück)', 2000), F.num('orderCost', 'Kosten pro Bestellung (€)', 40), F.num('holding', 'Lagerkosten pro Stück und Jahr (€)', 1.5)], v => {
    need(n(v, 'holding') > 0, 'Lagerkosten angeben.');
    const q = Math.sqrt((2 * n(v, 'demand') * n(v, 'orderCost')) / n(v, 'holding'));
    return `Optimale Bestellmenge: ${num(q, 0)} Stück\nBestellungen pro Jahr: ${num(n(v, 'demand') / q, 1)}`;
  }),
  tool('returns-cost', EC, 'Retourenkosten', 'Was Retouren dich pro Monat kosten.', [F.num('orders', 'Bestellungen pro Monat', 300), F.num('rate', 'Retourenquote (%)', 8), F.num('label', 'Retourenlabel (€)', 5.5), F.num('handling', 'Bearbeitung pro Retoure (€)', 3), F.num('loss', 'Wertverlust pro Retoure (€)', 4)], v => {
    const r = (n(v, 'orders') * n(v, 'rate')) / 100, c = r * (n(v, 'label') + n(v, 'handling') + n(v, 'loss'));
    return `Retouren: ${num(r, 0)} pro Monat\nKosten: ${eur(c)} pro Monat (${eur(c * 12)} pro Jahr)\nJe 1 % weniger Retouren: ${eur(c / Math.max(0.01, n(v, 'rate')))} gespart`;
  }),
  tool('shipping-compare', EC, 'Versand-Vergleich', 'Günstigster Versand für ein Gewicht nach deinen eigenen Tarifen.', [F.num('weight', 'Gewicht (kg)', 1.8), F.area('rates', 'Anbieter: bis kg = Preis, … (eine Zeile je Anbieter)', 'Anbieter A: 1=4.50, 2=5.50, 5=7.00\nAnbieter B: 2=4.99, 10=8.49')], v => {
    const w = n(v, 'weight');
    const res = lines(t(v, 'rates')).map(l => { const [name, rest = ''] = l.split(':'); const tiers = rest.split(',').map(x => x.split('=').map(y => parseFloat(y.replace(',', '.')))).filter(x => x.length === 2 && x.every(Number.isFinite)).sort((a, b) => a[0] - b[0]); const hit = tiers.find(([kg]) => w <= kg); return { name: name.trim(), price: hit ? hit[1] : NaN }; });
    const ok = res.filter(r => Number.isFinite(r.price)).sort((a, b) => a.price - b.price);
    return ok.length ? ok.map((r, i) => `${i === 0 ? '✅' : '•'} ${r.name}: ${eur(r.price)}`).join('\n') : 'Kein Tarif passt zu diesem Gewicht.';
  }),
  tool('coupon-cost', EC, 'Gutschein-Kosten', 'Was eine Gutscheinaktion kostet und bringt.', [F.num('codes', 'Verteilte Codes', 1000), F.num('redeem', 'Einlösequote (%)', 6), F.num('aov', 'Ø Warenkorb (€)', 45), F.num('disc', 'Rabatt (%)', 10), F.num('margin', 'Marge vor Rabatt (%)', 45)], v => {
    const o = (n(v, 'codes') * n(v, 'redeem')) / 100, rev = o * n(v, 'aov') * (1 - n(v, 'disc') / 100), cost = o * n(v, 'aov') * (n(v, 'disc') / 100), profit = o * n(v, 'aov') * ((n(v, 'margin') - n(v, 'disc')) / 100);
    return `Erwartete Bestellungen: ${num(o, 0)}\nUmsatz: ${eur(rev)}\nRabattkosten: ${eur(cost)}\nRohertrag nach Rabatt: ${eur(profit)}`;
  }),
  tool('mrr', EC, 'Abo-Umsatz (MRR/ARR)', 'Monatlich wiederkehrender Umsatz und Prognose mit Kündigungen.', [F.num('subs', 'Aktive Abos', 80), F.num('price', 'Preis pro Monat (€)', 9.9), F.num('newM', 'Neue Abos pro Monat', 15), F.num('churn', 'Kündigungsrate pro Monat (%)', 4)], v => {
    let s = n(v, 'subs'); const out: string[] = [`Heute: MRR ${eur(s * n(v, 'price'))}, ARR ${eur(s * n(v, 'price') * 12)}`];
    for (let m = 1; m <= 12; m++) { s = s * (1 - n(v, 'churn') / 100) + n(v, 'newM'); if (m % 3 === 0) out.push(`Monat ${m}: ${num(s, 0)} Abos, MRR ${eur(s * n(v, 'price'))}`); }
    return out.join('\n');
  }),
  tool('price-increase', EC, 'Preiserhöhung', 'Wie viele Kunden du verlieren darfst, ohne Gewinn einzubüßen.', [F.num('price', 'Aktueller Preis (€)', 29), F.num('cost', 'Variable Kosten pro Stück (€)', 12), F.num('raise', 'Erhöhung (%)', 10)], v => {
    const p0 = n(v, 'price'), p1 = p0 * (1 + n(v, 'raise') / 100), c = n(v, 'cost'); need(p0 > c, 'Preis muss über den Kosten liegen.');
    const maxLoss = 1 - (p0 - c) / (p1 - c);
    return `Neuer Preis: ${eur(p1)}\nDeckungsbeitrag: ${eur(p0 - c)} → ${eur(p1 - c)}\nDu darfst bis zu ${pct(maxLoss)} der Verkäufe verlieren und verdienst gleich viel.`;
  }),

  // ===== Finanzen (12) =====
  tool('hourly-rate', FI, 'Stundensatz für Selbstständige', 'Welcher Stundensatz dein Wunsch-Einkommen deckt.', [F.num('income', 'Wunsch-Einkommen pro Jahr vor Steuern (€)', 48000), F.num('costs', 'Betriebskosten pro Jahr (€)', 6000), F.num('days', 'Arbeitstage pro Jahr', 200), F.num('hours', 'Abrechenbare Stunden pro Tag', 5)], v => {
    const h = n(v, 'days') * n(v, 'hours'); need(h > 0, 'Tage und Stunden angeben.');
    return `Abrechenbare Stunden: ${num(h, 0)}\nMindest-Stundensatz: ${eur((n(v, 'income') + n(v, 'costs')) / h)} (netto, ohne USt.)`;
  }),
  tool('kleinunternehmer', FI, 'Kleinunternehmer-Check', 'Grenzen der Kleinunternehmerregelung (§ 19 UStG, Stand 2025: 25.000 € Vorjahr / 100.000 € laufendes Jahr). Keine Steuerberatung.', [F.num('last', 'Umsatz Vorjahr (€)', 18000), F.num('current', 'Erwarteter Umsatz dieses Jahr (€)', 30000)], v => {
    const ok1 = n(v, 'last') <= 25000, ok2 = n(v, 'current') <= 100000;
    return `Vorjahr ≤ 25.000 €: ${ok1 ? '✅' : '❌'}\nLaufendes Jahr ≤ 100.000 €: ${ok2 ? '✅' : '❌ (Regelung endet ab dem Umsatz, der die Grenze überschreitet)'}\n${ok1 && ok2 ? 'Die Kleinunternehmerregelung ist voraussichtlich möglich.' : 'Die Kleinunternehmerregelung greift voraussichtlich nicht.'}\nBitte mit Steuerberatung bestätigen.`;
  }),
  tool('tax-reserve', FI, 'Steuer-Rücklage', 'Wie viel du von Einnahmen zur Seite legen solltest.', [F.num('income', 'Einnahmen diesen Monat (€)', 1200), F.num('pct', 'Rücklage-Satz (%)', 30), F.sel('vat', 'Enthält 19 % USt.?', ['Nein', 'Ja'])], v => {
    const gross = n(v, 'income'), vat = t(v, 'vat') === 'Ja' ? gross - gross / 1.19 : 0, base = gross - vat;
    return `${vat ? `USt. zurücklegen: ${eur(vat)}\n` : ''}Einkommensteuer-Rücklage: ${eur((base * n(v, 'pct')) / 100)}\nVerfügbar: ${eur(base - (base * n(v, 'pct')) / 100)}\n(Satz ist eine Annahme – Steuerberatung fragen.)`;
  }),
  tool('break-even-units', FI, 'Break-even-Menge', 'Ab wie vielen Verkäufen du Gewinn machst.', [F.num('fixed', 'Fixkosten pro Monat (€)', 800), F.num('price', 'Preis pro Stück (€)', 29), F.num('var', 'Variable Kosten pro Stück (€)', 13)], v => {
    const db = n(v, 'price') - n(v, 'var'); need(db > 0, 'Preis muss über den variablen Kosten liegen.');
    return `Deckungsbeitrag pro Stück: ${eur(db)}\nBreak-even: ${Math.ceil(n(v, 'fixed') / db)} Stück pro Monat (${eur(Math.ceil(n(v, 'fixed') / db) * n(v, 'price'))} Umsatz)`;
  }),
  tool('roi', FI, 'ROI-Rechner', 'Rendite einer Investition.', [F.num('invest', 'Investition (€)', 500), F.num('return', 'Rückfluss (€)', 800)], v => { need(n(v, 'invest') > 0, 'Investition angeben.'); return `Gewinn: ${eur(n(v, 'return') - n(v, 'invest'))}\nROI: ${pct((n(v, 'return') - n(v, 'invest')) / n(v, 'invest'))}`; }),
  tool('payback', FI, 'Amortisationsdauer', 'Wann sich eine Anschaffung bezahlt macht.', [F.num('invest', 'Anschaffung (€)', 1200), F.num('monthly', 'Ersparnis/Mehrgewinn pro Monat (€)', 150)], v => { need(n(v, 'monthly') > 0, 'Monatlichen Nutzen angeben.'); return `Amortisiert nach: ${num(n(v, 'invest') / n(v, 'monthly'), 1)} Monaten`; }),
  tool('compound', FI, 'Sparplan mit Zinseszins', 'Endkapital bei regelmäßiger Sparrate.', [F.num('start', 'Startkapital (€)', 1000), F.num('monthly', 'Monatliche Rate (€)', 100), F.num('rate', 'Zins pro Jahr (%)', 5), F.num('years', 'Jahre', 10)], v => {
    const r = n(v, 'rate') / 100 / 12, m = Math.round(n(v, 'years') * 12); let k = n(v, 'start');
    for (let i = 0; i < m; i++) k = k * (1 + r) + n(v, 'monthly');
    const paid = n(v, 'start') + n(v, 'monthly') * m;
    return `Eingezahlt: ${eur(paid)}\nEndkapital: ${eur(k)}\nZinsen: ${eur(k - paid)}\n(angenommener Zins, keine Garantie)`;
  }),
  tool('loan', FI, 'Kreditrate', 'Monatliche Rate eines Annuitätendarlehens.', [F.num('amount', 'Kreditbetrag (€)', 10000), F.num('rate', 'Sollzins pro Jahr (%)', 6.5), F.num('years', 'Laufzeit (Jahre)', 4)], v => {
    const r = n(v, 'rate') / 100 / 12, m = n(v, 'years') * 12; need(m > 0, 'Laufzeit angeben.');
    const rate = r ? (n(v, 'amount') * r) / (1 - Math.pow(1 + r, -m)) : n(v, 'amount') / m;
    return `Monatliche Rate: ${eur(rate)}\nGesamt zurück: ${eur(rate * m)}\nZinskosten: ${eur(rate * m - n(v, 'amount'))}`;
  }),
  tool('percent', FI, 'Prozentrechner', 'Prozentwert, Anteil und Veränderung.', [F.num('a', 'Wert A', 45), F.num('b', 'Wert B', 60)], v => {
    const a = n(v, 'a'), b = n(v, 'b');
    return `A ist ${b ? pct(a / b) : '–'} von B\nA % von B: ${num((a / 100) * b)}\nVeränderung A → B: ${a ? pct((b - a) / a) : '–'}`;
  }),
  tool('currency', FI, 'Währungsumrechner', 'Rechnet mit deinem eigenen Kurs (aktuellen Kurs bei der Bank nachsehen).', [F.num('amount', 'Betrag', 100), F.txt('from', 'Von', 'EUR'), F.txt('to', 'Nach', 'CHF'), F.num('rate', 'Kurs: 1 Von = x Nach', 0.94)], v => `${num(n(v, 'amount'))} ${t(v, 'from')} = ${num(n(v, 'amount') * n(v, 'rate'))} ${t(v, 'to')}\n1 ${t(v, 'to')} = ${n(v, 'rate') ? num(1 / n(v, 'rate'), 4) : '–'} ${t(v, 'from')}`),
  tool('skonto', FI, 'Skonto-Rechner', 'Lohnt sich frühes Zahlen?', [F.num('amount', 'Rechnungsbetrag (€)', 2000), F.num('skonto', 'Skonto (%)', 2), F.num('skontoDays', 'Skontofrist (Tage)', 10), F.num('netDays', 'Zahlungsziel (Tage)', 30)], v => {
    const s = n(v, 'skonto') / 100, d = n(v, 'netDays') - n(v, 'skontoDays'); need(d > 0, 'Zahlungsziel muss länger sein als die Skontofrist.');
    return `Ersparnis: ${eur(n(v, 'amount') * s)}\nEntspricht einem Jahreszins von ca. ${pct((s / (1 - s)) * (360 / d))}\nFaustregel: lohnt sich fast immer, wenn das Geld da ist.`;
  }),
  tool('invoice-no', FI, 'Rechnungsnummern', 'Fortlaufende Rechnungsnummern erzeugen.', [F.txt('prefix', 'Präfix', 'RE'), F.num('start', 'Startnummer', 1), F.num('count', 'Anzahl', 5)], v => { const y = new Date().getFullYear(); return Array.from({ length: Math.min(200, Math.max(1, Math.round(n(v, 'count')))) }, (_, i) => `${t(v, 'prefix')}-${y}-${String(n(v, 'start') + i).padStart(4, '0')}`).join('\n'); }),

  // ===== Produktivität (11) =====
  tool('pomodoro', PR, 'Pomodoro-Planer', 'Plant Aufgaben in 25-Minuten-Blöcken mit Pausen.', [F.area('tasks', 'Aufgaben: Minuten (eine pro Zeile)', 'Reel drehen: 50\nCaptions schreiben: 25\nE-Mails: 25'), F.txt('start', 'Start (HH:MM)', '09:00')], v => {
    const [h, m] = t(v, 'start').split(':').map(Number); need(Number.isFinite(h) && Number.isFinite(m), 'Startzeit als HH:MM.');
    let min = h * 60 + m, block = 0; const out: string[] = []; const f = (x: number) => `${String(Math.floor(x / 60) % 24).padStart(2, '0')}:${String(x % 60).padStart(2, '0')}`;
    for (const l of lines(t(v, 'tasks'))) { const [name, mins = '25'] = l.split(':'); let left = Number(mins) || 25; while (left > 0) { const d = Math.min(25, left); out.push(`${f(min)}–${f(min + d)} ${name.trim()}`); min += d; left -= d; block++; const p = block % 4 === 0 ? 15 : 5; out.push(`${f(min)}–${f(min + p)} Pause`); min += p; } }
    return out.join('\n');
  }),
  tool('date-calc', PR, 'Datumsrechner', 'Datum plus Tage oder Werktage.', [F.txt('date', 'Startdatum (JJJJ-MM-TT)', new Date().toISOString().slice(0, 10)), F.num('days', 'Tage', 14), F.sel('mode', 'Zählen', ['Kalendertage', 'Werktage (Mo–Fr)'])], v => {
    const d = parseDate(t(v, 'date')); let left = Math.round(n(v, 'days'));
    if (t(v, 'mode') === 'Kalendertage') d.setDate(d.getDate() + left); else { while (left > 0) { d.setDate(d.getDate() + 1); if (d.getDay() % 6 !== 0) left--; } }
    return `Ergebnis: ${fmtDate(d)}`;
  }),
  tool('countdown', PR, 'Tage bis …', 'Countdown bis zu einem Datum.', [F.txt('date', 'Zieldatum (JJJJ-MM-TT)', `${new Date().getFullYear()}-12-24`), F.txt('label', 'Ereignis', 'Weihnachts-Aktion')], v => {
    const d = parseDate(t(v, 'date')), now = new Date(); now.setHours(0, 0, 0, 0); const diff = Math.round((d.getTime() - now.getTime()) / 864e5);
    let wd = 0; for (let x = new Date(now); x < d; x.setDate(x.getDate() + 1)) if (x.getDay() % 6 !== 0) wd++;
    return `${t(v, 'label')}: ${diff >= 0 ? `noch ${diff} Tage (${wd} Werktage)` : `vor ${-diff} Tagen`}`;
  }),
  tool('kw-week', PR, 'Kalenderwoche', 'ISO-Kalenderwoche eines Datums.', [F.txt('date', 'Datum (JJJJ-MM-TT)', new Date().toISOString().slice(0, 10))], v => {
    const d = parseDate(t(v, 'date')), x = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate())); const day = x.getUTCDay() || 7; x.setUTCDate(x.getUTCDate() + 4 - day);
    const y0 = new Date(Date.UTC(x.getUTCFullYear(), 0, 1)); const w = Math.ceil(((x.getTime() - y0.getTime()) / 864e5 + 1) / 7);
    return `KW ${w} / ${x.getUTCFullYear()}`;
  }),
  tool('eisenhower', PR, 'Eisenhower-Matrix', 'Sortiert Aufgaben nach wichtig/dringend. Markiere mit !w (wichtig) und !d (dringend).', [F.area('tasks', 'Aufgaben', 'Steuererklärung !w !d\nReel schneiden !w\nE-Mail beantworten !d\nInstagram scrollen')], v => {
    const q: Record<string, string[]> = { 'Sofort erledigen (wichtig + dringend)': [], 'Planen (wichtig)': [], 'Abgeben (dringend)': [], 'Streichen': [] };
    lines(t(v, 'tasks')).forEach(l => { const w = /!w/i.test(l), d = /!d/i.test(l), name = l.replace(/!w|!d/gi, '').trim(); q[w && d ? 'Sofort erledigen (wichtig + dringend)' : w ? 'Planen (wichtig)' : d ? 'Abgeben (dringend)' : 'Streichen'].push(name); });
    return Object.entries(q).map(([k, ts]) => `${k}:\n${ts.map(x => `• ${x}`).join('\n') || '–'}`).join('\n\n');
  }),
  tool('smart', PR, 'SMART-Ziel', 'Formuliert ein messbares Ziel.', [F.txt('what', 'Was?', 'Instagram-Follower steigern'), F.num('target', 'Zielwert', 15000), F.txt('unit', 'Einheit', 'Follower'), F.txt('date', 'Bis wann?', '31.03.2027'), F.txt('how', 'Wie?', '4 Reels pro Woche und tägliche Storys')], v => `Ich will ${t(v, 'what').toLowerCase()} auf ${num(n(v, 'target'), 0)} ${t(v, 'unit')} bis ${t(v, 'date')}, indem ich ${t(v, 'how')}.\n\nCheck: Spezifisch ✓ Messbar ✓ Terminiert ✓ – ist es für dich erreichbar und relevant?`),
  tool('week-plan', PR, 'Wochenplan in Zeitblöcken', 'Verteilt Stunden pro Thema auf die Woche.', [F.area('topics', 'Thema: Stunden pro Woche', 'Content erstellen: 8\nCommunity: 3\nKooperationen: 2\nLernen: 2'), F.num('days', 'Arbeitstage', 5)], v => {
    const d = Math.max(1, Math.round(n(v, 'days'))), names = ['Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa', 'So'].slice(0, d);
    return lines(t(v, 'topics')).map(l => { const [k, h = '0'] = l.split(':'); const per = Number(h.replace(',', '.')) / d; return `${k.trim()}: ${names.map(x => `${x} ${num(per * 60, 0)} Min.`).join(' · ')}`; }).join('\n');
  }),
  tool('meeting-cost', PR, 'Meeting-Kosten', 'Was ein Meeting kostet.', [F.num('people', 'Teilnehmer', 4), F.num('rate', 'Ø Stundensatz (€)', 45), F.num('minutes', 'Dauer (Minuten)', 60)], v => `Kosten: ${eur((n(v, 'people') * n(v, 'rate') * n(v, 'minutes')) / 60)}`),
  tool('timezones', PR, 'Zeitzonen', 'Uhrzeit in anderen Zeitzonen.', [F.txt('time', 'Uhrzeit (HH:MM, deine Zone)', '18:00'), F.txt('date', 'Datum (JJJJ-MM-TT)', new Date().toISOString().slice(0, 10))], v => {
    const [h, m] = t(v, 'time').split(':').map(Number), d = parseDate(t(v, 'date')); d.setHours(h || 0, m || 0, 0, 0);
    return ['Europe/Berlin', 'Europe/London', 'America/New_York', 'America/Los_Angeles', 'Asia/Dubai', 'Asia/Tokyo', 'Australia/Sydney'].map(z => `${z.split('/')[1].replace('_', ' ')}: ${d.toLocaleString('de-DE', { timeZone: z, weekday: 'short', hour: '2-digit', minute: '2-digit' })}`).join('\n');
  }),
  tool('picker', PR, 'Zufallsauswahl / Gewinner', 'Zieht fair (kryptografischer Zufall) aus einer Liste.', [F.area('list', 'Teilnehmer (einer pro Zeile)', '@anna\n@ben\n@cara\n@dennis\n@emma'), F.num('count', 'Anzahl Gewinner', 1)], v => {
    const l = Array.from(new Set(lines(t(v, 'list')))); need(l.length > 0, 'Teilnehmer eingeben.'); const k = Math.min(l.length, Math.max(1, Math.round(n(v, 'count')))); const out: string[] = []; const pool = [...l];
    while (out.length < k) out.push(pool.splice(rnd(pool.length), 1)[0]);
    return `Gezogen am ${new Date().toLocaleString('de-DE')} aus ${l.length} Teilnehmern (Duplikate entfernt):\n${out.map((x, i) => `${i + 1}. ${x}`).join('\n')}`;
  }),
  tool('checklist', PR, 'Checklisten', 'Fertige Checklisten zum Abhaken.', [F.sel('type', 'Checkliste', ['Produkt-Launch', 'Kooperation', 'Neuer Blogartikel', 'Shop-Start'])], v => ({
    'Produkt-Launch': ['Produktseite mit Fotos & Texten', 'Preise & Versand geprüft', 'Rechtstexte aktuell', 'E-Mail an Liste vorbereitet', '3 Social-Posts geplant', 'Gutscheincode angelegt', 'Tracking (UTM) gesetzt'],
    'Kooperation': ['Briefing schriftlich', 'Leistungen & Fristen klar', 'Nutzungsrechte geklärt', 'Honorar & Zahlungsziel', 'Kennzeichnung „Anzeige“', 'Freigabe eingeholt', 'Statistik nach 7 Tagen geschickt'],
    'Neuer Blogartikel': ['Keyword recherchiert', 'Titel & Meta-Description', 'Zwischenüberschriften', 'Bilder mit Alt-Text', 'Interne Links', 'Affiliate-Links gekennzeichnet', 'In Social Media geteilt'],
    'Shop-Start': ['Impressum vollständig', 'AGB, Widerruf, Datenschutz', 'Zahlungsarten getestet', 'Testbestellung durchgeführt', 'Versandkosten klar', 'Cookie-Banner', 'Google Search Console'],
  } as Record<string, string[]>)[t(v, 'type')].map(x => `☐ ${x}`).join('\n')),

  // ===== Daten & Umwandlung (12) =====
  tool('csv-table', DA, 'CSV → Tabelle', 'Wandelt CSV (Komma oder Semikolon) in eine Markdown-Tabelle.', [F.area('csv', 'CSV', 'Produkt;Preis;Klicks\nSet A;29;120\nSet B;35;80')], v => {
    const rows = lines(t(v, 'csv')).map(l => l.split(l.includes(';') ? ';' : ',').map(c => c.trim())); need(rows.length > 0, 'CSV einfügen.');
    return [`| ${rows[0].join(' | ')} |`, `|${rows[0].map(() => '---').join('|')}|`, ...rows.slice(1).map(r => `| ${r.join(' | ')} |`)].join('\n');
  }),
  tool('json-format', DA, 'JSON prüfen & formatieren', 'Prüft JSON und rückt es ein.', [F.area('json', 'JSON', '{"name":"Set A","preis":29,"tags":["fitness","home"]}')], v => { try { return json(JSON.parse(t(v, 'json'))); } catch (e: any) { throw new Error('Ungültiges JSON: ' + e.message); } }),
  tool('sort-dedupe', DA, 'Liste sortieren & bereinigen', 'Sortiert, entfernt Duplikate und Leerzeilen.', [F.area('list', 'Liste', 'Banane\nApfel\napfel\nKirsche\nBanane'), F.sel('mode', 'Sortierung', ['A–Z', 'Z–A', 'Original'])], v => {
    const seen = new Set<string>(); const l = lines(t(v, 'list')).filter(x => { const k = x.toLowerCase(); if (seen.has(k)) return false; seen.add(k); return true; });
    const s = t(v, 'mode') === 'A–Z' ? l.sort((a, b) => a.localeCompare(b, 'de')) : t(v, 'mode') === 'Z–A' ? l.sort((a, b) => b.localeCompare(a, 'de')) : l;
    return `${s.join('\n')}\n\n(${s.length} Einträge)`;
  }),
  tool('prefix-suffix', DA, 'Präfix/Suffix für jede Zeile', 'Setzt Text vor oder hinter jede Zeile.', [F.area('list', 'Zeilen', 'fitness\nhomeworkout\nyoga'), F.txt('pre', 'Davor', '#'), F.txt('post', 'Dahinter', '')], v => lines(t(v, 'list')).map(l => `${t(v, 'pre')}${l}${t(v, 'post')}`).join('\n')),
  tool('top-words', DA, 'Häufigste Wörter', 'Die häufigsten Wörter eines Textes (ohne Füllwörter).', [F.area('text', 'Text', SAMPLE)], v => {
    const stop = new Set('der die das und oder in im mit für ist sind zu ein eine einer auf von den dem des sich nicht es du ich wir sie er als auch an bei aus wie so weil kaum halt'.split(' '));
    const c = new Map<string, number>(); words(t(v, 'text').toLowerCase().replace(/[^\p{L}\p{N}\s-]/gu, ' ')).filter(w => w.length > 2 && !stop.has(w)).forEach(w => c.set(w, (c.get(w) || 0) + 1));
    return [...c].sort((a, b) => b[1] - a[1]).slice(0, 15).map(([w, k]) => `${w}: ${k}`).join('\n') || 'Keine Wörter gefunden.';
  }),
  tool('extract-emails', DA, 'E-Mail-Adressen herausfiltern', 'Findet E-Mail-Adressen in einem Text.', [F.area('text', 'Text', 'Kontakt: anna@beispiel.de, Ben (ben.k@firma.com) und info@shop.at')], v => { const m = Array.from(new Set(t(v, 'text').match(/[\w.+-]+@[\w-]+\.[\w.-]+/g) || [])); return m.length ? `${m.join('\n')}\n\n(${m.length} gefunden)` : 'Keine E-Mail-Adressen gefunden.'; }),
  tool('extract-links', DA, 'Links herausfiltern', 'Findet alle URLs in einem Text.', [F.area('text', 'Text', 'Hier https://goalsforce.store und www.example.com/test sowie https://amzn.to/abc')], v => { const m = Array.from(new Set(t(v, 'text').match(/(https?:\/\/[^\s)]+|www\.[^\s)]+)/g) || [])); return m.length ? m.join('\n') : 'Keine Links gefunden.'; }),
  tool('password', DA, 'Passwort-Generator', 'Sichere Zufallspasswörter.', [F.num('len', 'Länge', 16), F.num('count', 'Anzahl', 5), F.sel('symbols', 'Sonderzeichen', ['Ja', 'Nein'])], v => {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789' + (t(v, 'symbols') === 'Ja' ? '!#$%&*+-=?@_' : '');
    const len = Math.min(64, Math.max(8, Math.round(n(v, 'len')))); return Array.from({ length: Math.min(20, Math.max(1, Math.round(n(v, 'count')))) }, () => Array.from({ length: len }, () => chars[rnd(chars.length)]).join('')).join('\n');
  }),
  tool('uuid', DA, 'UUID-Generator', 'Eindeutige IDs (Version 4).', [F.num('count', 'Anzahl', 5)], v => Array.from({ length: Math.min(50, Math.max(1, Math.round(n(v, 'count')))) }, () => crypto.randomUUID()).join('\n')),
  tool('base64', DA, 'Base64', 'Text in Base64 kodieren oder zurück.', [F.area('text', 'Text', 'Hallo Goalsforce!'), F.sel('mode', 'Richtung', ['kodieren', 'dekodieren'])], v => {
    if (t(v, 'mode') === 'kodieren') return btoa(Array.from(new TextEncoder().encode(t(v, 'text')), b => String.fromCharCode(b)).join(''));
    try { return new TextDecoder().decode(Uint8Array.from(atob(t(v, 'text')), c => c.charCodeAt(0))); } catch { throw new Error('Das ist kein gültiges Base64.'); }
  }),
  tool('url-encode', DA, 'URL kodieren', 'Sonderzeichen für Links kodieren oder zurück.', [F.txt('text', 'Text', 'Fitness für zuhause & unterwegs'), F.sel('mode', 'Richtung', ['kodieren', 'dekodieren'])], v => { try { return t(v, 'mode') === 'kodieren' ? encodeURIComponent(t(v, 'text')) : decodeURIComponent(t(v, 'text')); } catch { throw new Error('Ungültige Kodierung.'); } }),
  tool('contrast', DA, 'Farbkontrast (WCAG)', 'Ist Text auf dieser Hintergrundfarbe gut lesbar?', [F.txt('fg', 'Textfarbe (Hex)', '#020617'), F.txt('bg', 'Hintergrund (Hex)', '#fbbf24')], v => {
    const a = lum(hexToRgb(t(v, 'fg'))), b = lum(hexToRgb(t(v, 'bg'))), r = (Math.max(a, b) + 0.05) / (Math.min(a, b) + 0.05);
    return `Kontrast: ${num(r, 2)} : 1\nNormaler Text (AA, ≥ 4,5): ${r >= 4.5 ? '✅' : '❌'}\nGroßer Text (AA, ≥ 3): ${r >= 3 ? '✅' : '❌'}\nAAA (≥ 7): ${r >= 7 ? '✅' : '❌'}`;
  }),
];

export const slugForTool = slug;
