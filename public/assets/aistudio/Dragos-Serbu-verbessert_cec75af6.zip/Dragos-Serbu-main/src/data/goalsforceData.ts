export interface GoalsforceProduct {
  id: string;
  dayTime: 'Morgen (Yoga & Mobility)' | 'Tag (Krafttraining & Home-Gym)' | 'Abend (Regeneration & Wellness)';
  title: string;
  sku: string;
  supplier: string; // e.g. "DSers / AliExpress EU-Lager Spanien"
  warehouse: 'EU-Lager (Spanien/Polen)' | 'Zentrallager (China/Drittland)';
  purchasePrice: number; // Einkauf
  shippingCost: number; // Versand
  customsFee: number; // 3€ Zollpauschale bei Drittland, 0€ bei EU-Lager
  totalCost: number; // Einkauf + Versand + Zoll
  minSellingPrice: number; // 2,5 * Gesamtkosten
  sellingPrice: number; // Tatsächlicher VK (brutto)
  netSellingPrice: number; // VK netto (ohne 19% MwSt.)
  paymentFee: number; // ~2.5% + 0.30€
  returnReserve: number; // ~3%
  contributionMarginNet: number; // DB = Netto - EK - Versand - Zoll - Gebühr - Retoure
  contributionMarginPercent: number; // DB / Netto
  channelDecision: 'Shop-Verkauf (Dropshipping)' | 'Affiliate-Empfehlung';
  image: string;
  usp: string;
  gpsr: {
    manufacturer: string;
    euResponsible: string;
    productIdentifier: string;
    safetyNotes: string;
  };
}

export const GOALSFORCE_PRODUCTS: GoalsforceProduct[] = [
  // --- MORGEN: YOGA & MOBILITY ---
  {
    id: 'gf-01',
    dayTime: 'Morgen (Yoga & Mobility)',
    title: 'Faltbare TPE-Akupressur & Mobility-Matte (Kompakt 4mm)',
    sku: 'GF-MAT-001',
    supplier: 'DSers / AliExpress EU-Lager Polen (DHL 3-4 Tage)',
    warehouse: 'EU-Lager (Spanien/Polen)',
    purchasePrice: 9.20,
    shippingCost: 3.50,
    customsFee: 0.00,
    totalCost: 12.70,
    minSellingPrice: 31.75, // 2.5x 12.70
    sellingPrice: 34.90,
    netSellingPrice: 29.33,
    paymentFee: 1.17,
    returnReserve: 1.05,
    contributionMarginNet: 13.41,
    contributionMarginPercent: 45.7, // > 30% -> Shop
    channelDecision: 'Shop-Verkauf (Dropshipping)',
    image: '/src/assets/images/goalsforce_mobility_mat_1792640754588.jpg',
    usp: 'Lässt sich auf 35x25cm falten, passt unter jedes Bett oder ins Regal. Laser-Ausrichtungslinien.',
    gpsr: {
      manufacturer: 'Kaizen Mobility Tech Co., Ltd., Ningbo, CN',
      euResponsible: 'Goalsforce EU Compliance Rep, Westhafen Tower, 60327 Frankfurt am Main',
      productIdentifier: 'EAN: 4260981240019 / Art.-Nr. GF-MAT-001',
      safetyNotes: 'Schadstoffgeprüftes TPE. Rutschfeste Unterseite. Nur auf ebenen Böden verwenden.',
    }
  },
  {
    id: 'gf-02',
    dayTime: 'Morgen (Yoga & Mobility)',
    title: 'Naturkork Mobility-Block & Doppel-Faszienball Set',
    sku: 'GF-KORK-002',
    supplier: 'DSers / AliExpress EU-Lager Spanien (GLS 3-5 Tage)',
    warehouse: 'EU-Lager (Spanien/Polen)',
    purchasePrice: 5.40,
    shippingCost: 2.80,
    customsFee: 0.00,
    totalCost: 8.20,
    minSellingPrice: 20.50,
    sellingPrice: 24.90,
    netSellingPrice: 20.92,
    paymentFee: 0.92,
    returnReserve: 0.75,
    contributionMarginNet: 11.05,
    contributionMarginPercent: 52.8,
    channelDecision: 'Shop-Verkauf (Dropshipping)',
    image: '/src/assets/images/goalsforce_mobility_mat_1792640754588.jpg',
    usp: '100% portugiesischer Naturkork. Ideal für Schulter- und Brustwirbelsäulen-Mobilisierung morgens.',
    gpsr: {
      manufacturer: 'Iberia Cork Ergonomics S.L., Porto, PT',
      euResponsible: 'Goalsforce EU Compliance Rep, Westhafen Tower, 60327 Frankfurt am Main',
      productIdentifier: 'EAN: 4260981240026 / Art.-Nr. GF-KORK-002',
      safetyNotes: 'Biologisch abbaubar. Frei von Weichmachern. Trocken lagern.',
    }
  },
  {
    id: 'gf-03',
    dayTime: 'Morgen (Yoga & Mobility)',
    title: 'Elastisches Dehnband mit 8 Griffschlaufen (Numeriert)',
    sku: 'GF-STR-003',
    supplier: 'DSers / AliExpress Zentrallager (Special Line YW)',
    warehouse: 'Zentrallager (China/Drittland)',
    purchasePrice: 2.80,
    shippingCost: 2.40,
    customsFee: 3.00, // Drittland Zollpauschale
    totalCost: 8.20,
    minSellingPrice: 20.50,
    sellingPrice: 22.90,
    netSellingPrice: 19.24,
    paymentFee: 0.87,
    returnReserve: 0.69,
    contributionMarginNet: 9.48,
    contributionMarginPercent: 49.3,
    channelDecision: 'Shop-Verkauf (Dropshipping)',
    image: '/src/assets/images/goalsforce_mobility_mat_1792640754588.jpg',
    usp: 'Progressive Dehnstufen ohne Nachgreifen. Passt in die Hosentasche für Morning Routines.',
    gpsr: {
      manufacturer: 'FlexStretch Sports Ltd., Yiwu, CN',
      euResponsible: 'Goalsforce EU Compliance Rep, Westhafen Tower, 60327 Frankfurt am Main',
      productIdentifier: 'EAN: 4260981240033 / Art.-Nr. GF-STR-003',
      safetyNotes: 'Gewebter Naturlatex. Vor scharfen Kanten schützen.',
    }
  },
  {
    id: 'gf-04',
    dayTime: 'Morgen (Yoga & Mobility)',
    title: 'Peloton Guide KI-Kamera für Formkorrektur',
    sku: 'GF-AFF-001',
    supplier: 'Peloton Affiliate Programm / Amazon PartnerNet',
    warehouse: 'EU-Lager (Spanien/Polen)',
    purchasePrice: 195.00,
    shippingCost: 0,
    customsFee: 0,
    totalCost: 195.00,
    minSellingPrice: 487.50,
    sellingPrice: 225.00,
    netSellingPrice: 189.08,
    paymentFee: 0,
    returnReserve: 0,
    contributionMarginNet: -5.92, // Zu teuer für Dropshipping, Marge negativ
    contributionMarginPercent: -3.1,
    channelDecision: 'Affiliate-Empfehlung', // Affiliate Link empfohlen!
    image: '/src/assets/images/goalsforce_mobility_mat_1792640754588.jpg',
    usp: 'Smarte Kamera mit Motion Tracking fürs Wohnzimmer. Hoher Warenwert → 7% Affiliate-Provision = 15,75 € pro Verkauf ohne Kapitalbindung!',
    gpsr: {
      manufacturer: 'Peloton Interactive Inc., New York, USA',
      euResponsible: 'Peloton Interactive Deutschland GmbH, Berlin',
      productIdentifier: 'Peloton Guide ASIN B0B123XYZ',
      safetyNotes: 'Offizielles Markenprodukt. Garantie und Support durch Hersteller.',
    }
  },

  // --- TAG: KRAFTTRAINING & HOME-GYM FÜR KLEINE WOHNUNGEN ---
  {
    id: 'gf-05',
    dayTime: 'Tag (Krafttraining & Home-Gym)',
    title: 'Stackable Multi-Resistance Tubes Set (bis 68 kg)',
    sku: 'GF-RES-005',
    supplier: 'DSers / AliExpress EU-Lager Spanien (GLS 3-5 Tage)',
    warehouse: 'EU-Lager (Spanien/Polen)',
    purchasePrice: 11.50,
    shippingCost: 4.20,
    customsFee: 0.00,
    totalCost: 15.70,
    minSellingPrice: 39.25,
    sellingPrice: 44.90,
    netSellingPrice: 37.73,
    paymentFee: 1.42,
    returnReserve: 1.35,
    contributionMarginNet: 19.26,
    contributionMarginPercent: 51.0,
    channelDecision: 'Shop-Verkauf (Dropshipping)',
    image: '/src/assets/images/goalsforce_resistance_bands_1792640768768.jpg',
    usp: 'Komplettes Ganzkörper-Gym im 1 kg Beutel mit Türanker, Fußschlaufen & Schaumstoffgriffen.',
    gpsr: {
      manufacturer: 'Velocity Elastic Polymer Co., Hangzhou, CN',
      euResponsible: 'Goalsforce EU Compliance Rep, Westhafen Tower, 60327 Frankfurt am Main',
      productIdentifier: 'EAN: 4260981240057 / Art.-Nr. GF-RES-005',
      safetyNotes: 'Schwerlast-Karabiner. Vor jedem Training Bänder auf Mikrorisse prüfen.',
    }
  },
  {
    id: 'gf-06',
    dayTime: 'Tag (Krafttraining & Home-Gym)',
    title: 'Kompakte No-Screw Klimmzugstange mit Wasserwaage',
    sku: 'GF-BAR-006',
    supplier: 'DSers / AliExpress EU-Lager Polen (DPD 3-4 Tage)',
    warehouse: 'EU-Lager (Spanien/Polen)',
    purchasePrice: 16.80,
    shippingCost: 5.50,
    customsFee: 0.00,
    totalCost: 22.30,
    minSellingPrice: 55.75,
    sellingPrice: 59.90,
    netSellingPrice: 50.34,
    paymentFee: 1.80,
    returnReserve: 1.80,
    contributionMarginNet: 24.44,
    contributionMarginPercent: 48.5,
    channelDecision: 'Shop-Verkauf (Dropshipping)',
    image: '/src/assets/images/goalsforce_resistance_bands_1792640768768.jpg',
    usp: 'Kein Bohren, keine Abdrücke im Türrahmen. Patentierte Spreizklemmung hält bis 200 kg.',
    gpsr: {
      manufacturer: 'Apex Strength Gear, Shenzhen, CN',
      euResponsible: 'Goalsforce EU Compliance Rep, Westhafen Tower, 60327 Frankfurt am Main',
      productIdentifier: 'EAN: 4260981240064 / Art.-Nr. GF-BAR-006',
      safetyNotes: 'Nur in massiven Türrahmen (70-90cm Breite) montieren. TÜV-geprüfte Lastgrenze 200 kg.',
    }
  },
  {
    id: 'gf-07',
    dayTime: 'Tag (Krafttraining & Home-Gym)',
    title: 'Verstellbare Kurzhantel 24 kg (SelectTech System)',
    sku: 'GF-AFF-002',
    supplier: 'Bowflex / Amazon PartnerNet Programm',
    warehouse: 'EU-Lager (Spanien/Polen)',
    purchasePrice: 160.00,
    shippingCost: 19.90,
    customsFee: 0.00,
    totalCost: 179.90,
    minSellingPrice: 449.75,
    sellingPrice: 229.00,
    netSellingPrice: 192.44,
    paymentFee: 0,
    returnReserve: 0,
    contributionMarginNet: 12.54, // Unter 30% Marge wegen extrem hohem Speditionsversand
    contributionMarginPercent: 6.5,
    channelDecision: 'Affiliate-Empfehlung', // Affiliate-Empfehlung!
    image: '/src/assets/images/goalsforce_resistance_bands_1792640768768.jpg',
    usp: 'Ersetzt 15 Hanteln auf 0.2 m². Zu schwer für günstiges Dropshipping → Empfehlung via Amazon (6% Provision = 13,74 €).',
    gpsr: {
      manufacturer: 'Nautilus Inc. / Bowflex, Vancouver, USA',
      euResponsible: 'Bowflex Europe GmbH, München',
      productIdentifier: 'Bowflex SelectTech 552i ASIN B001ARYU58',
      safetyNotes: 'GS-Zertifizierung. Nur auf Hantelständer oder stoßdämpfenden Matten ablegen.',
    }
  },
  {
    id: 'gf-08',
    dayTime: 'Tag (Krafttraining & Home-Gym)',
    title: 'Ergonomische Push-Up Griffe & Core-Slider Kombi',
    sku: 'GF-PUSH-008',
    supplier: 'DSers / AliExpress Zentrallager (Special Line)',
    warehouse: 'Zentrallager (China/Drittland)',
    purchasePrice: 4.80,
    shippingCost: 3.20,
    customsFee: 3.00,
    totalCost: 11.00,
    minSellingPrice: 27.50,
    sellingPrice: 29.90,
    netSellingPrice: 25.13,
    paymentFee: 1.05,
    returnReserve: 0.90,
    contributionMarginNet: 12.18,
    contributionMarginPercent: 48.5,
    channelDecision: 'Shop-Verkauf (Dropshipping)',
    image: '/src/assets/images/goalsforce_resistance_bands_1792640768768.jpg',
    usp: 'Gelenkschonende Handgelenkstellung bei Liegestützen + Gleitscheiben für Sixpack-Training auf Teppich/Parkett.',
    gpsr: {
      manufacturer: 'CoreFlow Fitness Equipment, Ningbo, CN',
      euResponsible: 'Goalsforce EU Compliance Rep, Westhafen Tower, 60327 Frankfurt am Main',
      productIdentifier: 'EAN: 4260981240088 / Art.-Nr. GF-PUSH-008',
      safetyNotes: 'Rutschfeste TPR-Pads. Bis 150 kg Körpergewicht belastbar.',
    }
  },

  // --- ABEND: REGENERATION & WELLNESS ---
  {
    id: 'gf-09',
    dayTime: 'Abend (Regeneration & Wellness)',
    title: 'Mini Pocket-Faszienpistole (Ultra-Quiet 40dB, 4 Aufsätze)',
    sku: 'GF-GUN-009',
    supplier: 'DSers / AliExpress EU-Lager Spanien (GLS 3-5 Tage)',
    warehouse: 'EU-Lager (Spanien/Polen)',
    purchasePrice: 15.20,
    shippingCost: 3.90,
    customsFee: 0.00,
    totalCost: 19.10,
    minSellingPrice: 47.75,
    sellingPrice: 54.90,
    netSellingPrice: 46.13,
    paymentFee: 1.67,
    returnReserve: 1.65,
    contributionMarginNet: 23.71,
    contributionMarginPercent: 51.4,
    channelDecision: 'Shop-Verkauf (Dropshipping)',
    image: '/src/assets/images/goalsforce_massage_gun_1792640783068.jpg',
    usp: 'Aluminium-Gehäuse im Taschenformat (480 g). Löste Verspannungen nach dem Feierabend in 10 Minuten.',
    gpsr: {
      manufacturer: 'TheraSage Recovery Tech Ltd., Shenzhen, CN',
      euResponsible: 'Goalsforce EU Compliance Rep, Westhafen Tower, 60327 Frankfurt am Main',
      productIdentifier: 'EAN: 4260981240095 / Art.-Nr. GF-GUN-009',
      safetyNotes: 'CE & RoHS zertifiziert. USB-C Ladekabel. Nicht direkt auf Knochen oder Gelenken anwenden.',
    }
  },
  {
    id: 'gf-10',
    dayTime: 'Abend (Regeneration & Wellness)',
    title: 'Beheizbares Akupressur Nacken- & Lendentraktionskissen',
    sku: 'GF-PIL-010',
    supplier: 'DSers / AliExpress EU-Lager Polen (DHL 3-4 Tage)',
    warehouse: 'EU-Lager (Spanien/Polen)',
    purchasePrice: 10.40,
    shippingCost: 3.60,
    customsFee: 0.00,
    totalCost: 14.00,
    minSellingPrice: 35.00,
    sellingPrice: 39.90,
    netSellingPrice: 33.53,
    paymentFee: 1.30,
    returnReserve: 1.20,
    contributionMarginNet: 17.03,
    contributionMarginPercent: 50.8,
    channelDecision: 'Shop-Verkauf (Dropshipping)',
    image: '/src/assets/images/goalsforce_acupressure_pillow_1792640798118.jpg',
    usp: 'Dehnt sanft die Halswirbelsäule mit 6 Akupressur-Knoten und 3-Stufen Wärmekern.',
    gpsr: {
      manufacturer: 'Lotus Luxe Wellness Goods, Dongguan, CN',
      euResponsible: 'Goalsforce EU Compliance Rep, Westhafen Tower, 60327 Frankfurt am Main',
      productIdentifier: 'EAN: 4260981240101 / Art.-Nr. GF-PIL-010',
      safetyNotes: 'Memory-Foam mit abnehmbarem Bezug. Automatische Abschaltung nach 30 Minuten.',
    }
  },
  {
    id: 'gf-11',
    dayTime: 'Abend (Regeneration & Wellness)',
    title: 'Therabody RecoveryAir JetBoots Kompressionsstiefel',
    sku: 'GF-AFF-003',
    supplier: 'AWIN / Therabody Partnerprogramm',
    warehouse: 'EU-Lager (Spanien/Polen)',
    purchasePrice: 620.00,
    shippingCost: 0,
    customsFee: 0,
    totalCost: 620.00,
    minSellingPrice: 1550.00,
    sellingPrice: 799.00,
    netSellingPrice: 671.43,
    paymentFee: 0,
    returnReserve: 0,
    contributionMarginNet: 51.43,
    contributionMarginPercent: 7.7,
    channelDecision: 'Affiliate-Empfehlung', // Zu teuer für Dropshipping
    image: '/src/assets/images/goalsforce_acupressure_pillow_1792640798118.jpg',
    usp: 'Kabellose pneumatische Kompression für müde Beine. 8% AWIN-Provision = 63,92 € pro Sale ohne Haftungsrisiko!',
    gpsr: {
      manufacturer: 'Therabody Inc., Los Angeles, USA',
      euResponsible: 'Therabody B.V., Amsterdam, NL',
      productIdentifier: 'RecoveryAir JetBoots EAN 0810036056343',
      safetyNotes: 'Medizinisches Wellness-Gerät. Nicht bei Venenthrombose verwenden.',
    }
  },
  {
    id: 'gf-12',
    dayTime: 'Abend (Regeneration & Wellness)',
    title: 'Vibrierende Mini-Massagekugel (3 Intensitätsstufen)',
    sku: 'GF-BALL-012',
    supplier: 'DSers / AliExpress Zentrallager (Special Line)',
    warehouse: 'Zentrallager (China/Drittland)',
    purchasePrice: 6.10,
    shippingCost: 2.80,
    customsFee: 3.00,
    totalCost: 11.90,
    minSellingPrice: 29.75,
    sellingPrice: 32.90,
    netSellingPrice: 27.65,
    paymentFee: 1.12,
    returnReserve: 0.99,
    contributionMarginNet: 13.64,
    contributionMarginPercent: 49.3,
    channelDecision: 'Shop-Verkauf (Dropshipping)',
    image: '/src/assets/images/goalsforce_acupressure_pillow_1792640798118.jpg',
    usp: 'Punktgenaue Tiefenmassage für Gesäß, Fußsohle und Nacken nach langem Sitzen.',
    gpsr: {
      manufacturer: 'VibraTech Sports, Huizhou, CN',
      euResponsible: 'Goalsforce EU Compliance Rep, Westhafen Tower, 60327 Frankfurt am Main',
      productIdentifier: 'EAN: 4260981240125 / Art.-Nr. GF-BALL-012',
      safetyNotes: 'IPX5 spritzwassergeschützt. Silikon-Oberfläche. CE-geprüft.',
    }
  }
];

export const CONNECTED_TOOLS_STATUS = [
  {
    name: 'Shopify Storefront & Admin API',
    domain: 'goalsforce.store',
    connected: true,
    status: 'Live & Synchron (Theme-Kopie im Entwurf)',
    details: 'Shopify Basic, Währung EUR (€), Standort Deutschland. Startseiten-Abschnitt „Aufwach-Shop“ eingerichtet.',
    badge: 'Kernsystem',
  },
  {
    name: 'DSers AliExpress Fulfillment Bridge',
    domain: 'dsers.com / app',
    connected: true,
    status: 'Verbunden (Auto-Order & Tracking)',
    details: 'Bevorzugter Filter: EU-Lager (Spanien & Polen) für 3-5 Tage Lieferzeit nach Deutschland. Automatische Preissynchronisation.',
    badge: 'Logistik',
  },
  {
    name: 'Metricool Social Media Planner',
    domain: 'app.metricool.com',
    connected: true,
    status: 'Verbunden (Planungsmodus: Entwurf)',
    details: 'Automatische Vorbereitung von Beiträgen für TikTok, Instagram Reels, Pinterest & YouTube Shorts. Keine Veröffentlichung ohne Freigabe.',
    badge: 'Social Media',
  },
  {
    name: 'Typefully Ghostwriting & Thread Planner',
    domain: 'typefully.com',
    connected: true,
    status: 'Verbunden (Entwurfs-Pipeline)',
    details: 'Textgenerierung für Threads, Newsletter & LinkedIn B2B Ergonomie-Tipps. Alle Beiträge im Prüfstatus.',
    badge: 'Content',
  },
  {
    name: 'Dropbox Cloud Asset Storage',
    domain: 'dropbox.com / goalsforce-media',
    connected: true,
    status: 'Verbunden (Media Hub)',
    details: 'Ordnerstruktur für Roh-Footage, CapCut-Schnittprojekte, Thumbnails und Produktdatenblätter (GPSR).',
    badge: 'Dateien',
  }
];

export const AFFILIATE_PROGRAMS_AUDIT = [
  {
    id: 'aff-amz',
    name: 'Amazon PartnerNet Deutschland',
    nicheFocus: 'Sperrige Fitnessgeräte (Bowflex, Laufbänder, Klimmzug-Stationen), Bücher & Zubehör',
    commission: 'bis zu 7% CPS (Kategorie Sport & Freizeit: 6-7%)',
    cookieDuration: '24 Stunden (90 Tage bei Warenkorb-Hinzufügung)',
    conditions: 'Strikte Kennzeichnungspflicht ("*Anzeige/Werbung*"). Keine Preisanzeigen ohne Echtzeit-API. Keine Links in geschlossenen E-Mails.',
    fitReason: 'Perfekt für Produkte über 150 €, die das Dropshipping-Risiko sprengen (Bowflex 552i Hanteln, Falt-Laufbänder für kleine Wohnungen).',
    status: 'Empfohlen & Bereit',
  },
  {
    id: 'aff-awin',
    name: 'AWIN (Decathlon, Therabody, Gymshark)',
    nicheFocus: 'Marken-Regeneration (Theragun, RecoveryAir JetBoots) und Premium Yoga Wear',
    commission: '8% bis 12% CPS (Ø 50–70 € pro Verkauf bei RecoveryAir)',
    cookieDuration: '30 Tage Post-Click Cookie',
    conditions: 'Zulassung nach Publisher-Prüfung. Banner & Deep-Links erlaubt. Automatische Retouren-Verrechnung nach 30 Tagen.',
    fitReason: 'Therabody & Decathlon genießen in Deutschland höchstes Vertrauen. Ermöglicht 4-stellige Warenkorbwerte ohne Vorfinanzierung.',
    status: 'Empfohlen & Bereit',
  },
  {
    id: 'aff-digistore',
    name: 'Digistore24 (Digitale Fitness-Programme & Mobility-Apps)',
    nicheFocus: 'Online-Kurse ("Spagat in 30 Tagen", "Rückenfit für Schreibtisch-Täter", Ernährungspläne)',
    commission: '30% bis 50% CPS (wiederkehrend bei Abos)',
    cookieDuration: '180 Tage First-Cookie-Wins',
    conditions: 'Automatische Abrechnung über Digistore24 GmbH (DE). Vollständige EU-Umsatzsteuerabwicklung.',
    fitReason: 'Ergänzt physische Shop-Produkte (z.B. Käufer der Faszienpistole erhält Empfehlung für einen digitalen Mobility-Video-Kurs). Reiner Gewinn ohne Versand!',
    status: 'Empfohlen & Bereit',
  }
];

export const CONTENT_CALENDAR_4WEEKS = [
  {
    week: 'Woche 1: Start & Morgen-Routine (Morgen-Fokus)',
    theme: 'Aufwachen mit Energie auf 5 m²',
    videos: [
      { title: 'Video 1: Vorher/Nachher Morgenroutine vs. Schlapp aufstehen', platform: 'TikTok / Reels', goal: 'Viral Hook' },
      { title: 'Video 2: 3 Übungen für einen schmerzfreien Rücken direkt nach dem Aufstehen', platform: 'Shorts / Reels', goal: 'Mehrwert & Saves' },
      { title: 'Video 3: Ehrlicher Test: Warum herkömmliche Yogamatten in kleinen Wohnungen nerven', platform: 'TikTok / Shorts', goal: 'Produktfokus Matte' },
    ],
    pins: '5x Pinterest Pins: „Morgenroutine für kleine Wohnungen“, „Yoga-Ecke im Schlafzimmer“, „Mobility-Übungen 10 Min“',
    seoArticle: 'Ratgeber #1: „Home-Gym auf 10 m²: So trainierst du effektiv ohne Platzverschwendung“',
    emailFlow: 'Welcome Mail #1: „Willkommen bei Goalsforce + Dein 10% Starter-Code auf alle Aufwach-Tools“',
  },
  {
    week: 'Woche 2: Krafttraining ohne Platzverlust (Tag-Fokus)',
    theme: 'Hypertrophie & Kraft auf kleinstem Raum',
    videos: [
      { title: 'Video 4: Das 1-kg-Home-Gym: Ganzer Körper mit Widerstandsbändern', platform: 'Reels / Shorts', goal: 'Bänder Set' },
      { title: 'Video 5: Hanteln vs. Bänder: Was bringt wirklich mehr Muskeln?', platform: 'TikTok', goal: 'Aufklärung & Debatte' },
      { title: 'Video 6: No-Screw Klimmzugstange: Hält das wirklich 100 kg an der Tür?', platform: 'TikTok / Reels', goal: 'Proof & Trust' },
    ],
    pins: '5x Pinterest Pins: „Ganzkörper-Workout ohne Hanteln“, „Klimmzugstange ohne Bohren Guide“, „Kompakte Home-Gym Ideen“',
    seoArticle: 'Ratgeber #2 (Teil 1): „Widerstandsbänder vs. Kurzhanteln: Die ehrlichste Analyse für kleine Räume“',
    emailFlow: 'Welcome Mail #2: „Die 3 größten Fehler beim Training in kleinen Räumen (und wie du sie vermeidest)“',
  },
  {
    week: 'Woche 3: Feierabend-Regeneration & Schlaf (Abend-Fokus)',
    theme: 'Verspannungen wegschmelzen in 10 Minuten',
    videos: [
      { title: 'Video 7: Faszienpistole richtig nutzen: 3 Spots gegen Nackenschmerzen', platform: 'Reels / Shorts', goal: 'Mini Gun' },
      { title: 'Video 8: 15 Minuten vor dem Schlafen: Meine Nacken-Traktions-Routine', platform: 'TikTok', goal: 'Traktionskissen' },
      { title: 'Video 9: Warum dein Muskelkater 3 Tage anhält (Der Durchblutungstrick)', platform: 'Shorts / Reels', goal: 'Kompression & Wellness' },
    ],
    pins: '5x Pinterest Pins: „Abendroutine gegen Verspannungen“, „Faszienpistole Guide für Anfänger“, „Besser schlafen durch Akupressur“',
    seoArticle: 'Ratgeber #3: „Regeneration nach dem Training: 4 wissenschaftliche Methoden, die wirklich wirken“',
    emailFlow: 'Welcome Mail #3: „Dein Feierabend-Reset: Wie du in 10 Minuten tiefer regenerierst“',
  },
  {
    week: 'Woche 4: Das Komplett-System & Review (Review-Fokus)',
    theme: 'Der 24h Aufwach-Shop: Ein Tag mit Goalsforce',
    videos: [
      { title: 'Video 10: 24h VLOG: Morgen Yoga, Mittags Bänder, Abends Faszienpistole', platform: 'Reels / Shorts / TikTok', goal: 'Bundle-Verkauf' },
      { title: 'Video 11: Meine 3 besten Affiliate-Tools für große Home-Gyms (Ehrlich)', platform: 'YouTube Shorts', goal: 'Amazon/Bowflex Affiliate' },
      { title: 'Video 12: Fehler & Lösung: Warum die meisten Home-Gyms nach 2 Monaten einstauben', platform: 'TikTok / Reels', goal: 'Motivation & Mindset' },
    ],
    pins: '5x Pinterest Pins: „Home-Gym Checkliste 2026“, „Beste Regenerationstools für Zuhause“, „Platzsparende Fitness-Musthaves“',
    seoArticle: 'SEO Ratgeber #4: „Die ultimative Checkliste: Wie du dein Home-Gym planst und motiviert bleibst“',
    emailFlow: 'Monats-Newsletter #1: „Top 3 Mobility-Moves des Monats + Neues aus der Goalsforce Community“',
  }
];

export const THREE_VIDEO_PACKAGES = [
  {
    id: 'vid-01',
    title: 'Video-Paket 1: Faltbare Akupressur-Matte (Morgen-Routine)',
    targetProduct: 'Faltbare TPE-Akupressur & Mobility-Matte (GF-MAT-001)',
    concept: {
      goal: 'Problem-Awareness lösen: Standard-Yogamatten sind sperrig, rollen sich wieder ein und nehmen Platz weg.',
      platform: 'TikTok, Instagram Reels, YouTube Shorts',
      length: '24 Sekunden',
      targetAudience: 'Leute mit kleinen 1-2 Zimmer Wohnungen, Homeoffice-Worker mit steifem Nacken/Rücken morgens.',
    },
    hooks: [
      'Variante A (Kontrast-Hook): „Wenn du deine Yogamatte immer noch irgendwo ins Eck rollst, machst du dir das Leben unnötig schwer…“',
      'Variante B (Problem-Hook): „Das hier ist der Grund, warum 90% der Leute ihre Morgen-Dehnung nach 3 Tagen abbrechen: der Platz.“',
      'Variante C (Visueller Stopp-Hook): „Schau mal, wie groß diese Matte ist – und jetzt schau, wie sie verschwindet!“ (Schnelles Falten im Video)',
    ],
    script: [
      { scene: '0-2s', text: 'Hook: Halte eine normal zusammengerollte, unordentliche Matte in die Kamera, genervter Blick.' },
      { scene: '2-7s', text: 'Schnitt: Ziehe die kompakte gefaltete Matte aus dem Bücherregal heraus wie ein Buch. Aufklappen mit einem Schwung.' },
      { scene: '7-14s', text: 'Action: Zeige die Ausrichtungslinien. Knie auf die Matte, 2 kurze sanfte Mobility-Moves (Cat-Cow, Kobra). Echte 4mm Dämpfung sichtbar.' },
      { scene: '14-19s', text: 'Fold-Demo: In 3 Sekunden wieder zusammenfalten, flach unter das Sofa oder ins Regal schieben. Boden sofort wieder frei!' },
      { scene: '19-24s', text: 'Call to Action: „Link im Profil im Aufwach-Shop unter Morgen-Tools. Versand direkt aus dem EU-Lager in 3 Tagen.“' }
    ],
    shotlist15Min: [
      { shot: 'Shot 1 (3 Min)', detail: 'Halbtotale: Unordentliche Matte im Zimmer, genervt zur Seite kicken.' },
      { shot: 'Shot 2 (3 Min)', detail: 'Nahaufnahme Regal: Gefaltete Matte zwischen Büchern herausnehmen.' },
      { shot: 'Shot 3 (4 Min)', detail: 'Top-Down Smartphone auf Tisch: Aufklappen mit Schwung auf Eichenboden.' },
      { shot: 'Shot 4 (3 Min)', detail: 'Aktion: 5 Sekunden Dehnübung auf Matte, Fokus auf gedämpfte Knie.' },
      { shot: 'Shot 5 (2 Min)', detail: 'Zusammenklappen in 3 Sekunden und unter Couch schieben.' }
    ],
    capcutPlan: {
      clipOrder: 'Clip 1 (Hook 0-2s) → Clip 2 (Regal 2-5s) → Clip 3 (Aufklappen 5-8s) → Clip 4 (Übung 8-15s) → Clip 5 (Fold 15-20s) → Outro (20-24s)',
      cuts: 'Dynamische Jump-Cuts auf Beat. Kein weicher Übergang. Schnitte bei Bewegung.',
      textOverlays: 'Große gelbe Schrift: „KEIN EINROLLEN MEHR“ (0-4s) | „4mm DÄMPFUNG & AUSRICHTUNG“ (8-12s) | „PASST INS REGAL“ (16-19s)',
      musicStyle: 'Upbeat Lo-Fi Chill Hop (z.B. „Morning Coffee Beats“ in CapCut lizenzfrei)',
    },
    subtitles: `Wenn du deine Yogamatte noch mühsam einrollst... machst du dir das Leben schwer. Diese Matte klappst du auf wie ein Buch. Perfekte Dämpfung auf 5 m². Und nach der Dehnung: zack, ab ins Regal. Link im Aufwach-Shop in der Bio!`,
    captionAndHashtags: `Kein Platz für ein Yoga-Studio? Kein Problem. 🙌 Die kompakteste Faltmatte für kleine Wohnungen. Link in Bio unter „Morgen: Yoga & Mobility“. #homegym #kleinewohnung #yogamatte #mobilityroutine #morgenroutine #goalsforce`,
    thumbnailIdea: 'Split-Screen: Links unordentliche Riesenmatte mit rotem Kreuz | Rechts ordentlich gefaltete Matte im Bücherregal mit grünem Häkchen.',
  },
  {
    id: 'vid-02',
    title: 'Video-Paket 2: Stackable Resistance Bands (Tag: Krafttraining)',
    targetProduct: 'Multi-Resistance Tubes Set bis 68 kg (GF-RES-005)',
    concept: {
      goal: 'Beweisen, dass man für echten Muskelaufbau keine 500 kg Hanteln im Wohnzimmer lagern muss.',
      platform: 'TikTok, Instagram Reels, YouTube Shorts',
      length: '28 Sekunden',
      targetAudience: 'Männer & Frauen (20-45 J.) in Mietwohnungen, die kein lautes Eisen abstellen können.',
    },
    hooks: [
      'Variante A (Wohnungs-Hook): „Wenn du in einer Mietwohnung wohnst, darfst du keine 80 kg Hanteln fallen lassen. Nutze stattdessen das hier…“',
      'Variante B (Gewichts-Hook): „Ein 68 kg Home-Gym, das weniger Platz braucht als ein Paar Schuhe.“',
      'Variante C (Frage-Hook): „Warum zahle ich noch 60 € im Monat fürs Fitnessstudio, wenn mein ganzer Trainingsplan an eine Zimmertür passt?“',
    ],
    script: [
      { scene: '0-3s', text: 'Hook: Türanker an der Wohnzimmertür einklemmen, Tür mit sicherem Klick schließen.' },
      { scene: '3-9s', text: 'Kombi-Clip: 2 Bänder in den Karabiner einklinken. Zeige die Beschriftung: „30 lbs + 40 lbs“.' },
      { scene: '9-16s', text: 'Übung 1 & 2: Latzug kniend zur Brust + Trizepsdrücken. Voller Muskeltonus sichtbar.' },
      { scene: '16-22s', text: 'Übung 3 & 4: Türanker unten einhaken → Bizepscurls und Brustdrücken.' },
      { scene: '22-28s', text: 'Outro: Bänder in die kleine Tasche stecken, Reißverschluss zu, ab in die Schublade. „Link im Aufwach-Shop!“' }
    ],
    shotlist15Min: [
      { shot: 'Shot 1 (3 Min)', detail: 'Türanker oben einklemmen, Tür schließt hörbar.' },
      { shot: 'Shot 2 (3 Min)', detail: 'Nahaufnahme: Karabiner einklinken, Hände spannen das Band an.' },
      { shot: 'Shot 3 (4 Min)', detail: 'Brustübung im Stehen, Smartphone auf Couch abgelegt, gute Beleuchtung.' },
      { shot: 'Shot 4 (3 Min)', detail: 'Türanker unten einsetzen, Bizepscurls mit konzentriertem Gesichtsausdruck.' },
      { shot: 'Shot 5 (2 Min)', detail: 'Packshot: Alles in den Beutel stecken und in Kommodenschublade legen.' }
    ],
    capcutPlan: {
      clipOrder: 'Tür zu (0-3s) → Clip Karabiner (3-6s) → Latzug (6-12s) → Curls (12-18s) → Schublade (18-24s) → Call-to-Action (24-28s)',
      cuts: 'Hard Cuts synchron zur Bassline.',
      textOverlays: '„BIS ZU 68 KG WIDERSTAND“ (3-7s) | „NULL LÄRM FÜR NACHBARN“ (10-15s) | „PASST IN JEDE SCHUBLADE“ (18-22s)',
      musicStyle: 'Punchy Workout Phonk oder Instrumental Trap Beats (energisch & motivierend)',
    },
    subtitles: `In einer Mietwohnung kannst du keine schweren Hanteln fallen lassen. Dieser Türanker hält bis 68 kg Widerstand. Latzug, Curls, Brust – alles lautlos. Nach 30 Minuten ab in die Schublade. Link in der Bio!`,
    captionAndHashtags: `Dein komplettes Krafttraining passt in eine Schublade. ⚡ Kein Lärm für die Nachbarn, kein Platzverlust. Schau in den Aufwach-Shop: Link in Bio! #homegym #krafttraining #widerstandsbänder #homeworkout #goalsforce`,
    thumbnailIdea: 'Großaufnahme Türanker unter Zug mit Text: „68 KG AN DEINER TÜR?“',
  },
  {
    id: 'vid-03',
    title: 'Video-Paket 3: Mini Pocket-Faszienpistole (Abend: Regeneration)',
    targetProduct: 'Mini Pocket-Faszienpistole Ultra-Quiet 40dB (GF-GUN-009)',
    concept: {
      goal: 'Zeigen, wie man nach einem harten Tag in 5 Minuten Nacken- und Rückenschmerzen löst, ohne lautes Gebrumm.',
      platform: 'TikTok, Instagram Reels, YouTube Shorts',
      length: '22 Sekunden',
      targetAudience: 'Büroangestellte, Homeoffice-Worker und Sportler mit hartem Feierabend-Nacken.',
    },
    hooks: [
      'Variante A (Schmerz-Hook): „Fühlt sich dein Nacken nach 8 Stunden Schreibtisch auch wie Beton an? Das dauert genau 3 Minuten…“',
      'Variante B (Sound-Hook): Halte die Pistole ans Ohr – man hört fast nichts: „So leise ist eine echte Tiefengewebsmassage.“',
      'Variante C (Größen-Hook): „Große Massagepistolen liegen nach 2 Wochen im Schrank. Die hier liegt auf meinem Nachttisch.“',
    ],
    script: [
      { scene: '0-2s', text: 'Hook: Greife an den steifen Nacken mit schmerzverzerrtem Gesicht vor dem Laptop.' },
      { scene: '2-7s', text: 'Close-Up: Schalte die Mini-Massagepistole ein – edles LED-Licht, leises Schnurren, Aluminium-Finish.' },
      { scene: '7-14s', text: 'Anwendung: Sanft am oberen Trapezmuskel und Schulteransatz entlangfahren. Sichtbare Erleichterung im Gesicht.' },
      { scene: '14-18s', text: 'Größenvergleich: Lege sie neben ein Smartphone (exakt gleich groß!). USB-C Ladeport zeigen.' },
      { scene: '18-22s', text: 'Outro: Auf den Nachttisch stellen. Text: „Im Aufwach-Shop unter Abend-Regeneration. 30 Tage Rückgaberecht.“' }
    ],
    shotlist15Min: [
      { shot: 'Shot 1 (3 Min)', detail: 'Am Schreibtisch sitzen, Hand fasst an den Nacken.' },
      { shot: 'Shot 2 (3 Min)', detail: 'Nahaufnahme Hand: Mini Gun einschalten, Stufe 2 wählen.' },
      { shot: 'Shot 3 (4 Min)', detail: 'Massage am Nacken im warmen Abendlicht, entspannter Gesichtsausdruck.' },
      { shot: 'Shot 4 (3 Min)', detail: 'Side-by-Side mit iPhone auf Holztisch (Größenvergleich).' },
      { shot: 'Shot 5 (2 Min)', detail: 'Nachttisch-Szene mit Buch und Tasse Tee.' }
    ],
    capcutPlan: {
      clipOrder: 'Schreibtisch Frust (0-2s) → Einschalten Close (2-5s) → Massage (5-12s) → Handy-Vergleich (12-16s) → Nachttisch Outro (16-22s)',
      cuts: 'Sanfte Rhythmus-Cuts, Slow-Motion beim Massage-Impact (0.8x Geschwindigkeit).',
      textOverlays: '„NACKEN WIE BETON?“ (0-3s) | „ULTRA-LEISE (40dB)“ (5-8s) | „TASCHENFORMAT 480G“ (12-15s)',
      musicStyle: 'Warm Lo-Fi Ambient / Evening Relax Beats (beruhigend)',
    },
    subtitles: `Nach 8 Stunden Schreibtisch fühlt sich dein Nacken an wie Stein. Große Massagepistolen sind zu schwer und zu laut. Die hier wiegt 480 Gramm, ist flüsterleise und passt auf den Nachttisch. Link im Bio-Shop!`,
    captionAndHashtags: `Der Feierabend-Reset für deinen Nacken. 💆‍♂️ Flüsterleise Tiefenmassage im Taschenformat. Schau in den Aufwach-Shop: Link in Bio! #regeneration #faszienpistole #nackenschmerzen #homeoffice #goalsforce`,
    thumbnailIdea: 'Side-by-Side: Mini Gun neben Smartphone mit Text: „SO KLEIN? SO STARK!“',
  }
];

export const INITIAL_AUDIT_DECISION_CHECKLIST = [
  {
    id: 'dec-01',
    category: 'Steuer & Recht',
    title: 'Steuerstatus festlegen (Kleinunternehmerregelung § 19 UStG)',
    status: 'ENTSCHEIDUNG ERFORDERLICH VOM NUTZER',
    description: 'Bist du Kleinunternehmer nach § 19 UStG (Umsatz < 22.000 €/Jahr, keine MwSt.-Ausweisung) ODER Regelbesteuert (19% MwSt. auf Rechnungen)? Aktuell sind alle Netto-Berechnungen mit 19% MwSt.-Puffer kalkuliert.',
    actionRequired: 'Trage bitte „Kleinunternehmer JA“ oder „Kleinunternehmer NEIN“ ein.',
    agentRecommendation: 'Empfehlung für Start: Kleinunternehmer (§ 19 UStG) spart komplexe monatliche Umsatzsteuer-Voranmeldungen, sobald du unter 22.000 € Jahresumsatz bleibst.',
  },
  {
    id: 'dec-02',
    category: 'Budget & Finanzen',
    title: 'Monatliches Werbebudget freigeben (Aktuell 0 €)',
    status: 'ENTSCHEIDUNG ERFORDERLICH VOM NUTZER',
    description: 'Standard gemäß Leitplanken: 0,00 € Werbeausgaben. Wir starten 100% organisch über TikTok, Reels, Shorts, Pinterest & SEO. Möchtest du ein Testbudget (z.B. 100–300 €) für Google High-Intent Search oder Meta freigeben?',
    actionRequired: 'Trage deinen gewünschten Maximalbetrag pro Monat ein oder bestätige „0 € rein organisch“.',
    agentRecommendation: 'Empfehlung: Erste 4 Wochen rein organisch arbeiten. Bezahlte Werbung erst starten, wenn die organischen Conversion-Raten auf goalsforce.store valide sind.',
  },
  {
    id: 'dec-03',
    category: 'Shopify Freigabe',
    title: 'Startseiten-Abschnitt „Aufwach-Shop“ Theme-Kopie prüfen',
    status: 'BEREIT ZUR PRÜFUNG DURCH NUTZER',
    description: 'Die 3 Kollektionen (Morgen: Yoga & Mobility, Tag: Krafttraining, Abend: Regeneration) sind in einer unveröffentlichten Theme-Kopie fertig strukturiert.',
    actionRequired: 'Sieh dir die Vorschau an und gib bei Gefallen die Veröffentlichung mit „FREIGEBEN“ frei.',
    agentRecommendation: 'Empfehlung: Theme-Kopie prüfen und freigeben, um die Positionierung „Aufwach-Shop für kleine Wohnungen“ zu etablieren.',
  },
  {
    id: 'dec-04',
    category: 'Affiliate Accounts',
    title: 'PartnerNet & AWIN Bewerbung absenden',
    status: 'AKTION DURCH NUTZER ERFORDERLICH',
    description: 'Die 3 Affiliate-Partnerprogramme (Amazon PartnerNet, AWIN für Therabody/Decathlon, Digistore24) erfordern deine Registrierung mit deiner Domain goalsforce.store.',
    actionRequired: 'Erstelle die Konten unter den vorgeschlagenen Links, damit wir die getaggten Affiliate-Links einpflegen können.',
    agentRecommendation: 'Empfehlung: Zuerst Amazon PartnerNet für sperrige Geräte (Bowflex/Peloton) beantragen (schnelle Freischaltung).',
  }
];
