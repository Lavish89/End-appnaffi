// Marketing-Toolkit: 50 echte Werkzeuge. Jedes Tool rechnet ausschliesslich mit den Eingaben
// des Nutzers – keine erfundenen Markt- oder Performance-Daten.

export type FieldType = 'number' | 'text' | 'textarea' | 'select';

export interface ToolField {
  key: string;
  label: string;
  type: FieldType;
  default?: string | number;
  options?: string[];
  placeholder?: string;
}

export type ToolValues = Record<string, string>;

export interface MarketingTool {
  id: string;
  category: ToolCategory;
  name: string;
  description: string;
  fields: ToolField[];
  run: (v: ToolValues) => string | Promise<string>;
  usesAi?: boolean;
}

export type ToolCategory =
  | 'Kalkulation'
  | 'Werbeanzeigen'
  | 'SEO'
  | 'Content & Social'
  | 'E-Mail'
  | 'Conversion & Preise'
  | 'Tracking & Planung';

export const TOOL_CATEGORIES: ToolCategory[] = [
  'Kalkulation',
  'Werbeanzeigen',
  'SEO',
  'Content & Social',
  'E-Mail',
  'Conversion & Preise',
  'Tracking & Planung',
];

// ---------- Helfer ----------
const n = (v: ToolValues, k: string): number => {
  const x = parseFloat(String(v[k] ?? '').replace(',', '.'));
  return Number.isFinite(x) ? x : 0;
};
const t = (v: ToolValues, k: string): string => String(v[k] ?? '').trim();
const eur = (x: number) =>
  Number.isFinite(x) ? x.toLocaleString('de-DE', { style: 'currency', currency: 'EUR' }) : '–';
const pct = (x: number, d = 1) => (Number.isFinite(x) ? `${(x * 100).toFixed(d).replace('.', ',')} %` : '–');
const num = (x: number, d = 2) => (Number.isFinite(x) ? x.toLocaleString('de-DE', { maximumFractionDigits: d }) : '–');
const words = (s: string) => s.split(/\s+/).filter(Boolean);
const lines = (s: string) => s.split(/[\n,;]+/).map(x => x.trim()).filter(Boolean);
const need = (cond: boolean, msg: string) => {
  if (!cond) throw new Error(msg);
};

const slugify = (s: string) =>
  s
    .toLowerCase()
    .replace(/ä/g, 'ae').replace(/ö/g, 'oe').replace(/ü/g, 'ue').replace(/ß/g, 'ss')
    .normalize('NFKD').replace(/[̀-ͯ]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 80);

const countSyllablesDe = (w: string) => {
  const m = w.toLowerCase().match(/[aeiouyäöü]+/g);
  return Math.max(1, m ? m.length : 1);
};

// Normalverteilung (fuer A/B-Test)
const normCdf = (z: number) => {
  const tt = 1 / (1 + 0.2316419 * Math.abs(z));
  const d = 0.3989423 * Math.exp((-z * z) / 2);
  const p = d * tt * (0.3193815 + tt * (-0.3565638 + tt * (1.781478 + tt * (-1.821256 + tt * 1.330274))));
  return z > 0 ? 1 - p : p;
};

const SPAM_WORDS = ['gratis', 'kostenlos', '100%', 'garantiert', 'gewinn', 'jetzt sofort', 'dringend', 'nur heute', 'klicken sie hier', '!!!', '€€€', 'risikofrei', 'unglaublich'];

const PLATFORM_LIMITS: Record<string, { caption: number; hashtags: number; note: string }> = {
  Instagram: { caption: 2200, hashtags: 30, note: 'Nur ca. die ersten 125 Zeichen sind ohne „mehr“ sichtbar.' },
  TikTok: { caption: 4000, hashtags: 0, note: 'Hook in den ersten 1–2 Sekunden des Videos ist wichtiger als die Caption.' },
  Facebook: { caption: 63206, hashtags: 0, note: 'Kurze Posts (unter ca. 80 Zeichen) werden oft besser gelesen.' },
  LinkedIn: { caption: 3000, hashtags: 0, note: 'Nach ca. 210 Zeichen wird „mehr anzeigen“ eingeblendet.' },
  X: { caption: 280, hashtags: 0, note: 'Limit für Standard-Konten.' },
  Pinterest: { caption: 500, hashtags: 0, note: 'Titel max. 100 Zeichen; Keywords im Text helfen bei der Suche.' },
};

// ---------- Die 50 Tools ----------
export const MARKETING_TOOLS: MarketingTool[] = [
  // ===== Kalkulation (10) =====
  {
    id: 'roas', category: 'Kalkulation', name: 'ROAS-Rechner',
    description: 'Return on Ad Spend aus Umsatz und Werbekosten.',
    fields: [
      { key: 'revenue', label: 'Umsatz aus Anzeigen (€)', type: 'number', default: 1200 },
      { key: 'spend', label: 'Werbekosten (€)', type: 'number', default: 300 },
    ],
    run: v => {
      need(n(v, 'spend') > 0, 'Werbekosten müssen größer als 0 sein.');
      const r = n(v, 'revenue') / n(v, 'spend');
      return `ROAS: ${num(r)}x\nPro 1 € Werbung kamen ${eur(r)} Umsatz zurück.`;
    },
  },
  {
    id: 'breakeven-roas', category: 'Kalkulation', name: 'Break-even-ROAS',
    description: 'Ab welchem ROAS du mit Werbung kein Geld mehr verlierst.',
    fields: [{ key: 'margin', label: 'Deckungsbeitrag vor Werbung (% vom Umsatz)', type: 'number', default: 40 }],
    run: v => {
      const m = n(v, 'margin') / 100;
      need(m > 0 && m <= 1, 'Marge muss zwischen 1 und 100 % liegen.');
      return `Break-even-ROAS: ${num(1 / m)}x\nAlles darüber ist Gewinn, alles darunter Verlust.\nZiel-ROAS mit 20 % Puffer: ${num(1.2 / m)}x`;
    },
  },
  {
    id: 'cpa', category: 'Kalkulation', name: 'CPA-Rechner',
    description: 'Kosten pro Kauf (Cost per Acquisition).',
    fields: [
      { key: 'spend', label: 'Werbekosten (€)', type: 'number', default: 300 },
      { key: 'conv', label: 'Käufe', type: 'number', default: 12 },
    ],
    run: v => {
      need(n(v, 'conv') > 0, 'Anzahl Käufe muss größer als 0 sein.');
      return `CPA: ${eur(n(v, 'spend') / n(v, 'conv'))} pro Kauf`;
    },
  },
  {
    id: 'max-cpa', category: 'Kalkulation', name: 'Maximaler CPA',
    description: 'Wie viel ein Neukunde höchstens kosten darf.',
    fields: [
      { key: 'aov', label: 'Ø Warenkorb (€)', type: 'number', default: 45 },
      { key: 'margin', label: 'Deckungsbeitrag vor Werbung (%)', type: 'number', default: 40 },
      { key: 'profit', label: 'Gewünschter Gewinn pro Bestellung (€)', type: 'number', default: 5 },
    ],
    run: v => {
      const db = n(v, 'aov') * n(v, 'margin') / 100;
      const max = db - n(v, 'profit');
      return `Deckungsbeitrag pro Bestellung: ${eur(db)}\nMaximaler CPA (Break-even): ${eur(db)}\nMaximaler CPA mit Wunschgewinn: ${eur(max)}${max <= 0 ? '\n⚠️ Mit diesen Werten ist bezahlte Werbung nicht profitabel.' : ''}`;
    },
  },
  {
    id: 'clv', category: 'Kalkulation', name: 'Customer Lifetime Value',
    description: 'Deckungsbeitrag eines Kunden über die ganze Kundenbeziehung.',
    fields: [
      { key: 'aov', label: 'Ø Warenkorb (€)', type: 'number', default: 45 },
      { key: 'freq', label: 'Käufe pro Jahr', type: 'number', default: 2 },
      { key: 'years', label: 'Kundenbeziehung (Jahre)', type: 'number', default: 2 },
      { key: 'margin', label: 'Deckungsbeitrag (%)', type: 'number', default: 40 },
    ],
    run: v => {
      const rev = n(v, 'aov') * n(v, 'freq') * n(v, 'years');
      return `Umsatz pro Kunde: ${eur(rev)}\nCLV (Deckungsbeitrag): ${eur(rev * n(v, 'margin') / 100)}`;
    },
  },
  {
    id: 'ltv-cac', category: 'Kalkulation', name: 'LTV:CAC-Verhältnis',
    description: 'Verhältnis von Kundenwert zu Akquisekosten.',
    fields: [
      { key: 'ltv', label: 'CLV / Deckungsbeitrag pro Kunde (€)', type: 'number', default: 72 },
      { key: 'cac', label: 'Akquisekosten pro Kunde (€)', type: 'number', default: 25 },
    ],
    run: v => {
      need(n(v, 'cac') > 0, 'CAC muss größer als 0 sein.');
      const r = n(v, 'ltv') / n(v, 'cac');
      const verdict = r >= 3 ? 'Gesund – Skalierung möglich.' : r >= 1 ? 'Knapp profitabel – CAC senken oder Wiederkäufe steigern.' : 'Verlust – jeder Neukunde kostet mehr als er bringt.';
      return `LTV:CAC = ${num(r)} : 1\n${verdict}\n(Faustregel im E-Commerce: ab ca. 3:1 gilt es als gesund.)`;
    },
  },
  {
    id: 'unit-economics', category: 'Kalkulation', name: 'Deckungsbeitrag pro Bestellung',
    description: 'Was nach Einkauf, Versand, Gebühren und Retouren übrig bleibt.',
    fields: [
      { key: 'vk', label: 'Verkaufspreis brutto (€)', type: 'number', default: 39.9 },
      { key: 'vat', label: 'MwSt. (%)', type: 'number', default: 19 },
      { key: 'ek', label: 'Einkaufspreis netto inkl. Lieferant-Versand (€)', type: 'number', default: 12 },
      { key: 'ship', label: 'Versandkosten an Kunden (€)', type: 'number', default: 4.5 },
      { key: 'fee', label: 'Zahlungsgebühr (% + 0,30 €)', type: 'number', default: 2.9 },
      { key: 'ret', label: 'Retourenquote (%)', type: 'number', default: 5 },
    ],
    run: v => {
      const net = n(v, 'vk') / (1 + n(v, 'vat') / 100);
      const fee = n(v, 'vk') * n(v, 'fee') / 100 + 0.3;
      const ret = net * n(v, 'ret') / 100;
      const db = net - n(v, 'ek') - n(v, 'ship') - fee - ret;
      return [
        `Nettoerlös: ${eur(net)}`,
        `− Einkauf: ${eur(n(v, 'ek'))}`,
        `− Versand: ${eur(n(v, 'ship'))}`,
        `− Zahlungsgebühr: ${eur(fee)}`,
        `− Retourenrisiko: ${eur(ret)}`,
        `= Deckungsbeitrag: ${eur(db)} (${pct(db / net)} vom Netto)`,
        db < 0 ? '⚠️ Verlust pro Bestellung.' : `Max. Werbekosten pro Bestellung: ${eur(db)}`,
      ].join('\n');
    },
  },
  {
    id: 'discount-impact', category: 'Kalkulation', name: 'Rabatt-Auswirkung',
    description: 'Wie viel mehr du verkaufen musst, um einen Rabatt auszugleichen.',
    fields: [
      { key: 'margin', label: 'Aktuelle Marge (%)', type: 'number', default: 40 },
      { key: 'disc', label: 'Rabatt (%)', type: 'number', default: 15 },
    ],
    run: v => {
      const m = n(v, 'margin') / 100, d = n(v, 'disc') / 100;
      need(m > d, 'Der Rabatt ist größer als die Marge – jeder Verkauf wäre ein Verlust.');
      const extra = m / (m - d) - 1;
      return `Neue Marge: ${pct(m - d)}\nBenötigter Mehrabsatz für gleichen Gewinn: +${pct(extra)}`;
    },
  },
  {
    id: 'budget-planner', category: 'Kalkulation', name: 'Werbebudget-Planer',
    description: 'Benötigtes Budget für ein Umsatzziel.',
    fields: [
      { key: 'goal', label: 'Umsatzziel pro Monat (€)', type: 'number', default: 5000 },
      { key: 'roas', label: 'Erwarteter ROAS', type: 'number', default: 3 },
    ],
    run: v => {
      need(n(v, 'roas') > 0, 'ROAS muss größer als 0 sein.');
      const b = n(v, 'goal') / n(v, 'roas');
      return `Monatsbudget: ${eur(b)}\nTagesbudget (30 Tage): ${eur(b / 30)}`;
    },
  },
  {
    id: 'influencer-roi', category: 'Kalkulation', name: 'Influencer-Kalkulator',
    description: 'Lohnt sich eine Kooperation? Benötigte Verkäufe und Prognose.',
    fields: [
      { key: 'cost', label: 'Kosten inkl. Produkt (€)', type: 'number', default: 300 },
      { key: 'reach', label: 'Erwartete Aufrufe', type: 'number', default: 20000 },
      { key: 'ctr', label: 'Klickrate (%)', type: 'number', default: 1 },
      { key: 'cr', label: 'Conversion-Rate im Shop (%)', type: 'number', default: 2 },
      { key: 'aov', label: 'Ø Warenkorb (€)', type: 'number', default: 45 },
      { key: 'margin', label: 'Deckungsbeitrag (%)', type: 'number', default: 40 },
    ],
    run: v => {
      const db = n(v, 'aov') * n(v, 'margin') / 100;
      need(db > 0, 'Warenkorb und Marge angeben.');
      const sales = n(v, 'reach') * n(v, 'ctr') / 100 * n(v, 'cr') / 100;
      return `Benötigte Verkäufe für Break-even: ${Math.ceil(n(v, 'cost') / db)}\nPrognose mit deinen Annahmen: ${num(sales, 1)} Verkäufe → ${eur(sales * db - n(v, 'cost'))} Ergebnis`;
    },
  },

  // ===== Werbeanzeigen (8) =====
  {
    id: 'ctr', category: 'Werbeanzeigen', name: 'CTR-Rechner',
    description: 'Klickrate aus Impressionen und Klicks.',
    fields: [
      { key: 'imp', label: 'Impressionen', type: 'number', default: 10000 },
      { key: 'clicks', label: 'Klicks', type: 'number', default: 150 },
    ],
    run: v => {
      need(n(v, 'imp') > 0, 'Impressionen müssen größer als 0 sein.');
      return `CTR: ${pct(n(v, 'clicks') / n(v, 'imp'), 2)}`;
    },
  },
  {
    id: 'cpc-cpm', category: 'Werbeanzeigen', name: 'CPC & CPM',
    description: 'Kosten pro Klick und pro 1.000 Impressionen.',
    fields: [
      { key: 'spend', label: 'Werbekosten (€)', type: 'number', default: 100 },
      { key: 'imp', label: 'Impressionen', type: 'number', default: 12000 },
      { key: 'clicks', label: 'Klicks', type: 'number', default: 180 },
    ],
    run: v => `CPM: ${eur(n(v, 'imp') ? n(v, 'spend') / n(v, 'imp') * 1000 : NaN)}\nCPC: ${eur(n(v, 'clicks') ? n(v, 'spend') / n(v, 'clicks') : NaN)}`,
  },
  {
    id: 'cr', category: 'Werbeanzeigen', name: 'Conversion-Rate',
    description: 'Anteil der Besucher, die kaufen.',
    fields: [
      { key: 'visits', label: 'Besucher', type: 'number', default: 1000 },
      { key: 'orders', label: 'Bestellungen', type: 'number', default: 18 },
    ],
    run: v => {
      need(n(v, 'visits') > 0, 'Besucher müssen größer als 0 sein.');
      return `Conversion-Rate: ${pct(n(v, 'orders') / n(v, 'visits'), 2)}`;
    },
  },
  {
    id: 'funnel', category: 'Werbeanzeigen', name: 'Funnel-Simulator',
    description: 'Vom Budget bis zum Gewinn – Schritt für Schritt.',
    fields: [
      { key: 'budget', label: 'Budget (€)', type: 'number', default: 500 },
      { key: 'cpm', label: 'CPM (€)', type: 'number', default: 8 },
      { key: 'ctr', label: 'CTR (%)', type: 'number', default: 1.2 },
      { key: 'cr', label: 'Conversion-Rate (%)', type: 'number', default: 2 },
      { key: 'aov', label: 'Ø Warenkorb (€)', type: 'number', default: 45 },
      { key: 'margin', label: 'Deckungsbeitrag (%)', type: 'number', default: 40 },
    ],
    run: v => {
      need(n(v, 'cpm') > 0, 'CPM muss größer als 0 sein.');
      const imp = n(v, 'budget') / n(v, 'cpm') * 1000;
      const clicks = imp * n(v, 'ctr') / 100;
      const orders = clicks * n(v, 'cr') / 100;
      const rev = orders * n(v, 'aov');
      const profit = rev * n(v, 'margin') / 100 - n(v, 'budget');
      return `Impressionen: ${num(imp, 0)}\nKlicks: ${num(clicks, 0)}\nBestellungen: ${num(orders, 1)}\nUmsatz: ${eur(rev)}\nROAS: ${num(rev / n(v, 'budget'))}x\nErgebnis nach Werbung: ${eur(profit)}`;
    },
  },
  {
    id: 'ab-significance', category: 'Werbeanzeigen', name: 'A/B-Test-Signifikanz',
    description: 'Ist Variante B wirklich besser oder nur Zufall?',
    fields: [
      { key: 'na', label: 'Besucher A', type: 'number', default: 2000 },
      { key: 'ca', label: 'Conversions A', type: 'number', default: 40 },
      { key: 'nb', label: 'Besucher B', type: 'number', default: 2000 },
      { key: 'cb', label: 'Conversions B', type: 'number', default: 58 },
    ],
    run: v => {
      const na = n(v, 'na'), nb = n(v, 'nb'), pa = n(v, 'ca') / na, pb = n(v, 'cb') / nb;
      need(na > 0 && nb > 0, 'Besucherzahlen angeben.');
      const p = (n(v, 'ca') + n(v, 'cb')) / (na + nb);
      const se = Math.sqrt(p * (1 - p) * (1 / na + 1 / nb));
      need(se > 0, 'Zu wenige Daten.');
      const z = (pb - pa) / se;
      const pval = 2 * (1 - normCdf(Math.abs(z)));
      return `CR A: ${pct(pa, 2)} · CR B: ${pct(pb, 2)}\nUplift: ${pa ? pct((pb - pa) / pa) : '–'}\np-Wert: ${num(pval, 4)}\n${pval < 0.05 ? '✅ Signifikant (95 %) – der Unterschied ist wahrscheinlich echt.' : '⏳ Nicht signifikant – weiter testen.'}`;
    },
  },
  {
    id: 'ab-sample', category: 'Werbeanzeigen', name: 'A/B-Test-Stichprobe',
    description: 'Wie viele Besucher du pro Variante brauchst.',
    fields: [
      { key: 'base', label: 'Aktuelle Conversion-Rate (%)', type: 'number', default: 2 },
      { key: 'mde', label: 'Gewünschter relativer Uplift (%)', type: 'number', default: 20 },
    ],
    run: v => {
      const p1 = n(v, 'base') / 100, p2 = p1 * (1 + n(v, 'mde') / 100);
      need(p1 > 0 && p2 < 1 && p2 > p1, 'Werte prüfen.');
      const za = 1.96, zb = 0.8416; // 95 % Konfidenz, 80 % Power
      const pbar = (p1 + p2) / 2;
      const size = Math.pow(za * Math.sqrt(2 * pbar * (1 - pbar)) + zb * Math.sqrt(p1 * (1 - p1) + p2 * (1 - p2)), 2) / Math.pow(p2 - p1, 2);
      return `Benötigte Besucher pro Variante: ${num(Math.ceil(size), 0)}\nGesamt: ${num(Math.ceil(size) * 2, 0)}\n(95 % Konfidenz, 80 % Teststärke)`;
    },
  },
  {
    id: 'frequency', category: 'Werbeanzeigen', name: 'Frequenz-Check',
    description: 'Wie oft dieselbe Person deine Anzeige sieht.',
    fields: [
      { key: 'imp', label: 'Impressionen', type: 'number', default: 30000 },
      { key: 'reach', label: 'Reichweite (Personen)', type: 'number', default: 9000 },
    ],
    run: v => {
      need(n(v, 'reach') > 0, 'Reichweite angeben.');
      const f = n(v, 'imp') / n(v, 'reach');
      return `Frequenz: ${num(f)}\n${f > 4 ? '⚠️ Hohe Frequenz – Anzeigenmüdigkeit möglich. Neue Creatives testen.' : 'Im üblichen Bereich.'}`;
    },
  },
  {
    id: 'budget-split', category: 'Werbeanzeigen', name: 'Budget-Aufteilung 70/20/10',
    description: '70 % Bewährtes, 20 % Ausbau, 10 % Experimente.',
    fields: [
      { key: 'budget', label: 'Monatsbudget (€)', type: 'number', default: 1000 },
      { key: 'main', label: 'Hauptkanal', type: 'text', default: 'Meta Ads' },
      { key: 'second', label: 'Ausbaukanal', type: 'text', default: 'Google Shopping' },
      { key: 'test', label: 'Testkanal', type: 'text', default: 'TikTok' },
    ],
    run: v => {
      const b = n(v, 'budget');
      return `${t(v, 'main')}: ${eur(b * 0.7)} (${eur(b * 0.7 / 30)}/Tag)\n${t(v, 'second')}: ${eur(b * 0.2)} (${eur(b * 0.2 / 30)}/Tag)\n${t(v, 'test')}: ${eur(b * 0.1)} (${eur(b * 0.1 / 30)}/Tag)`;
    },
  },

  // ===== SEO (8) =====
  {
    id: 'meta-title', category: 'SEO', name: 'Meta-Title-Prüfer',
    description: 'Länge und Keyword-Position für Google.',
    fields: [
      { key: 'title', label: 'Seitentitel', type: 'text', default: 'Widerstandsbänder Set – Home-Gym ohne Geräte | goalsforce' },
      { key: 'kw', label: 'Haupt-Keyword', type: 'text', default: 'Widerstandsbänder' },
    ],
    run: v => {
      const s = t(v, 'title'), kw = t(v, 'kw').toLowerCase();
      const pos = kw ? s.toLowerCase().indexOf(kw) : -1;
      const out = [`Länge: ${s.length} Zeichen (empfohlen: 30–60)`];
      out.push(s.length > 60 ? '⚠️ Zu lang – wird in Google wahrscheinlich abgeschnitten.' : s.length < 30 ? '⚠️ Zu kurz – Platz für Nutzen oder Marke nutzen.' : '✅ Länge passt.');
      if (kw) out.push(pos === -1 ? '⚠️ Keyword fehlt im Titel.' : pos < 20 ? '✅ Keyword steht weit vorne.' : 'ℹ️ Keyword weiter nach vorne ziehen.');
      return out.join('\n');
    },
  },
  {
    id: 'meta-desc', category: 'SEO', name: 'Meta-Description-Prüfer',
    description: 'Länge, Keyword und Handlungsaufforderung.',
    fields: [
      { key: 'desc', label: 'Meta-Description', type: 'textarea', default: 'Trainiere zuhause mit 5 Widerstandsstufen. Platzsparend, inkl. Türanker. Jetzt entdecken!' },
      { key: 'kw', label: 'Haupt-Keyword', type: 'text', default: 'Widerstandsstufen' },
    ],
    run: v => {
      const s = t(v, 'desc');
      const cta = /(jetzt|entdecke|bestell|sichere|hol dir|kaufen|mehr erfahren)/i.test(s);
      return [
        `Länge: ${s.length} Zeichen (empfohlen: 120–155)`,
        s.length > 155 ? '⚠️ Zu lang – wird abgeschnitten.' : s.length < 120 ? 'ℹ️ Etwas kurz – Nutzen ergänzen.' : '✅ Länge passt.',
        t(v, 'kw') ? (s.toLowerCase().includes(t(v, 'kw').toLowerCase()) ? '✅ Keyword enthalten.' : '⚠️ Keyword fehlt.') : '',
        cta ? '✅ Handlungsaufforderung vorhanden.' : 'ℹ️ Handlungsaufforderung ergänzen (z. B. „Jetzt entdecken“).',
      ].filter(Boolean).join('\n');
    },
  },
  {
    id: 'slug', category: 'SEO', name: 'URL-Slug-Generator',
    description: 'Saubere, suchmaschinenfreundliche URL aus einem Titel.',
    fields: [{ key: 'title', label: 'Produkt- oder Seitentitel', type: 'text', default: 'Türanker für Widerstandsbänder – Home-Gym ohne Bohren' }],
    run: v => `/products/${slugify(t(v, 'title'))}`,
  },
  {
    id: 'keyword-density', category: 'SEO', name: 'Keyword-Dichte',
    description: 'Wie oft ein Keyword im Text vorkommt.',
    fields: [
      { key: 'text', label: 'Text', type: 'textarea', default: 'Unsere Widerstandsbänder sind leicht und passen in jede Schublade. Du trainierst zuhause mit fünf Stufen. Widerstandsbänder sind ideal für kleine Wohnungen, weil sie kaum Platz brauchen.', placeholder: 'Produktbeschreibung einfügen …' },
      { key: 'kw', label: 'Keyword', type: 'text', default: 'Widerstandsbänder' },
    ],
    run: v => {
      const w = words(t(v, 'text').toLowerCase());
      need(w.length > 0 && t(v, 'kw').length > 0, 'Text und Keyword eingeben.');
      const kw = t(v, 'kw').toLowerCase();
      const hits = (t(v, 'text').toLowerCase().match(new RegExp(kw.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g')) || []).length;
      const d = hits * words(kw).length / w.length;
      return `Wörter: ${w.length}\nTreffer: ${hits}\nDichte: ${pct(d)}\n${d > 0.03 ? '⚠️ Sehr hoch – wirkt schnell überoptimiert.' : hits === 0 ? '⚠️ Keyword kommt nicht vor.' : '✅ Natürlicher Bereich.'}`;
    },
  },
  {
    id: 'readability', category: 'SEO', name: 'Lesbarkeit (Flesch, Deutsch)',
    description: 'Lesbarkeitsindex nach Amstad für deutsche Texte.',
    fields: [{ key: 'text', label: 'Text', type: 'textarea', default: 'Unsere Widerstandsbänder sind leicht und passen in jede Schublade. Du trainierst zuhause mit fünf Stufen. Widerstandsbänder sind ideal für kleine Wohnungen, weil sie kaum Platz brauchen.', placeholder: 'Text einfügen …' }],
    run: v => {
      const txt = t(v, 'text');
      const sentences = Math.max(1, (txt.match(/[.!?]+/g) || []).length);
      const w = words(txt);
      need(w.length >= 10, 'Bitte mindestens 10 Wörter eingeben.');
      const syl = w.reduce((s, x) => s + countSyllablesDe(x), 0);
      const score = 180 - w.length / sentences - 58.5 * (syl / w.length);
      const label = score >= 70 ? 'leicht' : score >= 50 ? 'mittel' : score >= 30 ? 'schwer' : 'sehr schwer';
      return `Flesch-Wert: ${num(score, 0)} (${label})\nØ Wörter pro Satz: ${num(w.length / sentences, 1)}\nFür Produkttexte sind Werte ab ca. 60 gut lesbar.`;
    },
  },
  {
    id: 'serp-preview', category: 'SEO', name: 'Google-Vorschau',
    description: 'So ungefähr erscheint deine Seite in den Suchergebnissen.',
    fields: [
      { key: 'title', label: 'Titel', type: 'text', default: 'Widerstandsbänder Set – Home-Gym | goalsforce' },
      { key: 'url', label: 'URL', type: 'text', default: 'goalsforce.store/products/widerstandsbaender-set' },
      { key: 'desc', label: 'Beschreibung', type: 'textarea', default: 'Trainiere zuhause mit 5 Widerstandsstufen. Platzsparend und inkl. Türanker.' },
    ],
    run: v => {
      const ti = t(v, 'title'), de = t(v, 'desc');
      return `${t(v, 'url')}\n${ti.length > 60 ? ti.slice(0, 57) + '…' : ti}\n${de.length > 155 ? de.slice(0, 152) + '…' : de}`;
    },
  },
  {
    id: 'jsonld-product', category: 'SEO', name: 'Produkt-Schema (JSON-LD)',
    description: 'Strukturierte Daten für Rich Results bei Google.',
    fields: [
      { key: 'name', label: 'Produktname', type: 'text', default: 'Widerstandsbänder Set' },
      { key: 'desc', label: 'Kurzbeschreibung', type: 'text', default: '5 Stufen, inkl. Türanker' },
      { key: 'price', label: 'Preis (€)', type: 'number', default: 29.9 },
      { key: 'brand', label: 'Marke', type: 'text', default: 'goalsforce' },
      { key: 'url', label: 'Produkt-URL', type: 'text', default: 'https://goalsforce.store/products/widerstandsbaender-set' },
      { key: 'image', label: 'Bild-URL', type: 'text', default: '' },
      { key: 'stock', label: 'Verfügbarkeit', type: 'select', options: ['InStock', 'OutOfStock', 'PreOrder'], default: 'InStock' },
    ],
    run: v => {
      const data: Record<string, unknown> = {
        '@context': 'https://schema.org',
        '@type': 'Product',
        name: t(v, 'name'),
        description: t(v, 'desc'),
        brand: { '@type': 'Brand', name: t(v, 'brand') },
        offers: {
          '@type': 'Offer',
          url: t(v, 'url'),
          priceCurrency: 'EUR',
          price: n(v, 'price').toFixed(2),
          availability: `https://schema.org/${t(v, 'stock') || 'InStock'}`,
        },
      };
      if (t(v, 'image')) data.image = [t(v, 'image')];
      return `<script type="application/ld+json">\n${JSON.stringify(data, null, 2)}\n</script>`;
    },
  },
  {
    id: 'alt-text', category: 'SEO', name: 'Alt-Text-Generator',
    description: 'Beschreibende Alt-Texte für Produktbilder.',
    fields: [
      { key: 'product', label: 'Produkt', type: 'text', default: 'Widerstandsbänder Set' },
      { key: 'attrs', label: 'Merkmale (Komma-getrennt)', type: 'text', default: 'schwarz, 5 Stärken, mit Türanker' },
      { key: 'scenes', label: 'Bildmotive (Komma-getrennt)', type: 'text', default: 'Freisteller, im Wohnzimmer, Detail Griff' },
    ],
    run: v => {
      const attrs = lines(t(v, 'attrs')).join(', ');
      return lines(t(v, 'scenes')).map((s, i) => `Bild ${i + 1}: ${t(v, 'product')} ${attrs ? `(${attrs})` : ''} – ${s}`.slice(0, 125)).join('\n') || 'Bitte Bildmotive angeben.';
    },
  },

  // ===== Content & Social (10) =====
  {
    id: 'hashtags', category: 'Content & Social', name: 'Hashtag-Generator',
    description: 'Hashtags aus deinen Keywords – Mix aus breit und Nische.',
    fields: [
      { key: 'kw', label: 'Keywords (Komma-getrennt)', type: 'text', default: 'homegym, widerstandsbänder, fitness zuhause' },
      { key: 'brand', label: 'Marken-Hashtag', type: 'text', default: 'goalsforce' },
    ],
    run: v => {
      const base = lines(t(v, 'kw')).map(k => k.replace(/\s+/g, '').toLowerCase());
      const extra = base.flatMap(k => [k, `${k}training`, `${k}tipps`]);
      const set = Array.from(new Set([...extra, t(v, 'brand').replace(/\s+/g, '').toLowerCase()].filter(Boolean)));
      return set.slice(0, 15).map(h => `#${h.replace(/[^a-z0-9äöüß]/gi, '')}`).join(' ');
    },
  },
  {
    id: 'hooks', category: 'Content & Social', name: 'Video-Hook-Generator',
    description: '10 Einstiegssätze für Reels und TikToks.',
    fields: [
      { key: 'product', label: 'Produkt', type: 'text', default: 'Widerstandsbänder' },
      { key: 'problem', label: 'Problem der Zielgruppe', type: 'text', default: 'kein Platz für ein Fitnessstudio' },
      { key: 'audience', label: 'Zielgruppe', type: 'text', default: 'Leute in kleinen Wohnungen' },
    ],
    run: v => {
      const p = t(v, 'product'), pr = t(v, 'problem'), a = t(v, 'audience');
      return [
        `POV: Du hast ${pr} – und trainierst trotzdem jeden Tag.`,
        `Das hier hätte ich gerne früher gewusst: ${p}.`,
        `3 Fehler, die ${a} beim Training machen.`,
        `Hör auf damit, wenn du ${pr} hast.`,
        `Ich habe 30 Tage nur mit ${p} trainiert. Das ist passiert:`,
        `Warum ${a} ${p} lieben.`,
        `So sieht mein komplettes Home-Gym aus – passt in eine Schublade.`,
        `Unbeliebte Meinung: Du brauchst kein Fitnessstudio.`,
        `${p} in 15 Sekunden erklärt.`,
        `Speichere dir das, wenn du ${pr} hast.`,
      ].map((h, i) => `${i + 1}. ${h}`).join('\n');
    },
  },
  {
    id: 'caption-check', category: 'Content & Social', name: 'Caption-Längen-Check',
    description: 'Passt dein Text zur Plattform?',
    fields: [
      { key: 'platform', label: 'Plattform', type: 'select', options: Object.keys(PLATFORM_LIMITS), default: 'Instagram' },
      { key: 'text', label: 'Caption', type: 'textarea', default: 'Mein Home-Gym passt in eine Schublade 💪 Welche Übung soll ich als Nächstes zeigen? #homegym #fitnesszuhause' },
    ],
    run: v => {
      const L = PLATFORM_LIMITS[t(v, 'platform')] || PLATFORM_LIMITS.Instagram;
      const s = t(v, 'text');
      const tags = (s.match(/#\w+/g) || []).length;
      return [
        `Zeichen: ${s.length} / ${L.caption}`,
        s.length > L.caption ? '⚠️ Zu lang für diese Plattform.' : '✅ Innerhalb des Limits.',
        `Hashtags: ${tags}${L.hashtags && tags > L.hashtags ? ` ⚠️ (max. ${L.hashtags})` : ''}`,
        `Tipp: ${L.note}`,
      ].join('\n');
    },
  },
  {
    id: 'content-calendar', category: 'Content & Social', name: 'Content-Kalender (30 Tage)',
    description: 'Ein Monatsplan mit rotierenden Inhaltstypen.',
    fields: [
      { key: 'start', label: 'Startdatum', type: 'text', default: new Date().toISOString().slice(0, 10), placeholder: 'JJJJ-MM-TT' },
      { key: 'perWeek', label: 'Posts pro Woche', type: 'number', default: 4 },
      { key: 'topic', label: 'Hauptthema', type: 'text', default: 'Home-Gym in kleinen Wohnungen' },
    ],
    run: v => {
      const start = new Date(t(v, 'start'));
      need(!isNaN(start.getTime()), 'Datum im Format JJJJ-MM-TT eingeben.');
      const per = Math.min(7, Math.max(1, Math.round(n(v, 'perWeek'))));
      const types = ['Tipp/Anleitung', 'Produkt in Aktion', 'Kundenfrage beantworten', 'Vorher/Nachher oder Ergebnis', 'Hinter den Kulissen', 'Mythos aufklären', 'Mini-Workout'];
      const dayPattern = [1, 3, 5, 0, 2, 4, 6].slice(0, per);
      const out: string[] = [];
      let k = 0;
      for (let d = 0; d < 30; d++) {
        const day = new Date(start.getTime() + d * 86400000);
        if (dayPattern.includes(day.getDay())) {
          out.push(`${day.toLocaleDateString('de-DE', { weekday: 'short', day: '2-digit', month: '2-digit' })}: ${types[k % types.length]} – ${t(v, 'topic')}`);
          k++;
        }
      }
      return out.join('\n');
    },
  },
  {
    id: 'post-frequency', category: 'Content & Social', name: 'Posting-Aufwand-Planer',
    description: 'Wie viel Zeit dein Content-Plan pro Monat kostet.',
    fields: [
      { key: 'posts', label: 'Posts pro Woche', type: 'number', default: 4 },
      { key: 'minutes', label: 'Minuten pro Post (Idee, Dreh, Schnitt)', type: 'number', default: 45 },
      { key: 'platforms', label: 'Anzahl Plattformen', type: 'number', default: 2 },
      { key: 'reuse', label: 'Mehraufwand pro weiterer Plattform (Minuten)', type: 'number', default: 5 },
    ],
    run: v => {
      const per = n(v, 'minutes') + Math.max(0, n(v, 'platforms') - 1) * n(v, 'reuse');
      const month = per * n(v, 'posts') * 4.33;
      return `Pro Post: ${num(per, 0)} Min.\nPro Monat: ${num(month / 60, 1)} Std.\nTipp: Ein Video für alle Plattformen wiederverwenden spart am meisten Zeit.`;
    },
  },
  {
    id: 'aida', category: 'Content & Social', name: 'AIDA-Werbetext',
    description: 'Attention, Interest, Desire, Action – als Textgerüst.',
    fields: [
      { key: 'product', label: 'Produkt', type: 'text', default: 'Widerstandsbänder Set' },
      { key: 'audience', label: 'Zielgruppe', type: 'text', default: 'Berufstätige in kleinen Wohnungen' },
      { key: 'benefit', label: 'Hauptnutzen', type: 'text', default: 'Ganzkörpertraining in 20 Minuten ohne Geräte' },
      { key: 'proof', label: 'Beweis / Besonderheit', type: 'text', default: '5 Stärken, passt in jede Schublade' },
      { key: 'offer', label: 'Angebot / CTA', type: 'text', default: 'Jetzt im Shop entdecken' },
    ],
    run: v => `Aufmerksamkeit: Kein Platz, keine Zeit – und trotzdem fit?\nInteresse: Für ${t(v, 'audience')}: ${t(v, 'product')}.\nVerlangen: ${t(v, 'benefit')}. ${t(v, 'proof')}.\nHandlung: ${t(v, 'offer')}.`,
  },
  {
    id: 'pas', category: 'Content & Social', name: 'PAS-Werbetext',
    description: 'Problem – Verstärkung – Lösung.',
    fields: [
      { key: 'problem', label: 'Problem', type: 'text', default: 'Das Fitnessstudio ist zu weit weg' },
      { key: 'agitate', label: 'Folge des Problems', type: 'text', default: 'Am Ende trainierst du gar nicht' },
      { key: 'solution', label: 'Deine Lösung', type: 'text', default: 'Mit unserem Set trainierst du direkt im Wohnzimmer' },
    ],
    run: v => `${t(v, 'problem')}?\n${t(v, 'agitate')}.\n${t(v, 'solution')}.`,
  },
  {
    id: 'features-benefits', category: 'Content & Social', name: 'Merkmal → Nutzen',
    description: 'Macht aus technischen Merkmalen Kundennutzen.',
    fields: [{ key: 'features', label: 'Merkmale (eins pro Zeile)', type: 'textarea', default: 'Naturlatex\n5 Widerstandsstufen\nInkl. Türanker\nTasche' }],
    run: v => lines(t(v, 'features')).map(f => `✓ ${f} – damit du … [Nutzen für den Kunden ergänzen: Was wird leichter, schneller, angenehmer?]`).join('\n') || 'Bitte Merkmale eingeben.',
  },
  {
    id: 'text-cleaner', category: 'Content & Social', name: 'Text-Bereiniger',
    description: 'Entfernt Emojis, doppelte Leerzeichen und Leerzeilen.',
    fields: [{ key: 'text', label: 'Text', type: 'textarea', default: 'Super   Angebot 🔥🔥\n\n\n\nJetzt   ansehen 👉' }],
    run: v => t(v, 'text')
      .replace(/[\u{1F000}-\u{1FAFF}\u{2600}-\u{27BF}\u{FE0F}]/gu, '')
      .replace(/[ \t]+/g, ' ')
      .replace(/\n{3,}/g, '\n\n')
      .trim(),
  },
  {
    id: 'ai-ad-copy', category: 'Content & Social', name: 'KI-Werbetext (Gemini)',
    description: 'Hook, Skript, CTA und Hashtags per KI. Benötigt GEMINI_API_KEY.',
    usesAi: true,
    fields: [
      { key: 'productName', label: 'Produkt', type: 'text', default: 'Widerstandsbänder Set' },
      { key: 'channel', label: 'Kanal', type: 'select', options: ['tiktok', 'instagram', 'pinterest', 'google_ads', 'email_flow'], default: 'tiktok' },
      { key: 'targetAudience', label: 'Zielgruppe', type: 'text', default: 'Home-Workout in kleinen Wohnungen' },
      { key: 'price', label: 'Preis', type: 'text', default: '29,90 €' },
    ],
    run: async v => {
      const res = await fetch('/api/gemini/generate-marketing', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(v),
      });
      const j = await res.json();
      need(res.ok && j.success, j.error || 'KI-Anfrage fehlgeschlagen.');
      const d = j.data || {};
      const note = j.source && !String(j.source).startsWith('gemini') ? '\n\n(Beispieltext – kein GEMINI_API_KEY gesetzt.)' : '';
      return `Hook: ${d.hook}\n\n${d.scriptOrBody}\n\nCTA: ${d.callToAction}\n${(d.hashtags || []).join(' ')}${note}`;
    },
  },

  // ===== E-Mail (6) =====
  {
    id: 'subject-lines', category: 'E-Mail', name: 'Betreffzeilen-Generator',
    description: '10 Betreffzeilen in verschiedenen Stilen.',
    fields: [
      { key: 'topic', label: 'Thema / Produkt', type: 'text', default: 'Widerstandsbänder' },
      { key: 'benefit', label: 'Nutzen', type: 'text', default: 'Training ohne Fitnessstudio' },
      { key: 'name', label: 'Personalisierung', type: 'text', default: '{{ first_name }}' },
    ],
    run: v => {
      const tp = t(v, 'topic'), b = t(v, 'benefit'), nm = t(v, 'name');
      return [
        `${nm}, ${b} – so geht's`,
        `Neu: ${tp}`,
        `Die 3 häufigsten Fragen zu ${tp}`,
        `Du hast etwas vergessen …`,
        `${b} in 20 Minuten`,
        `Warum so viele auf ${tp} umsteigen`,
        `Kurze Frage, ${nm}`,
        `Dein Plan für diese Woche`,
        `${tp}: Das sagen unsere Kunden`,
        `Weniger Platz, mehr Training`,
      ].map((s, i) => `${i + 1}. ${s} (${s.length} Z.)`).join('\n');
    },
  },
  {
    id: 'subject-check', category: 'E-Mail', name: 'Betreffzeilen-Check',
    description: 'Länge, Spam-Signalwörter und Großbuchstaben.',
    fields: [{ key: 'subject', label: 'Betreffzeile', type: 'text', default: 'GRATIS Versand nur heute!!!' }],
    run: v => {
      const s = t(v, 'subject');
      const spam = SPAM_WORDS.filter(w => s.toLowerCase().includes(w));
      const caps = (s.match(/[A-ZÄÖÜ]/g) || []).length / Math.max(1, (s.match(/[a-zäöüA-ZÄÖÜ]/g) || []).length);
      return [
        `Länge: ${s.length} Zeichen ${s.length > 50 ? '⚠️ (auf dem Handy oft abgeschnitten, ideal unter 50)' : '✅'}`,
        spam.length ? `⚠️ Spam-Signalwörter: ${spam.join(', ')}` : '✅ Keine typischen Spam-Wörter.',
        caps > 0.3 ? '⚠️ Viele Großbuchstaben – wirkt aufdringlich.' : '✅ Groß-/Kleinschreibung unauffällig.',
      ].join('\n');
    },
  },
  {
    id: 'abandoned-cart', category: 'E-Mail', name: 'Warenkorbabbruch-Serie',
    description: 'Drei E-Mails mit Zeitplan und Inhalt.',
    fields: [
      { key: 'shop', label: 'Shopname', type: 'text', default: 'goalsforce' },
      { key: 'code', label: 'Rabattcode (optional, nur Mail 3)', type: 'text', default: '' },
    ],
    run: v => [
      `Mail 1 – nach 1 Stunde\nBetreff: Dein Warenkorb bei ${t(v, 'shop')} wartet\nInhalt: Freundliche Erinnerung, Produktbild, Button „Zum Warenkorb“.`,
      `Mail 2 – nach 24 Stunden\nBetreff: Noch Fragen?\nInhalt: Häufige Fragen (Versand, Rückgabe), Kontaktmöglichkeit, Kundenstimme.`,
      `Mail 3 – nach 72 Stunden\nBetreff: Letzte Erinnerung\nInhalt: ${t(v, 'code') ? `Rabattcode ${t(v, 'code')} mit echtem Ablaufdatum.` : 'Nutzen zusammenfassen, kein Rabatt nötig.'}`,
      `Hinweis: Nur an Kunden mit Einwilligung zum Marketing-Versand oder im Rahmen von § 7 Abs. 3 UWG.`,
    ].join('\n\n'),
  },
  {
    id: 'welcome-flow', category: 'E-Mail', name: 'Willkommens-Serie',
    description: 'Vier E-Mails für neue Newsletter-Abonnenten.',
    fields: [
      { key: 'shop', label: 'Shopname', type: 'text', default: 'goalsforce' },
      { key: 'gift', label: 'Willkommensgeschenk', type: 'text', default: '10 % auf die erste Bestellung' },
    ],
    run: v => [
      `Tag 0: Willkommen bei ${t(v, 'shop')} + ${t(v, 'gift')}`,
      `Tag 2: Unsere Geschichte – warum es ${t(v, 'shop')} gibt`,
      `Tag 4: Bestseller und wofür sie gut sind`,
      `Tag 7: Erinnerung an ${t(v, 'gift')} + Kundenstimmen`,
    ].join('\n'),
  },
  {
    id: 'email-rates', category: 'E-Mail', name: 'E-Mail-Kennzahlen',
    description: 'Öffnungs-, Klick- und Abmelderate.',
    fields: [
      { key: 'sent', label: 'Zugestellt', type: 'number', default: 1000 },
      { key: 'opens', label: 'Öffnungen', type: 'number', default: 380 },
      { key: 'clicks', label: 'Klicks', type: 'number', default: 42 },
      { key: 'unsub', label: 'Abmeldungen', type: 'number', default: 3 },
      { key: 'revenue', label: 'Umsatz (€)', type: 'number', default: 250 },
    ],
    run: v => {
      const s = n(v, 'sent');
      need(s > 0, 'Zugestellte E-Mails angeben.');
      return `Öffnungsrate: ${pct(n(v, 'opens') / s)}\nKlickrate: ${pct(n(v, 'clicks') / s, 2)}\nKlicks pro Öffnung: ${n(v, 'opens') ? pct(n(v, 'clicks') / n(v, 'opens')) : '–'}\nAbmelderate: ${pct(n(v, 'unsub') / s, 2)}\nUmsatz pro Empfänger: ${eur(n(v, 'revenue') / s)}\nHinweis: Öffnungsraten sind durch Apple Mail Privacy oft zu hoch.`;
    },
  },
  {
    id: 'list-growth', category: 'E-Mail', name: 'Listenwachstum-Prognose',
    description: 'Wie groß deine Liste in 12 Monaten wird.',
    fields: [
      { key: 'start', label: 'Aktuelle Abonnenten', type: 'number', default: 0 },
      { key: 'visitors', label: 'Besucher pro Monat', type: 'number', default: 2000 },
      { key: 'optin', label: 'Anmelderate (%)', type: 'number', default: 3 },
      { key: 'churn', label: 'Abmeldungen pro Monat (%)', type: 'number', default: 1 },
    ],
    run: v => {
      let s = n(v, 'start');
      const out: string[] = [];
      for (let m = 1; m <= 12; m++) {
        s = s * (1 - n(v, 'churn') / 100) + n(v, 'visitors') * n(v, 'optin') / 100;
        if (m % 3 === 0) out.push(`Monat ${m}: ${num(s, 0)} Abonnenten`);
      }
      return out.join('\n');
    },
  },

  // ===== Conversion & Preise (5) =====
  {
    id: 'charm-price', category: 'Conversion & Preise', name: 'Preisschwellen-Rechner',
    description: 'Psychologische Preise rund um deinen Wunschpreis.',
    fields: [{ key: 'price', label: 'Kalkulierter Preis (€)', type: 'number', default: 31.4 }],
    run: v => {
      const p = n(v, 'price');
      need(p > 1, 'Preis angeben.');
      const down = Math.floor(p) - 0.01, up = Math.ceil(p) - 0.01, round5 = Math.ceil(p / 5) * 5 - 0.1;
      return `Leicht darunter: ${eur(down)}\nNächste Schwelle: ${eur(up < p ? up + 1 : up)}\nRunde Optik: ${eur(round5)}\nTipp: Bei Premium-Produkten wirken glatte Preise (z. B. 35 €) oft hochwertiger.`;
    },
  },
  {
    id: 'free-shipping', category: 'Conversion & Preise', name: 'Versandkostenfrei-Schwelle',
    description: 'Ab welchem Bestellwert kostenloser Versand sinnvoll ist.',
    fields: [
      { key: 'aov', label: 'Ø Warenkorb (€)', type: 'number', default: 38 },
      { key: 'ship', label: 'Deine Versandkosten pro Paket (€)', type: 'number', default: 4.5 },
      { key: 'margin', label: 'Deckungsbeitrag (%)', type: 'number', default: 40 },
    ],
    run: v => {
      const low = n(v, 'aov') * 1.15, high = n(v, 'aov') * 1.3;
      const needed = n(v, 'ship') / (n(v, 'margin') / 100);
      return `Empfohlene Schwelle: ${eur(low)} – ${eur(high)} (15–30 % über dem Ø Warenkorb)\nZusätzlicher Umsatz, der den Versand finanziert: ${eur(needed)}\n${n(v, 'aov') + needed > high ? '⚠️ Bei deiner Marge reicht die Schwelle allein nicht – Versand teilweise einpreisen.' : '✅ Schwelle ist mit deiner Marge tragbar.'}`;
    },
  },
  {
    id: 'bundle', category: 'Conversion & Preise', name: 'Bundle-Preis-Rechner',
    description: 'Preis und Marge für ein Produktset.',
    fields: [
      { key: 'prices', label: 'Einzelpreise (€, Komma-getrennt)', type: 'text', default: '29.90; 14.90; 9.90' },
      { key: 'costs', label: 'Einkaufspreise (€, Komma-getrennt)', type: 'text', default: '9; 4; 2.5' },
      { key: 'disc', label: 'Bundle-Rabatt (%)', type: 'number', default: 15 },
    ],
    run: v => {
      const ps = t(v, 'prices').split(/[;\s]+/).map(x => parseFloat(x.replace(',', '.'))).filter(Number.isFinite);
      const cs = t(v, 'costs').split(/[;\s]+/).map(x => parseFloat(x.replace(',', '.'))).filter(Number.isFinite);
      need(ps.length > 0, 'Preise mit Semikolon trennen, z. B. 29.90; 14.90');
      const sum = ps.reduce((a, b) => a + b, 0), cost = cs.reduce((a, b) => a + b, 0);
      const bp = sum * (1 - n(v, 'disc') / 100);
      return `Einzeln: ${eur(sum)}\nBundle-Preis: ${eur(bp)} (Ersparnis ${eur(sum - bp)})\nRohertrag Bundle: ${eur(bp - cost)} (${pct((bp - cost) / bp)})`;
    },
  },
  {
    id: 'coupon-codes', category: 'Conversion & Preise', name: 'Gutscheincode-Generator',
    description: 'Eindeutige Codes für Kampagnen oder Partner.',
    fields: [
      { key: 'prefix', label: 'Präfix', type: 'text', default: 'GOALS' },
      { key: 'count', label: 'Anzahl', type: 'number', default: 10 },
      { key: 'len', label: 'Zufallszeichen', type: 'number', default: 5 },
    ],
    run: v => {
      const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
      const cnt = Math.min(500, Math.max(1, Math.round(n(v, 'count'))));
      const len = Math.min(12, Math.max(3, Math.round(n(v, 'len'))));
      const set = new Set<string>();
      const rnd = new Uint32Array(len);
      while (set.size < cnt) {
        crypto.getRandomValues(rnd);
        set.add(`${t(v, 'prefix').toUpperCase()}-${Array.from(rnd, x => chars[x % chars.length]).join('')}`);
      }
      return Array.from(set).join('\n');
    },
  },
  {
    id: 'review-request', category: 'Conversion & Preise', name: 'Bewertungs-Anfrage',
    description: 'Text, um nach dem Kauf um eine ehrliche Bewertung zu bitten.',
    fields: [
      { key: 'product', label: 'Produkt', type: 'text', default: 'Widerstandsbänder Set' },
      { key: 'days', label: 'Tage nach Zustellung', type: 'number', default: 10 },
    ],
    run: v => `Versand: ${num(n(v, 'days'), 0)} Tage nach Zustellung\n\nBetreff: Wie gefällt dir dein ${t(v, 'product')}?\n\nHallo {{ first_name }},\ndu nutzt dein ${t(v, 'product')} jetzt seit ein paar Tagen. Wir würden uns über eine ehrliche Bewertung freuen – positiv wie negativ. Sie hilft anderen bei der Entscheidung und uns beim Besserwerden.\n[Jetzt bewerten]\n\nHinweis: Bewertungen nicht an Gegenleistungen knüpfen (sonst Kennzeichnungspflicht).`,
  },

  // ===== Tracking & Planung (3) =====
  {
    id: 'utm', category: 'Tracking & Planung', name: 'UTM-Link-Builder',
    description: 'Kampagnen-Links für Google Analytics und Shopify.',
    fields: [
      { key: 'url', label: 'Ziel-URL', type: 'text', default: 'https://goalsforce.store/products/widerstandsbaender-set' },
      { key: 'source', label: 'Quelle (utm_source)', type: 'text', default: 'instagram' },
      { key: 'medium', label: 'Medium (utm_medium)', type: 'text', default: 'social' },
      { key: 'campaign', label: 'Kampagne (utm_campaign)', type: 'text', default: 'herbst_2026' },
      { key: 'content', label: 'Inhalt (utm_content, optional)', type: 'text', default: '' },
    ],
    run: v => {
      let u: URL;
      try { u = new URL(t(v, 'url')); } catch { throw new Error('Bitte eine vollständige URL mit https:// eingeben.'); }
      (['source', 'medium', 'campaign', 'content'] as const).forEach(k => {
        const val = slugify(t(v, k)).replace(/-/g, '_');
        if (val) u.searchParams.set(`utm_${k}`, val);
      });
      return u.toString();
    },
  },
  {
    id: 'campaign-name', category: 'Tracking & Planung', name: 'Kampagnen-Namensschema',
    description: 'Einheitliche Namen für Kampagnen, Anzeigengruppen und Anzeigen.',
    fields: [
      { key: 'channel', label: 'Kanal', type: 'text', default: 'META' },
      { key: 'goal', label: 'Ziel', type: 'select', options: ['SALES', 'TRAFFIC', 'LEADS', 'AWARENESS', 'RETARGETING'], default: 'SALES' },
      { key: 'product', label: 'Produkt', type: 'text', default: 'Widerstandsbaender' },
      { key: 'audience', label: 'Zielgruppe', type: 'text', default: 'DE 25-45 Fitness' },
      { key: 'creative', label: 'Creative', type: 'text', default: 'UGC Video 1' },
    ],
    run: v => {
      const ym = new Date().toISOString().slice(0, 7).replace('-', '');
      const c = (s: string) => slugify(s).replace(/-/g, '').toUpperCase();
      return `Kampagne: ${c(t(v, 'channel'))}_${t(v, 'goal')}_${c(t(v, 'product'))}_${ym}\nAnzeigengruppe: ${c(t(v, 'audience'))}\nAnzeige: ${c(t(v, 'creative'))}`;
    },
  },
  {
    id: 'kpi-backwards', category: 'Tracking & Planung', name: 'Umsatzziel rückwärts',
    description: 'Wie viele Besucher und Bestellungen du für dein Ziel brauchst.',
    fields: [
      { key: 'goal', label: 'Umsatzziel pro Monat (€)', type: 'number', default: 3000 },
      { key: 'aov', label: 'Ø Warenkorb (€)', type: 'number', default: 40 },
      { key: 'cr', label: 'Conversion-Rate (%)', type: 'number', default: 1.5 },
    ],
    run: v => {
      need(n(v, 'aov') > 0 && n(v, 'cr') > 0, 'Warenkorb und Conversion-Rate angeben.');
      const orders = n(v, 'goal') / n(v, 'aov');
      const visitors = orders / (n(v, 'cr') / 100);
      return `Bestellungen pro Monat: ${num(Math.ceil(orders), 0)} (${num(orders / 30, 1)} pro Tag)\nBenötigte Besucher: ${num(Math.ceil(visitors), 0)} (${num(visitors / 30, 0)} pro Tag)`;
    },
  },
];
