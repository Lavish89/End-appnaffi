import React, { useState } from 'react';
import { Dumbbell, Link2, Zap, FileText, Wallet, GraduationCap, Wrench, ChevronDown, Check, ArrowRight } from 'lucide-react';
import { Pricing } from '../billing/Pricing';
import type { Interval } from '../billing/plans';
import { LegalPagesModal } from '../components/LegalPagesModal';
import { RECIPES } from '../affiliate/engine';
import { LESSONS } from '../affiliate/tutorials';
import { NETWORKS } from '../affiliate/networks';
import { ALL_TOOLS as MARKETING_TOOLS } from '../data/allTools';

const FEATURES = [
  { icon: Link2, title: 'Kurzlinks mit Klickzählung', text: 'Füg deinen Affiliate-Link ein und bekomm einen kurzen, eigenen Link. Du siehst, wie oft er geklickt wird.' },
  { icon: Zap, title: 'Automationen, die mitdenken', text: 'SubIDs anhängen, Post-Entwürfe schreiben, an Auszahlungen erinnern, Wochenbericht – automatisch.' },
  { icon: FileText, title: 'Posts mit Kennzeichnung', text: 'Fertige Texte für Instagram, TikTok, Pinterest, Newsletter und Blog – „Anzeige“ und Amazon-Hinweis sind schon drin.' },
  { icon: Wallet, title: 'Einnahmen im Blick', text: 'Provisionen eintragen, Status verfolgen und den Verdienst pro Klick je Link sehen. Export als CSV für die Steuer.' },
  { icon: GraduationCap, title: 'Lernen für Anfänger', text: 'Geführte Tour und Lektionen mit Quiz – von „Was ist Affiliate-Marketing?“ bis Gewerbe und Steuern.' },
  { icon: Wrench, title: 'Marketing-Werkzeuge', text: 'Rechner für ROAS, Deckungsbeitrag und A/B-Tests, SEO-Prüfer, UTM-Links, Hook-Generator und mehr.' },
];

const FAQ = [
  { q: 'Was kostet Goalsforce?', a: 'Der Free-Plan ist dauerhaft kostenlos. Pro schaltet unbegrenzte Links, alle Automationen, KI-Texte und die Link-Prüfung frei – monatlich oder jährlich, jederzeit zum Ende der Laufzeit kündbar.' },
  { q: 'Brauche ich Erfahrung?', a: 'Nein. Die Tour und der Lernbereich führen dich Schritt für Schritt bis zum ersten Link. Viele starten als kompletter Anfänger.' },
  { q: 'Mit welchen Partnerprogrammen funktioniert das?', a: 'Mit allen, die dir einen Affiliate-Link geben – zum Beispiel Amazon PartnerNet, AWIN, Digistore24 oder ADCELL. Du meldest dich dort selbst an und trägst deine Links hier ein.' },
  { q: 'Verdiene ich damit automatisch Geld?', a: 'Nein – und wer das verspricht, übertreibt. Goalsforce nimmt dir Routine ab und zeigt dir, was funktioniert. Einnahmen entstehen durch gute Empfehlungen und Reichweite, und das braucht meist ein paar Monate.' },
  { q: 'Ist das rechtssicher?', a: 'Die App fügt Werbekennzeichnung und den Amazon-Pflichthinweis automatisch ein und hat eine Rechts-Checkliste. Sie ersetzt aber keine Rechtsberatung.' },
  { q: 'Wie kündige ich?', a: 'Unter „Konto & Mitgliedschaft“ mit einem Klick auf „Verträge hier kündigen“. Du bekommst sofort eine Bestätigung per E-Mail, Pro läuft bis zum Ende der bezahlten Zeit.' },
  { q: 'Was passiert mit meinen Daten?', a: 'Deine Links, Einnahmen und Entwürfe sieht nur dein Konto. Passwörter werden verschlüsselt gespeichert. Du kannst jederzeit eine Sicherung kopieren.' },
];

export const Landing: React.FC<{ authForm: React.ReactNode; onChoosePlan: (plan: 'free' | 'pro', interval: Interval) => void }> = ({ authForm, onChoosePlan }) => {
  const [legal, setLegal] = useState<null | 'impressum' | 'datenschutz' | 'agb'>(null);
  const [faq, setFaq] = useState<number | null>(0);
  const toForm = () => document.getElementById('auth-card')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
  const register = () => { onChoosePlan('free', 'month'); };
  const stats = [
    { n: MARKETING_TOOLS.length, label: 'Marketing-Werkzeuge' },
    { n: RECIPES.length, label: 'fertige Automationen' },
    { n: LESSONS.length, label: 'Lektionen für Anfänger' },
    { n: NETWORKS.length, label: 'Netzwerke im Verzeichnis' },
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100">
      <header className="sticky top-0 z-40 bg-slate-950/90 backdrop-blur border-b border-slate-800">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-3 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-400 flex items-center justify-center"><Dumbbell className="w-4 h-4 text-slate-950" /></div>
            <span className="text-lg font-bold tracking-tight">Goalsforce</span>
          </div>
          <nav className="hidden md:flex items-center gap-6 text-sm text-slate-400" aria-label="Seitenbereiche">
            <a href="#funktionen" className="hover:text-slate-100">Funktionen</a>
            <a href="#so-gehts" className="hover:text-slate-100">So geht’s</a>
            <a href="#preise" className="hover:text-slate-100">Preise</a>
            <a href="#faq" className="hover:text-slate-100">Fragen</a>
          </nav>
          <button onClick={toForm} className="px-3.5 py-1.5 text-xs font-bold rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950">Anmelden</button>
        </div>
      </header>

      <section className="max-w-6xl mx-auto px-4 sm:px-6 py-12 lg:py-16 grid grid-cols-1 lg:grid-cols-[1fr_440px] gap-10 items-center">
        <div className="space-y-6">
          <div className="text-[11px] uppercase tracking-wider font-bold text-amber-400">Für Creator, Blogger und Einsteiger</div>
          <h1 className="text-4xl sm:text-5xl font-bold tracking-tight leading-[1.1]">Dein Cockpit für Affiliate-Marketing.</h1>
          <p className="text-base text-slate-400 max-w-xl">Partnerprogramme, Links, Provisionen und Posts an einem Ort – und Automationen, die die Routine für dich erledigen. Kostenlos starten, in deinem Tempo lernen.</p>
          <ul className="space-y-2">
            {['Kostenloser Plan ohne Zeitlimit', 'Werbekennzeichnung automatisch in jedem Entwurf', 'Monatlich oder jährlich upgraden, jederzeit kündbar'].map(t => (
              <li key={t} className="flex items-center gap-2 text-sm text-slate-300"><Check className="w-4 h-4 text-emerald-400 shrink-0" /> {t}</li>
            ))}
          </ul>
          <div className="flex flex-wrap gap-3">
            <button onClick={register} className="px-5 py-3 text-sm font-bold rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 flex items-center gap-2">Kostenlos starten <ArrowRight className="w-4 h-4" /></button>
            <a href="#preise" className="px-5 py-3 text-sm font-semibold rounded-xl border border-slate-700 hover:bg-slate-800 text-slate-200">Preise ansehen</a>
          </div>
        </div>
        <div>{authForm}</div>
      </section>

      <section className="border-y border-slate-800 bg-slate-900/40">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8 grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
          {stats.map(s => (
            <div key={s.label}>
              <div className="text-3xl font-bold text-amber-300 font-mono tabular-nums">{s.n}</div>
              <div className="text-xs text-slate-400 mt-1">{s.label}</div>
            </div>
          ))}
        </div>
      </section>

      <section id="so-gehts" className="max-w-6xl mx-auto px-4 sm:px-6 py-16 space-y-8">
        <div className="text-center space-y-2">
          <h2 className="text-2xl sm:text-3xl font-bold">In drei Schritten zum ersten Link</h2>
          <p className="text-sm text-slate-400">So startest du – auch ganz ohne Vorkenntnisse.</p>
        </div>
        <ol className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[
            ['Partnerprogramm wählen', 'Such dir im Verzeichnis ein Netzwerk aus, melde dich dort an und trag es ein.'],
            ['Link anlegen', 'Füg deinen Affiliate-Link ein. Du bekommst einen Kurzlink und fertige Post-Entwürfe.'],
            ['Posten & auswerten', 'Veröffentliche deine Beiträge und trag Provisionen ein. Der Wochenbericht zeigt, was läuft.'],
          ].map(([t, d], i) => (
            <li key={t} className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5 space-y-2">
              <div className="w-8 h-8 rounded-full bg-amber-400 text-slate-950 font-bold flex items-center justify-center text-sm">{i + 1}</div>
              <h3 className="font-semibold text-slate-100">{t}</h3>
              <p className="text-sm text-slate-400">{d}</p>
            </li>
          ))}
        </ol>
      </section>

      <section id="funktionen" className="max-w-6xl mx-auto px-4 sm:px-6 py-16 space-y-8">
        <div className="text-center space-y-2">
          <h2 className="text-2xl sm:text-3xl font-bold">Alles, was du brauchst</h2>
          <p className="text-sm text-slate-400">Keine erfundenen Zahlen: Alles basiert auf deinen echten Klicks und Einträgen.</p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {FEATURES.map(f => {
            const Icon = f.icon;
            return (
              <div key={f.title} className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5 space-y-2">
                <Icon className="w-5 h-5 text-amber-400" />
                <h3 className="font-semibold text-slate-100">{f.title}</h3>
                <p className="text-sm text-slate-400">{f.text}</p>
              </div>
            );
          })}
        </div>
      </section>

      <section id="preise" className="max-w-6xl mx-auto px-4 sm:px-6 py-16 space-y-8">
        <div className="text-center space-y-2">
          <h2 className="text-2xl sm:text-3xl font-bold">Einfache Preise</h2>
          <p className="text-sm text-slate-400">Starte kostenlos. Upgrade, wenn du mehr willst.</p>
        </div>
        <Pricing onChoose={onChoosePlan} />
      </section>

      <section id="faq" className="max-w-3xl mx-auto px-4 sm:px-6 py-16 space-y-6">
        <h2 className="text-2xl sm:text-3xl font-bold text-center">Häufige Fragen</h2>
        <div className="space-y-2">
          {FAQ.map((f, i) => (
            <div key={f.q} className="bg-slate-900/60 border border-slate-800 rounded-xl">
              <button onClick={() => setFaq(faq === i ? null : i)} aria-expanded={faq === i} className="w-full flex items-center justify-between gap-3 px-4 py-3.5 text-left text-sm font-semibold text-slate-100">
                {f.q}
                <ChevronDown className={`w-4 h-4 text-slate-500 shrink-0 transition-transform ${faq === i ? 'rotate-180' : ''}`} />
              </button>
              {faq === i && <p className="px-4 pb-4 text-sm text-slate-400 leading-relaxed">{f.a}</p>}
            </div>
          ))}
        </div>
      </section>

      <section className="max-w-4xl mx-auto px-4 sm:px-6 py-16">
        <div className="bg-gradient-to-br from-amber-400 to-amber-500 rounded-3xl p-8 sm:p-10 text-center text-slate-950 space-y-4">
          <h2 className="text-2xl sm:text-3xl font-bold">Bereit für deinen ersten Affiliate-Link?</h2>
          <p className="text-sm max-w-lg mx-auto">Konto in einer Minute erstellt. Kostenlos, ohne Zahlungsdaten.</p>
          <button onClick={register} className="px-6 py-3 text-sm font-bold rounded-xl bg-slate-950 text-amber-300 hover:bg-slate-900">Jetzt kostenlos starten</button>
        </div>
      </section>

      <footer className="border-t border-slate-800">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-500">
          <span>© {new Date().getFullYear()} Goalsforce · Dragos Serbu</span>
          <div className="flex gap-4">
            <button onClick={() => setLegal('impressum')} className="hover:text-slate-300">Impressum</button>
            <button onClick={() => setLegal('datenschutz')} className="hover:text-slate-300">Datenschutz</button>
            <button onClick={() => setLegal('agb')} className="hover:text-slate-300">AGB & Widerruf</button>
          </div>
        </div>
      </footer>
      <LegalPagesModal isOpen={legal !== null} onClose={() => setLegal(null)} initialTab={legal || 'impressum'} />
    </div>
  );
};
